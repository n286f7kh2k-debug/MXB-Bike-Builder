from pathlib import Path
import os, json, shutil

APP_NAME = 'MXB Race Day Live'
LEGACY_APP_NAME = 'MXB Race Control'
VERSION = '0.3.4'
UPDATE_FEED = 'https://raw.githubusercontent.com/n286f7kh2k-debug/MXB-Bike-Builder/main/race-control/latest.json'

_BASE = Path(os.getenv('APPDATA', Path.home()))
APPDATA = _BASE / APP_NAME
LEGACY_APPDATA = _BASE / LEGACY_APP_NAME

# One-time data migration after the product rename. Never overwrite a newer Race Day Live
# database/settings with the legacy directory; copy only when the new home does not exist.
if not APPDATA.exists() and LEGACY_APPDATA.exists():
    try:
        shutil.copytree(LEGACY_APPDATA, APPDATA)
    except Exception:
        APPDATA.mkdir(parents=True, exist_ok=True)
else:
    APPDATA.mkdir(parents=True, exist_ok=True)

SETTINGS_FILE = APPDATA / 'settings.json'
DB_FILE = APPDATA / 'race_day_live.db'
LEGACY_DB_FILE = APPDATA / 'race_control.db'

# The legacy DB may have been copied during rename migration. Move it into the new product
# filename once; SQLite sidecars are deliberately ignored because the app is not running yet.
if not DB_FILE.exists() and LEGACY_DB_FILE.exists():
    try:
        LEGACY_DB_FILE.replace(DB_FILE)
    except Exception:
        try: shutil.copy2(LEGACY_DB_FILE, DB_FILE)
        except Exception: pass

DEFAULTS = {
    'theme': 'dark',
    'update_feed': UPDATE_FEED,
    'owner_name': 'Race Director',
    'no_refunds': True,
    'auto_check_updates': True,
}

def load_settings():
    data = dict(DEFAULTS)
    if SETTINGS_FILE.exists():
        try:
            data.update(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')))
        except Exception:
            pass
    if not data.get('update_feed'):
        data['update_feed'] = UPDATE_FEED
    return data

def save_settings(data):
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding='utf-8')
