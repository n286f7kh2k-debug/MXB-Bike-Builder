Option Explicit
On Error Resume Next
Dim shell, fso, root, pyw, pye, cmd, rc, logPath, logFile
Set shell = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
root = fso.GetParentFolderName(WScript.ScriptFullName)
shell.CurrentDirectory = root
logPath = shell.ExpandEnvironmentStrings("%TEMP%") & "\MXB_Race_Day_Live_restart.log"

Sub LogLine(msg)
  Err.Clear
  Set logFile = fso.OpenTextFile(logPath, 8, True)
  logFile.WriteLine Now & " " & msg
  logFile.Close
End Sub

' Give the updater helper time to fully exit and release file handles.
WScript.Sleep 1800
pyw = root & "\.venv\Scripts\pythonw.exe"
pye = root & "\.venv\Scripts\python.exe"

If fso.FileExists(pyw) Then
  Err.Clear
  cmd = Chr(34) & pyw & Chr(34) & " " & Chr(34) & root & "\app.py" & Chr(34)
  rc = shell.Run(cmd, 0, False)
  If Err.Number = 0 Then
    LogLine "Restarted with private pythonw.exe"
    WScript.Quit 0
  End If
  LogLine "pythonw launch failed: " & Err.Description
End If

If fso.FileExists(pye) Then
  Err.Clear
  cmd = Chr(34) & pye & Chr(34) & " " & Chr(34) & root & "\app.py" & Chr(34)
  rc = shell.Run(cmd, 0, False)
  If Err.Number = 0 Then
    LogLine "Restarted with private python.exe"
    WScript.Quit 0
  End If
  LogLine "python launch failed: " & Err.Description
End If

' Last resort: recreate the private environment, then launch it.
Err.Clear
cmd = "cmd.exe /d /s /c ""cd /d """ & root & """ && (where py >nul 2>nul && py -3 -m venv .venv || python -m venv .venv) && .venv\Scripts\python.exe -m pip install --disable-pip-version-check -r requirements.txt"""
rc = shell.Run(cmd, 0, True)
If rc = 0 And fso.FileExists(pyw) Then
  Err.Clear
  cmd = Chr(34) & pyw & Chr(34) & " " & Chr(34) & root & "\app.py" & Chr(34)
  shell.Run cmd, 0, False
  If Err.Number = 0 Then
    LogLine "Restarted after rebuilding private environment"
    WScript.Quit 0
  End If
End If

LogLine "Automatic restart failed"
