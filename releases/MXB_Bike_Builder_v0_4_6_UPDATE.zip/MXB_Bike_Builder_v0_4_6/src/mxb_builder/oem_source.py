from __future__ import annotations

"""MX Bikes bike-source helpers for installed OEM ``.pkz`` packages.

MX Bikes commonly stores bikes as ``.pkz`` files under ``mods/bikes``. Plain PKZ
files use the ZIP local-file header, so they can be inspected with Python's standard
``zipfile`` module without modifying the user's original package.

This module is deliberately read/copy only. It never writes back into an OEM PKZ.
Creator-locked/non-plain PKZ files are detected and left untouched.
"""

from dataclasses import dataclass
from io import BytesIO
from pathlib import Path
import shutil
import zipfile
from typing import Callable, Iterable

ZIP_MAGIC = b"PK\x03\x04"
MAX_SCAN_DEPTH = 4


class OemSourceError(RuntimeError):
    pass


@dataclass(frozen=True)
class BikeSource:
    source: Path
    display_name: str
    nested_member: str = ""


def _starts_with_zip_magic(data: bytes) -> bool:
    return len(data) >= 4 and data[:4] == ZIP_MAGIC




def is_edf_payload(data: bytes) -> bool:
    """Return True only for a real MX Bikes EDF payload, not a text/redirect placeholder."""
    return len(data) >= 4 and data[:4] == b"EDF\0"


def find_installed_oem_model_edf(
    bikes_dir: str | Path | None,
    keywords: Iterable[str],
    source_hint: str | Path | None = None,
) -> Path | None:
    """Locate the real Project OEM visual model stored under ``OEM_Models``.

    Modern Project OEM packs can keep physics in the per-bike PKZ while storing the
    visual EDFs separately under ``mods/bikes/OEM_Models/MX``.  Only files whose
    first four bytes are the actual ``EDF\0`` magic are considered.
    """
    if not bikes_dir:
        return None
    root = Path(bikes_dir).expanduser()
    if not root.is_dir():
        return None

    model_roots = [
        root / "OEM_Models" / "MX",
        root / "OEM_Models",
        root / "OEM Models" / "MX",
        root / "OEM Models",
    ]
    model_roots = [p for p in model_roots if p.is_dir()]
    if not model_roots:
        return None

    hints = list(keywords)
    if source_hint:
        hints.append(Path(source_hint).stem)
    strong = _strong_keywords(hints)

    candidates: list[Path] = []
    for model_root in model_roots:
        try:
            for path in model_root.rglob("*.edf"):
                try:
                    rel_depth = len(path.relative_to(model_root).parts)
                except ValueError:
                    continue
                if rel_depth > 7:
                    continue
                low = path.name.lower()
                if any(tag in low for tag in ("shadow", "cockpit", "temp")):
                    continue
                try:
                    with path.open("rb") as fh:
                        if fh.read(4) != b"EDF\0":
                            continue
                except OSError:
                    continue
                candidates.append(path)
        except OSError:
            continue

    if not candidates:
        return None

    def score(path: Path) -> tuple[int, int, int]:
        text = path.as_posix().lower().replace("-", "_").replace(" ", "_")
        val = source_score(text, hints)
        for kw in strong:
            norm = kw.lower().replace("-", "_").replace(" ", "_")
            if norm and norm in text:
                val += 160
        if path.name.lower() == "model.edf":
            val += 80
        # Prefer shallower, more canonical model folders when the text score ties.
        return (val, -len(path.parts), -len(path.name))

    return max(candidates, key=score)

def is_plain_zip_file(path: str | Path) -> bool:
    path = Path(path)
    try:
        with path.open("rb") as fh:
            return fh.read(4) == ZIP_MAGIC
    except OSError:
        return False


def _safe_rel(name: str) -> Path | None:
    parts = [p for p in name.replace("\\", "/").split("/") if p not in ("", ".", "..")]
    if not parts:
        return None
    # Reject Windows drive/absolute-ish archive members too.
    if ":" in parts[0] or name.startswith(("/", "\\")):
        return None
    return Path(*parts)


def _strong_keywords(keywords: Iterable[str]) -> tuple[str, ...]:
    kws = tuple(k.lower().strip() for k in keywords if k and k.strip())
    specific = tuple(k for k in kws if any(ch.isdigit() for ch in k) or "kx" in k or "crf" in k or "yz" in k or "rm" in k or "sx" in k)
    return specific or kws


def source_score(name: str, keywords: Iterable[str]) -> int:
    low = name.lower().replace("-", "_").replace(" ", "_")
    kws = tuple(k.lower().replace("-", "_").replace(" ", "_") for k in keywords if k)
    score = 0
    for kw in kws:
        if kw and kw in low:
            # Model-like keywords are much more valuable than manufacturer/year words.
            score += 100 if any(c.isdigit() for c in kw) or kw.startswith(("kx", "cr", "yz", "rm", "sx")) else 20
    if "oem" in low:
        score += 20
    if low.endswith(".pkz"):
        score += 8
    if "shadow" in low or "server" in low:
        score -= 20
    return score


def _best_named(paths: Iterable[Path], keywords: Iterable[str]) -> Path | None:
    items = list(paths)
    if not items:
        return None
    strong = _strong_keywords(keywords)
    matching = [p for p in items if any(k in p.name.lower() for k in strong)]
    pool = matching or items
    return max(pool, key=lambda p: (source_score(p.name, keywords), -len(p.name)))


def resolve_reference_source(
    explicit_source: str | Path | None,
    legacy_edf: str | Path | None,
    donor_bike_dir: str | Path | None,
    bikes_dir: str | Path | None,
    keywords: tuple[str, ...] = ("kx450", "kx450f", "kxf450", "2023", "kawasaki"),
) -> Path | None:
    """Find a usable bike reference, preferring installed OEM PKZ files.

    Order: explicit OEM/source path -> legacy explicit EDF -> donor folder -> matching
    PKZ in ``mods/bikes`` -> matching unpacked bike folder.
    """
    # v0.4.2's explicit OEM/source choice wins. The legacy v0.4 model.edf is
    # intentionally deferred until after installed OEM auto-detection; this prevents a
    # stale/bad EDF selection from blocking the Project OEM PKZ that is already installed.
    if explicit_source:
        p = Path(explicit_source).expanduser()
        if p.exists() and p.is_dir():
            return p
        if p.is_file() and p.suffix.lower() in {".pkz", ".zip"}:
            return p
        if p.is_file() and p.suffix.lower() == ".edf":
            # Older builds let a user select an EDF-named Project OEM redirect/placeholder.
            # Do not let that stale setting permanently outrank the real installed OEM bike.
            try:
                if is_edf_payload(p.read_bytes()[:4]):
                    return p
            except OSError:
                pass
            # Invalid EDF falls through to installed PKZ/OEM model discovery.

    if donor_bike_dir:
        donor = Path(donor_bike_dir).expanduser()
        if donor.is_dir():
            if (donor / "model.edf").is_file() or any(donor.glob("*.edf")):
                return donor

    if not bikes_dir:
        return None
    root = Path(bikes_dir).expanduser()
    if not root.is_dir():
        return None

    # Project OEM installs individual bike PKZ files directly under mods/bikes.
    archives = [p for p in root.iterdir() if p.is_file() and p.suffix.lower() == ".pkz"]
    strong = _strong_keywords(keywords)
    direct = [p for p in archives if any(k in p.name.lower() for k in strong)]
    if direct:
        return max(direct, key=lambda p: source_score(p.name, keywords))

    # Then check unpacked bike folders with matching names.
    dirs = [p for p in root.iterdir() if p.is_dir()]
    direct_dirs = [p for p in dirs if any(k in p.name.lower() for k in strong)]
    for p in sorted(direct_dirs, key=lambda p: source_score(p.name, keywords), reverse=True):
        if (p / "model.edf").is_file() or any(p.glob("*.edf")):
            return p

    # Last resort: inspect small descriptor files inside plain PKZs. This keeps the
    # common path fast while still handling unusually named OEM archives.
    for p in archives:
        if not is_plain_zip_file(p):
            continue
        try:
            with zipfile.ZipFile(p) as zf:
                for info in zf.infolist():
                    low = info.filename.lower()
                    if info.is_dir() or info.file_size > 256 * 1024:
                        continue
                    if not low.endswith((".ini", ".cfg")):
                        continue
                    text = zf.read(info).decode("utf-8", errors="ignore").lower()
                    if any(k in text for k in strong):
                        return p
        except (OSError, zipfile.BadZipFile, RuntimeError):
            continue

    if legacy_edf:
        p = Path(legacy_edf).expanduser()
        if p.is_file() and p.suffix.lower() == ".edf":
            try:
                if is_edf_payload(p.read_bytes()[:4]):
                    return p
            except OSError:
                pass
    return None


def _read_directory_selected(root: Path, keep: Callable[[str], bool]) -> list[tuple[str, bytes]]:
    out: list[tuple[str, bytes]] = []
    base_depth = len(root.parts)
    for p in root.rglob("*"):
        if not p.is_file() or len(p.parts) - base_depth > MAX_SCAN_DEPTH:
            continue
        rel = p.relative_to(root).as_posix()
        if keep(rel):
            try:
                out.append((rel, p.read_bytes()))
            except OSError:
                pass
    return out


def _select_nested_pkz_name(names: Iterable[str], keywords: Iterable[str]) -> str | None:
    candidates = [n for n in names if n.lower().endswith(".pkz")]
    if not candidates:
        return None
    strong = _strong_keywords(keywords)
    matching = [n for n in candidates if any(k in n.lower() for k in strong)]
    pool = matching or candidates
    return max(pool, key=lambda n: source_score(n, keywords))


def _read_zip_selected(
    zf: zipfile.ZipFile,
    keep: Callable[[str], bool],
    keywords: Iterable[str],
) -> tuple[list[tuple[str, bytes]], str]:
    infos = [i for i in zf.infolist() if not i.is_dir()]
    names = [i.filename.replace("\\", "/") for i in infos]

    # Individual bike PKZ / already-unpacked ZIP: read its bike files directly.
    direct = [i for i in infos if keep(i.filename.replace("\\", "/"))]
    if any(i.filename.lower().endswith(".edf") for i in direct):
        return [(i.filename.replace("\\", "/"), zf.read(i)) for i in direct], ""

    # Full Project OEM download: locate the matching individual bike PKZ inside it,
    # then inspect that nested PKZ in memory. The outer archive stays untouched.
    nested_name = _select_nested_pkz_name(names, keywords)
    if nested_name:
        info = next(i for i in infos if i.filename.replace("\\", "/") == nested_name)
        nested = zf.read(info)
        if not _starts_with_zip_magic(nested):
            raise OemSourceError(
                f"The selected OEM bike inside this pack ({Path(nested_name).name}) is creator-locked/non-plain. "
                "MXB Bike Builder will not bypass a locked PKZ."
            )
        try:
            with zipfile.ZipFile(BytesIO(nested)) as inner:
                entries, _ = _read_zip_selected(inner, keep, keywords)
                return entries, nested_name
        except zipfile.BadZipFile as exc:
            raise OemSourceError(f"Could not open nested OEM bike {Path(nested_name).name}.") from exc

    return [(i.filename.replace("\\", "/"), zf.read(i)) for i in direct], ""


def read_selected_entries(
    source: str | Path,
    keep: Callable[[str], bool],
    keywords: tuple[str, ...] = ("kx450", "kx450f", "kxf450", "2023", "kawasaki"),
) -> tuple[list[tuple[str, bytes]], BikeSource]:
    source = Path(source).expanduser()
    if source.is_dir():
        return _read_directory_selected(source, keep), BikeSource(source, source.name)
    if not source.is_file():
        raise OemSourceError(f"Bike source not found: {source}")

    if source.suffix.lower() == ".edf":
        return [(source.name, source.read_bytes())], BikeSource(source, source.parent.name or source.stem)

    if not is_plain_zip_file(source):
        raise OemSourceError(
            f"{source.name} is a creator-locked/non-plain PKZ. MXB Bike Builder can read normal OEM PKZ/ZIP packages "
            "but will not bypass creator locking."
        )
    try:
        with zipfile.ZipFile(source) as zf:
            entries, nested = _read_zip_selected(zf, keep, keywords)
    except zipfile.BadZipFile as exc:
        raise OemSourceError(f"{source.name} is not a readable OEM PKZ/ZIP package.") from exc

    display = Path(nested).stem if nested else source.stem
    return entries, BikeSource(source, display, nested)


def _extract_zipfile(zf: zipfile.ZipFile, destination: Path) -> None:
    for info in zf.infolist():
        if info.is_dir():
            continue
        rel = _safe_rel(info.filename)
        if rel is None:
            continue
        target = destination / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        with zf.open(info) as src, target.open("wb") as dst:
            shutil.copyfileobj(src, dst)


def _flatten_to_bike_root(destination: Path) -> None:
    if list(destination.glob("*.cfg")) and list(destination.glob("*.ini")):
        return
    candidates: list[Path] = []
    for cfg in destination.rglob("*.cfg"):
        folder = cfg.parent
        try:
            depth = len(folder.relative_to(destination).parts)
        except ValueError:
            continue
        if depth <= MAX_SCAN_DEPTH and list(folder.glob("*.ini")):
            candidates.append(folder)
    if not candidates:
        return
    root = min(candidates, key=lambda p: len(p.relative_to(destination).parts))
    if root == destination:
        return
    temp = destination.with_name(destination.name + "_flatten")
    if temp.exists():
        shutil.rmtree(temp)
    shutil.copytree(root, temp)
    shutil.rmtree(destination)
    temp.rename(destination)


def extract_bike_source(
    source: str | Path,
    destination: str | Path,
    keywords: tuple[str, ...] = ("kx450", "kx450f", "kxf450", "2023", "kawasaki"),
) -> BikeSource:
    """Clone an unpacked bike folder or a plain OEM PKZ into ``destination``.

    Supports selecting the full Project OEM ZIP too; the matching nested bike PKZ is
    chosen by ``keywords``. The source archive is never modified.
    """
    source = Path(source).expanduser()
    destination = Path(destination)
    if destination.exists():
        shutil.rmtree(destination)
    destination.mkdir(parents=True, exist_ok=True)

    if source.is_dir():
        shutil.rmtree(destination)
        shutil.copytree(source, destination)
        _flatten_to_bike_root(destination)
        return BikeSource(source, source.name)

    if not source.is_file() or source.suffix.lower() == ".edf":
        raise OemSourceError("A playable donor must be an OEM .pkz/.zip or an unpacked bike folder, not a lone EDF.")
    if not is_plain_zip_file(source):
        raise OemSourceError(
            f"{source.name} is creator-locked/non-plain. MXB Bike Builder will not bypass a locked PKZ."
        )

    try:
        with zipfile.ZipFile(source) as zf:
            infos = [i for i in zf.infolist() if not i.is_dir()]
            names = [i.filename.replace("\\", "/") for i in infos]
            has_direct_bike = any(n.lower().endswith(".edf") for n in names) and any(
                n.lower().endswith(".cfg") for n in names
            )
            nested_name = ""
            if has_direct_bike:
                _extract_zipfile(zf, destination)
            else:
                nested_name = _select_nested_pkz_name(names, keywords) or ""
                if not nested_name:
                    raise OemSourceError("No bike PKZ was found inside this OEM package.")
                info = next(i for i in infos if i.filename.replace("\\", "/") == nested_name)
                nested = zf.read(info)
                if not _starts_with_zip_magic(nested):
                    raise OemSourceError(
                        f"{Path(nested_name).name} is creator-locked/non-plain. MXB Bike Builder will not bypass it."
                    )
                with zipfile.ZipFile(BytesIO(nested)) as inner:
                    _extract_zipfile(inner, destination)
    except zipfile.BadZipFile as exc:
        raise OemSourceError(f"Could not open OEM package {source.name}.") from exc

    _flatten_to_bike_root(destination)
    if not list(destination.glob("*.cfg")) or not list(destination.glob("*.ini")):
        raise OemSourceError("The OEM package opened, but a root bike .cfg/.ini pair was not found.")
    return BikeSource(source, Path(nested_name).stem if nested_name else source.stem, nested_name)
