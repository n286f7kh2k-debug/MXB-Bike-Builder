from pathlib import Path
import os, json

APP_NAME = 'MXB Race Control'
VERSION = '0.1.3'
UPDATE_FEED = 'https://raw.githubusercontent.com/n286f7kh2k-debug/MXB-Bike-Builder/main/race-control/latest.json'

APPDATA = Path(os.getenv('APPDATA', Path.home())) / APP_NAME
APPDATA.mkdir(parents=True, exist_ok=True)
SETTINGS_FILE = APPDATA / 'settings.json'
DB_FILE = APPDATA / 'race_control.db'

DEFAULTS = {
    'theme': 'dark',
    'update_feed': UPDATE_FEED,
    'owner_name': 'Race Director',
    'no_refunds': True,
    'auto_check_updates': True,
}

def load_settings():
    data = dict(DEFAULTS)
    if SETTINGS_FILE.exists():
        try:
            data.update(json.loads(SETTINGS_FILE.read_text(encoding='utf-8')))
        except Exception:
            pass
    if not data.get('update_feed'):
        data['update_feed'] = UPDATE_FEED
    return data

def save_settings(data):
    SETTINGS_FILE.write_text(json.dumps(data, indent=2), encoding='utf-8')
