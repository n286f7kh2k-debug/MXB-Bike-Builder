from __future__ import annotations

"""Read-only MX Bikes EDF geometry preview support.

This module intentionally uses EDF only as a *viewer/reference* source. It does not
write, decompile, or redistribute a user's game assets.

Geometry-layout and placement logic is a clean-room Python port adapted from the
MIT-licensed `Frostn1/mxb-app` EDF reader (Copyright (c) 2026 Sean Dahan).
See THIRD_PARTY_NOTICES.md for the required MIT notice and source URL.
"""

from dataclasses import dataclass
from pathlib import Path
import math
import re
import struct
from typing import Iterable

import numpy as np

from .oem_source import OemSourceError, read_selected_entries, resolve_reference_source

STRIDE = 72
HEADER_START = 0x54
MAX_COUNT = 3_000_000
SUB_MAT_BACK = 148
SUB_MAT_PARENT_STEP = 280
NODE_MAT_OFF = 104
NODE_MAT_END = 168


class EdfPreviewError(RuntimeError):
    pass


@dataclass
class RawSub:
    name: str
    tri_start: int
    tri_count: int
    block_off: int
    vert_start: int
    vert_count: int


@dataclass
class SubCand:
    block_off: int
    tri_start: int
    tri_count: int
    vert_start: int
    vert_count: int


@dataclass
class EdfNode:
    name: str
    positions: np.ndarray  # (N, 3), float32
    uvs: np.ndarray        # (N, 2), float32
    normals: np.ndarray    # (N, 3), float32
    indices: np.ndarray    # (M, 3), uint32
    placed: bool = False


@dataclass
class EdfPreview:
    source: Path
    geom_source: Path | None
    nodes: list[EdfNode]
    assembled: bool
    display_name: str = ""

    @property
    def vertex_count(self) -> int:
        return sum(len(n.positions) for n in self.nodes)

    @property
    def triangle_count(self) -> int:
        return sum(len(n.indices) for n in self.nodes)


def _u32(b: bytes, o: int) -> int:
    return struct.unpack_from("<I", b, o)[0]


def _f32(b: bytes, o: int) -> float:
    return struct.unpack_from("<f", b, o)[0]


def _read_mat4(b: bytes, o: int) -> np.ndarray | None:
    if o < 0 or o + 64 > len(b):
        return None
    vals = np.frombuffer(b, dtype="<f4", count=16, offset=o).astype(np.float64, copy=True)
    if not np.isfinite(vals).all() or np.max(np.abs(vals)) >= 10.0:
        return None
    m = vals.reshape(4, 4)
    if not np.allclose(m[3], [0.0, 0.0, 0.0, 1.0], atol=1e-6):
        return None
    r = m[:3, :3]
    if not np.allclose(np.sum(r * r, axis=1), [1.0, 1.0, 1.0], atol=1e-3):
        return None
    det = float(np.linalg.det(r))
    if abs(abs(det) - 1.0) > 1e-3:
        return None
    return m.astype(np.float32)


def _apply_mat_points(points: np.ndarray, m: np.ndarray) -> np.ndarray:
    return points @ m[:3, :3].T + m[:3, 3]


def _apply_mat_dirs(dirs: np.ndarray, m: np.ndarray) -> np.ndarray:
    return dirs @ m[:3, :3].T


def _plausible_name(b: bytes, o: int) -> str | None:
    if o >= len(b) or not chr(b[o]).isalpha():
        return None
    end = o
    while end < len(b) and end - o < 32:
        c = b[end]
        if c == 0:
            break
        if not (chr(c).isalnum() or c in b"._-"):
            return None
        end += 1
    size = end - o
    if 2 <= size <= 31:
        return b[o:end].decode("ascii", errors="ignore")
    return None


def _read_cname(b: bytes, o: int) -> str:
    end = o
    while end < len(b) and 32 <= b[end] < 127:
        end += 1
    return b[o:end].decode("ascii", errors="ignore")


def _read_sub_group(
    b: bytes, o: int, tot_tris: int, tot_verts: int
) -> tuple[int, int, int, int] | None:
    if o < 0 or o + 24 > len(b):
        return None
    tri_start = _u32(b, o)
    first_vs = _u32(b, o + 8)
    tri_total = 0
    vc_total = 0
    k = o
    for _ in range(64):
        if k + 24 > len(b):
            return None
        a = _u32(b, k)
        cnt = _u32(b, k + 4)
        vstart = _u32(b, k + 8)
        vcnt = _u32(b, k + 12)
        if (
            cnt == 0
            or vcnt == 0
            or a != tri_start + tri_total
            or vstart != first_vs + vc_total
            or a + cnt > tot_tris
            or vstart + vcnt > tot_verts
        ):
            return None
        tri_total += cnt
        vc_total += vcnt
        if _u32(b, k + 16) == vc_total and _u32(b, k + 20) == first_vs:
            return tri_start, tri_total, first_vs, vc_total
        k += 24
    return None


def _collect_sub_cands(b: bytes) -> list[SubCand]:
    # The matrix bottom row [0,0,0,1] is a very selective byte signature and
    # bytes.find performs the scan in native code, avoiding a slow Python byte loop.
    sig = (b"\x00" * 12) + struct.pack("<f", 1.0)
    out: list[SubCand] = []
    start = 0
    while True:
        p = b.find(sig, start)
        if p < 0:
            break
        start = p + 1
        mb = p - 48
        if mb >= 0 and _read_mat4(b, mb) is not None:
            o = mb + SUB_MAT_BACK
            group = _read_sub_group(b, o, MAX_COUNT, MAX_COUNT)
            if group is not None:
                ts, tc, vs, vc = group
                out.append(SubCand(o, ts, tc, vs, vc))
    return out


def _chain_submeshes(
    b: bytes, cands: list[SubCand], iend: int, tot_tris: int, tot_verts: int
) -> list[RawSub] | None:
    valid = [
        c for c in cands
        if c.tri_start + c.tri_count <= tot_tris
        and c.vert_start + c.vert_count <= tot_verts
    ]
    starts = [c for c in valid if c.tri_start == 0 and c.vert_start == 0 and c.block_off >= iend]
    if not starts:
        return None
    current = min(starts, key=lambda c: c.block_off - iend)
    out: list[RawSub] = []
    run_t = 0
    run_v = 0
    prev_off = current.block_off
    while run_t < tot_tris:
        choices = [c for c in valid if c.tri_start == run_t and c.vert_start == run_v]
        if not choices:
            return None
        nxt = min(choices, key=lambda c: abs(c.block_off - prev_off))
        name = _read_cname(b, nxt.block_off - 252) if nxt.block_off >= 252 else ""
        out.append(RawSub(name, run_t, nxt.tri_count, nxt.block_off, nxt.vert_start, nxt.vert_count))
        run_t += nxt.tri_count
        run_v = nxt.vert_start + nxt.vert_count
        prev_off = nxt.block_off
    return out if run_t == tot_tris and run_v == tot_verts else None


def _detect_submeshes_window(
    b: bytes, iend: int, tot_tris: int, tot_verts: int
) -> list[RawSub]:
    end = min(len(b), iend + 200_000)
    cand: dict[int, list[tuple[int, int, int, int]]] = {}
    # Geometry blocks are word-sized even though the surrounding stream may be unaligned.
    for o in range(iend, max(iend, end - 23), 4):
        if o >= SUB_MAT_BACK and _read_mat4(b, o - SUB_MAT_BACK) is not None:
            group = _read_sub_group(b, o, tot_tris, tot_verts)
            if group is not None:
                a, cnt, vstart, vcnt = group
                cand.setdefault(a, []).append((o, cnt, vstart, vcnt))
    out: list[RawSub] = []
    run_t = 0
    run_v = 0
    while run_t < tot_tris:
        opts = cand.get(run_t)
        if not opts:
            break
        pick = next((x for x in opts if x[2] == run_v), opts[0])
        o, cnt, vstart, vcnt = pick
        name = _read_cname(b, o - 252) if o >= 252 else ""
        out.append(RawSub(name, run_t, cnt, o, vstart, vcnt))
        run_t += cnt
        run_v = vstart + vcnt
    return out


def _detect_submeshes(
    b: bytes, cands: list[SubCand], iend: int, tot_tris: int, tot_verts: int
) -> list[RawSub]:
    chained = _chain_submeshes(b, cands, iend, tot_tris, tot_verts)
    if chained is not None:
        return chained
    return _detect_submeshes_window(b, iend, tot_tris, tot_verts)


def _submesh_transform(b: bytes, name_off: int, block_off: int) -> list[np.ndarray]:
    chain: list[np.ndarray] = []
    base = block_off - SUB_MAT_BACK
    if base < 0:
        return chain
    m = _read_mat4(b, base)
    if m is None:
        return chain
    chain.append(m)
    k = base
    while True:
        p = k - SUB_MAT_PARENT_STEP
        if p < name_off + NODE_MAT_END:
            break
        pm = _read_mat4(b, p)
        if pm is None:
            break
        chain.append(pm)
        k = p
    return chain


def _read_node(
    b: bytes,
    cands: list[SubCand],
    vs: int,
    vc: int,
    raw_idx: np.ndarray,
    iend: int,
    raw_tris: int,
    name: str,
) -> EdfNode:
    positions = np.frombuffer(b, dtype="<f4", count=vc * 3, offset=vs).copy().reshape((-1, 3))
    uv_base = vs + vc * 12
    normal_base = vs + vc * 44
    uvs = np.frombuffer(b, dtype="<f4", count=vc * 2, offset=uv_base).copy().reshape((-1, 2))
    normals = np.frombuffer(b, dtype="<f4", count=vc * 3, offset=normal_base).copy().reshape((-1, 3))

    raw_subs = _detect_submeshes(b, cands, iend, raw_tris, vc)
    covers = bool(raw_subs) and sum(s.tri_count for s in raw_subs) == raw_tris

    placed_vert = np.zeros(vc, dtype=np.bool_)
    placed = False
    node_mat = _read_mat4(b, iend + NODE_MAT_OFF)
    if node_mat is not None:
        placed = True
        ranges: list[tuple[slice, list[np.ndarray]]]
        if not raw_subs:
            ranges = [(slice(0, vc), [])]
        else:
            ranges = [
                (slice(s.vert_start, min(vc, s.vert_start + s.vert_count)), _submesh_transform(b, iend, s.block_off))
                for s in raw_subs
            ]
        for sl, chain in ranges:
            start = sl.start or 0
            stop = sl.stop or vc
            if stop <= start:
                continue
            placed_vert[start:stop] = True
            pos = positions[start:stop]
            nrm = normals[start:stop]
            for m in chain:
                pos = _apply_mat_points(pos, m)
                nrm = _apply_mat_dirs(nrm, m)
            positions[start:stop] = _apply_mat_points(pos, node_mat)
            normals[start:stop] = _apply_mat_dirs(nrm, node_mat)

    tris = raw_idx.reshape((-1, 3))
    nondeg = (tris[:, 0] != tris[:, 1]) & (tris[:, 1] != tris[:, 2]) & (tris[:, 0] != tris[:, 2])
    if placed:
        nondeg &= placed_vert[tris].all(axis=1)

    if covers:
        # Keep original triangle order. The viewer doesn't need submesh material ranges yet.
        keep = nondeg
    else:
        keep = nondeg
    indices = tris[keep].copy().astype(np.uint32, copy=False)
    return EdfNode(name, positions, uvs, normals, indices, placed)


def _candidate_vertex_offsets(b: bytes) -> list[int]:
    # EDF records can begin unaligned after compressed texture blobs. Scan all four
    # possible uint32 alignments with NumPy (native-speed) instead of Python byte-by-byte.
    out: list[int] = []
    n = len(b)
    for base in range(HEADER_START, min(HEADER_START + 4, n)):
        usable = ((n - base) // 4) * 4
        if usable <= 0:
            continue
        words = np.frombuffer(b, dtype="<u4", count=usable // 4, offset=base)
        idx = np.flatnonzero((words >= 8) & (words <= MAX_COUNT))
        if idx.size:
            out.extend((base + idx.astype(np.int64) * 4).tolist())
    out.sort()
    return out


def _level0_only(nodes: list[EdfNode]) -> list[EdfNode]:
    def base_name(name: str) -> str:
        first_digit = next((i for i, c in enumerate(name) if c.isdigit()), None)
        if first_digit is not None and first_digit >= 1 and name[first_digit - 1] in "bc":
            return name[: first_digit - 1] + name[first_digit:]
        if first_digit is None and len(name) > 1 and name[-1] in "bc":
            return name[:-1]
        return name

    best: dict[str, EdfNode] = {}
    for node in nodes:
        key = base_name(node.name)
        old = best.get(key)
        if old is None:
            best[key] = node
            continue
        node_l0 = node.name == key
        old_l0 = old.name == key
        if (node_l0 and not old_l0) or (node_l0 == old_l0 and len(node.indices) > len(old.indices)):
            best[key] = node
    wanted_ids = {id(v) for v in best.values()}
    return [n for n in nodes if id(n) in wanted_ids]


def parse_edf_bytes(b: bytes) -> list[EdfNode]:
    if len(b) < HEADER_START + 8 or b[:4] != b"EDF\0":
        raise EdfPreviewError("Not a supported MX Bikes EDF file (missing EDF header).")
    cands = _collect_sub_cands(b)
    nodes: list[EdfNode] = []
    skip_to = HEADER_START

    for o in _candidate_vertex_offsets(b):
        if o < skip_to or o + 8 > len(b):
            continue
        vc = _u32(b, o)
        vs = o + 4
        if not (8 <= vc <= MAX_COUNT) or vs + vc * STRIDE + 8 > len(b):
            continue
        sample_ids = [0, 1, 2, vc // 2, vc - 1]
        good = True
        for i in sample_ids:
            vals = np.frombuffer(b, dtype="<f4", count=3, offset=vs + i * 12)
            if not np.isfinite(vals).all() or np.max(np.abs(vals)) >= 200.0:
                good = False
                break
        if not good:
            continue

        ic = vs + vc * STRIDE
        tc = _u32(b, ic)
        if not (1 <= tc <= MAX_COUNT) or ic + 8 + tc * 12 > len(b):
            continue
        raw_idx = np.frombuffer(b, dtype="<u4", count=tc * 3, offset=ic + 4)
        if raw_idx.size != tc * 3 or int(raw_idx.max(initial=0)) >= vc:
            continue
        iend = ic + 8 + tc * 12
        name = _plausible_name(b, iend)
        if name is None:
            continue
        try:
            node = _read_node(b, cands, vs, vc, raw_idx.copy(), iend, tc, name)
        except (ValueError, struct.error, OverflowError):
            continue
        if len(node.indices):
            nodes.append(node)
        skip_to = iend

    if not nodes:
        raise EdfPreviewError("No renderable mesh nodes were found in this EDF file.")
    return _level0_only(nodes)


def _parse_geom_vectors(text: str) -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}
    for line in text.splitlines():
        line = line.split(";", 1)[0].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        try:
            nums = [float(x.strip()) for x in value.split(",")]
        except ValueError:
            continue
        if len(nums) == 3:
            out[key.strip().lower()] = np.asarray(nums, dtype=np.float32)
    return out


def _parse_geom_scalars(text: str) -> dict[str, float]:
    out: dict[str, float] = {}
    for line in text.splitlines():
        line = line.split(";", 1)[0].strip()
        if "=" not in line:
            continue
        key, value = line.split("=", 1)
        try:
            nums = [float(x.strip()) for x in value.split(",")]
        except ValueError:
            continue
        if len(nums) == 1:
            out[key.strip().lower()] = nums[0]
    return out


def _rot_x(points: np.ndarray, deg: float) -> np.ndarray:
    rad = math.radians(deg)
    s, c = math.sin(rad), math.cos(rad)
    out = points.copy()
    y = points[:, 1] * c - points[:, 2] * s
    z = points[:, 1] * s + points[:, 2] * c
    out[:, 1] = y
    out[:, 2] = z
    return out


def assemble_bike(nodes: list[EdfNode], geom_text: str) -> bool:
    g = _parse_geom_vectors(geom_text)
    sc = _parse_geom_scalars(geom_text)
    keys = ["chassis_steer", "chassis_rsusp_min", "steer_joint", "rsusp_joint", "front_upper"]
    if any(k not in g for k in keys):
        return False
    head = g["chassis_steer"]
    pivot = g["chassis_rsusp_min"]
    steer_joint = g["steer_joint"]
    rsusp_joint = g["rsusp_joint"]
    front_upper = g["front_upper"]
    rake = -float(sc.get("rakeangle_min", 0.0))

    def rotate_vec(v: np.ndarray) -> np.ndarray:
        return _rot_x(v.reshape((1, 3)), rake)[0]

    fork_origin = rotate_vec(front_upper - steer_joint) + head
    for node in nodes:
        if not node.placed:
            continue
        name = node.name.lower()
        if name.startswith("chassis"):
            continue
        if name.startswith("rsusp"):
            rot = 0.0
            off = pivot - rsusp_joint
        elif name.startswith("steer"):
            rot = rake
            off = head - rotate_vec(steer_joint)
        elif name.startswith("fsusp"):
            rot = rake
            off = fork_origin
        else:
            continue
        node.positions[:] = _rot_x(node.positions, rot) + off
        node.normals[:] = _rot_x(node.normals, rot)

    all_pos = np.concatenate([n.positions for n in nodes if len(n.positions)], axis=0)
    if not len(all_pos):
        return True
    center = (all_pos.min(axis=0) + all_pos.max(axis=0)) * 0.5
    for node in nodes:
        node.positions[:] -= center
    return True


def to_right_handed(nodes: Iterable[EdfNode]) -> None:
    for node in nodes:
        # DirectX left-handed -> right-handed.
        node.positions[:, 0] *= -1.0
        node.normals[:, 0] *= -1.0
        # Negating one coordinate reverses winding.
        if len(node.indices):
            node.indices[:, [1, 2]] = node.indices[:, [2, 1]]
        # MX Bikes authors +Y as up and +Z as forward. Rotate that frame into
        # PyVista's conventional +Z-up view: (x, y, z) -> (x, -z, y).
        p = node.positions.copy()
        n = node.normals.copy()
        node.positions[:, 0] = p[:, 0]
        node.positions[:, 1] = -p[:, 2]
        node.positions[:, 2] = p[:, 1]
        node.normals[:, 0] = n[:, 0]
        node.normals[:, 1] = -n[:, 2]
        node.normals[:, 2] = n[:, 1]


def find_geom_for_edf(edf_path: Path) -> Path | None:
    folder = edf_path.parent
    candidates = list(folder.glob("*.geom"))
    if not candidates:
        return None
    # Prefer the file that actually carries the bike mount points.
    for path in candidates:
        try:
            text = path.read_text(encoding="utf-8", errors="ignore").lower()
            if "chassis_steer" in text and "steer_joint" in text:
                return path
        except OSError:
            pass
    return candidates[0]


def resolve_reference_edf(
    explicit_edf: str | Path | None,
    donor_bike_dir: str | Path | None,
    bikes_dir: str | Path | None,
    keywords: tuple[str, ...] = ("kx450", "kx450f", "kxf450", "2023", "kawasaki"),
) -> Path | None:
    """Backward-compatible resolver retained for older callers/tests.

    v0.4.2 resolves OEM PKZ/ZIP/folder sources through ``resolve_reference_source``.
    This wrapper returns only a direct EDF when that is what was found.
    """
    source = resolve_reference_source(explicit_edf, explicit_edf, donor_bike_dir, bikes_dir, keywords)
    if source and source.is_file() and source.suffix.lower() == ".edf":
        return source
    if source and source.is_dir():
        model = source / "model.edf"
        if model.is_file():
            return model
        edfs = [p for p in source.glob("*.edf") if "shadow" not in p.name.lower()]
        if edfs:
            return edfs[0]
    return None


def _center_nodes(nodes: list[EdfNode]) -> None:
    chunks = [n.positions for n in nodes if len(n.positions)]
    if not chunks:
        return
    all_pos = np.concatenate(chunks, axis=0)
    center = (all_pos.min(axis=0) + all_pos.max(axis=0)) * 0.5
    for node in nodes:
        node.positions[:] -= center


def _is_real_edf_payload(data: bytes) -> bool:
    return len(data) >= 4 and data[:4] == b"EDF\0"


def _infer_bikes_root(source: Path) -> Path | None:
    """Find mods/bikes for an installed OEM source without needing another setting."""
    source = Path(source).expanduser()
    start = source if source.is_dir() else source.parent
    chain = [start, *start.parents]
    for folder in chain[:8]:
        if folder.name.lower() == "bikes":
            return folder
        if (folder / "OEM_Models").is_dir() or (folder / "OEM Models").is_dir():
            return folder
    return None


def _find_installed_oem_model_edf(source: Path, keywords: tuple[str, ...]) -> Path | None:
    """Resolve modern Project OEM visuals stored separately under OEM_Models/MX."""
    bikes = _infer_bikes_root(source)
    if bikes is None:
        return None
    roots = [
        bikes / "OEM_Models" / "MX",
        bikes / "OEM_Models",
        bikes / "OEM Models" / "MX",
        bikes / "OEM Models",
    ]
    roots = [p for p in roots if p.is_dir()]
    if not roots:
        return None

    normalized = [k.lower().replace("-", "_").replace(" ", "_") for k in keywords if k]
    source_hint = source.stem.lower().replace("-", "_").replace(" ", "_")
    # Add useful tokens from the PKZ name but ignore generic OEM/class words.
    source_tokens = [t for t in re.split(r"[_\W]+", source_hint) if len(t) >= 3]
    ignore = {"oem", "mx1oem", "mx2oem", "kawasaki", "2023", "bike", "model"}
    source_tokens = [t for t in source_tokens if t not in ignore]

    candidates: list[Path] = []
    for root in roots:
        for path in root.rglob("*.edf"):
            try:
                if len(path.relative_to(root).parts) > 7:
                    continue
            except ValueError:
                continue
            low_name = path.name.lower()
            if any(tag in low_name for tag in ("shadow", "cockpit", "temp")):
                continue
            try:
                with path.open("rb") as fh:
                    if fh.read(4) != b"EDF\0":
                        continue
            except OSError:
                continue
            candidates.append(path)

    if not candidates:
        return None

    def score(path: Path) -> tuple[int, int]:
        text = path.as_posix().lower().replace("-", "_").replace(" ", "_")
        val = 0
        for kw in normalized:
            if kw and kw in text:
                val += 160 if any(ch.isdigit() for ch in kw) or "kx" in kw else 30
        for token in source_tokens:
            if token in text:
                val += 120
        if path.name.lower() == "model.edf":
            val += 80
        if "kx250" in text and any("450" in k for k in normalized):
            val -= 500
        return (val, -len(path.parts))

    return max(candidates, key=score)


def _select_edf_entries(entries: list[tuple[str, bytes]]) -> list[tuple[str, bytes]]:
    edfs = [
        (n, b) for n, b in entries
        if n.lower().endswith(".edf")
        and "shadow" not in Path(n).name.lower()
        and _is_real_edf_payload(b)
    ]
    if not edfs:
        return []

    # The normal OEM convention is one complete model.edf. Prefer it whenever it
    # exists so unrelated accessory EDFs are not accidentally rendered on top.
    models = [(n, b) for n, b in edfs if Path(n).name.lower() == "model.edf"]
    if models:
        return [min(models, key=lambda item: item[0].count("/"))]

    # Some bikes split the visual model one EDF per part and list those EDFs in an
    # HRC. Use those references if present; otherwise every non-shadow EDF is a
    # reasonable render candidate (matching the convention used by mxb-app).
    hrc_text = "\n".join(
        b.decode("utf-8", errors="ignore") for n, b in entries if n.lower().endswith(".hrc")
    )
    if hrc_text:
        refs = {Path(x).name.lower() for x in re.findall(r"[A-Za-z0-9_.-]+\.edf", hrc_text, flags=re.I)}
        chosen = [(n, b) for n, b in edfs if Path(n).name.lower() in refs]
        if chosen:
            return chosen
    return edfs


def _best_geom_text(entries: list[tuple[str, bytes]]) -> str:
    geoms = [(n, b) for n, b in entries if n.lower().endswith(".geom")]
    if not geoms:
        return ""
    decoded = [(n, b.decode("utf-8", errors="ignore")) for n, b in geoms]
    for _name, text in decoded:
        low = text.lower()
        if "chassis_steer" in low and "steer_joint" in low:
            return text
    return decoded[0][1]


def _finish_preview(
    nodes: list[EdfNode], source: Path, display_name: str, geom_text: str = "", geom_source: Path | None = None
) -> EdfPreview:
    if not nodes:
        raise EdfPreviewError("No renderable OEM bike mesh was found.")
    assembled = False
    if geom_text:
        try:
            assembled = assemble_bike(nodes, geom_text)
        except Exception:
            assembled = False
    if not assembled:
        _center_nodes(nodes)
    to_right_handed(nodes)
    return EdfPreview(source, geom_source, nodes, assembled, display_name)


def load_reference_preview(
    source: str | Path,
    keywords: tuple[str, ...] = ("kx450", "kx450f", "kxf450", "2023", "kawasaki"),
) -> EdfPreview:
    """Load a preview from a direct EDF, unpacked bike, OEM PKZ, or full OEM ZIP.

    For archives, only small setup files and EDF mesh bytes are read. The OEM package
    remains in place and is never modified or redistributed by the builder.
    """
    source = Path(source).expanduser()

    # Preserve direct-EDF behaviour, including same-folder .geom assembly.
    if source.is_file() and source.suffix.lower() == ".edf":
        return load_edf_preview(source)

    def keep(name: str) -> bool:
        low = name.lower()
        return low.endswith((".edf", ".geom", ".hrc", ".cfg", ".ini"))

    try:
        entries, info = read_selected_entries(source, keep, keywords)
    except OemSourceError as exc:
        raise EdfPreviewError(str(exc)) from exc

    selected = _select_edf_entries(entries)
    if not selected:
        # Current Project OEM packs can keep physics/identity in the per-bike PKZ and
        # store the actual visual model separately in mods/bikes/OEM_Models/MX.
        external = _find_installed_oem_model_edf(source, keywords)
        if external is not None:
            try:
                nodes = parse_edf_bytes(external.read_bytes())
            except (OSError, EdfPreviewError) as exc:
                raise EdfPreviewError(f"Project OEM model found at {external}, but it could not be read: {exc}") from exc
            geom_text = _best_geom_text(entries)
            return _finish_preview(nodes, external, external.parent.name, geom_text)
        bikes = _infer_bikes_root(source)
        expected = bikes / "OEM_Models" / "MX" if bikes else None
        suffix = f" Looked under {expected}." if expected else ""
        raise EdfPreviewError(
            f"{source.name} is the OEM bike/physics package, but its visual EDF is stored separately and was not found.{suffix}"
        )

    nodes: list[EdfNode] = []
    errors: list[str] = []
    for name, data in selected:
        try:
            parsed = parse_edf_bytes(data)
            # Prefix nodes on split bikes to avoid confusing duplicate actor keys while
            # preserving chassis/steer/fsusp/rsusp prefixes used by .geom placement.
            if len(selected) > 1:
                stem = Path(name).stem
                for node in parsed:
                    if not node.name.lower().startswith(("chassis", "steer", "fsusp", "rsusp")):
                        node.name = f"{stem}:{node.name}"
            nodes.extend(parsed)
        except EdfPreviewError as exc:
            errors.append(f"{Path(name).name}: {exc}")

    if not nodes:
        detail = errors[0] if errors else "No supported EDF geometry was found."
        raise EdfPreviewError(f"OEM package was found, but its bike mesh could not be read. {detail}")

    geom_text = _best_geom_text(entries)
    return _finish_preview(nodes, info.source, info.display_name, geom_text)


def load_edf_preview(edf_path: Path, geom_path: Path | None = None) -> EdfPreview:
    edf_path = Path(edf_path)
    if not edf_path.is_file():
        raise EdfPreviewError(f"model.edf not found: {edf_path}")
    data = edf_path.read_bytes()
    nodes = parse_edf_bytes(data)
    geom_path = geom_path or find_geom_for_edf(edf_path)
    geom_text = ""
    if geom_path and geom_path.is_file():
        try:
            geom_text = geom_path.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            geom_text = ""
    return _finish_preview(nodes, edf_path, edf_path.parent.name, geom_text, geom_path)

