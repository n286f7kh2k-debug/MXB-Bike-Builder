import os, shutil, threading, tkinter as tk, webbrowser, re
from pathlib import Path
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from .config import VERSION, APP_NAME, APPDATA, load_settings
from .database import (
    connect, seed, current_purse, payout_split, fastest_lap_pool,
    race_financials, wallet_balance, wallet_credit, wallet_debit, wallet_statement,
    register_with_wallet, setting_float
)
from .updater import check_for_update, download_update, launch_update
from .mx_agent import MXRaceAgent
from .track_media import TrackMediaResolver
from .pricing import apply_low_entry_pricing
from .subscriptions import (PLANS, ensure_subscription_schema, get_subscription, usage_today, member_quote,
                            record_member_use, activate_demo_subscription, cancel_auto_renew,
                            admin_membership_metrics)
from .commentary import CommentaryDirector
from .broadcast import WindowsVoiceAnnouncer, VoiceSettings
try:
    from PIL import Image, ImageTk
except Exception:
    Image = ImageTk = None

BG='#0b0d10'; PANEL='#15191e'; PANEL2='#1d232a'; TEXT='#f3f5f7'; MUTED='#98a2ad'
ACCENT='#0b84ff'; GOLD='#ffc247'; GREEN='#45d483'; RED='#ff5757'; LINE='#24303c'; BLUE='#20a8ff'

NAV = [
    ('MY PROFILE','PROFILE'),
    ('FIND A RACE','UPCOMING'),
    ('LIVE','LIVE'),
    ('RESULTS','RESULTS'),
    ('SERIES','CHAMPIONSHIPS'),
    ('RANKINGS','RANKINGS'),
    ('ADMIN','ADMIN'),
]

class RaceDayLiveApp(tk.Tk):
    def __init__(self):
        super().__init__(); seed(); self.conn=connect(); apply_low_entry_pricing(self.conn); ensure_subscription_schema(self.conn); self.settings=load_settings(); self.current_rider='Welchy'
        self.mx_agent=MXRaceAgent(connect,self.current_rider); self.track_media=TrackMediaResolver(connect)
        self.commentary_director=CommentaryDirector(); self.commentary_history=[]; self.commentary_last_event_id=0
        def _setting(key,default=''):
            row=self.conn.execute('SELECT value FROM admin_settings WHERE key=?',(key,)).fetchone(); return (row['value'] if row else default)
        voice_enabled=str(_setting('announcer_spoken_enabled','true')).lower()=='true'
        try:voice_rate=int(_setting('announcer_voice_rate','2'))
        except Exception:voice_rate=2
        self.announcer=WindowsVoiceAnnouncer(VoiceSettings(enabled=voice_enabled,rate=voice_rate,voice_name=_setting('announcer_voice_name','')))
        self._image_refs=[]; self._mx_sync_started=False; self.profile_section='OVERVIEW'; self.race_filter='ALL'; self.current_page='PROFILE'
        self.title(f'{APP_NAME}  v{VERSION}'); self.geometry('1480x900'); self.minsize(1180,760); self.configure(bg=BG)
        try:self.iconbitmap(os.path.join(os.path.dirname(os.path.dirname(__file__)),'assets','mxb_race_day_live.ico'))
        except Exception:pass
        self._styles(); self._layout(); self.show('PROFILE')
        self.protocol('WM_DELETE_WINDOW',self._on_close)
        self.after(650,self._start_mx_sync)
        if self.settings.get('auto_check_updates'): self.after(1300,self._silent_update_check)

    def _styles(self):
        s=ttk.Style(self); s.theme_use('clam')
        s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=TEXT,rowheight=34,bordercolor=LINE,font=('Segoe UI',10))
        s.configure('Treeview.Heading',background=PANEL2,foreground=TEXT,font=('Segoe UI Semibold',10),relief='flat')
        s.map('Treeview',background=[('selected','#2d3944')])
        s.configure('TNotebook',background=BG,borderwidth=0); s.configure('TNotebook.Tab',padding=(14,8))

    def _layout(self):
        header=tk.Frame(self,bg=BG,height=74); header.pack(fill='x'); header.pack_propagate(False)
        brand=tk.Frame(header,bg=BG); brand.pack(side='left',padx=24)
        tk.Label(brand,text='MXB',fg=TEXT,bg=BG,font=('Segoe UI Black',26,'italic')).pack(side='left')
        tk.Label(brand,text=' RACE DAY',fg=TEXT,bg=BG,font=('Segoe UI Black',22)).pack(side='left')
        tk.Label(brand,text=' LIVE',fg=ACCENT,bg=BG,font=('Segoe UI Black',22,'italic')).pack(side='left')
        self.update_btn=tk.Button(header,text='UPDATE',command=self.do_update,bg=ACCENT,fg='white',activebackground='#ff7a30',relief='flat',font=('Segoe UI Semibold',10),padx=18,pady=8,cursor='hand2'); self.update_btn.pack(side='right',padx=24,pady=18)
        tk.Label(header,text=f'v{VERSION}',fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(side='right')
        tk.Frame(self,bg=ACCENT,height=3).pack(fill='x')
        body=tk.Frame(self,bg=BG); body.pack(fill='both',expand=True)
        self.nav=tk.Frame(body,bg='#101318',width=205); self.nav.pack(side='left',fill='y'); self.nav.pack_propagate(False)
        self.nav_buttons={}
        for label,page in NAV:
            if page=='ADMIN' and not self.is_admin():
                continue
            b=tk.Button(self.nav,text=label,anchor='w',command=lambda p=page:self.show(p),bg='#101318',fg=TEXT,activebackground=PANEL2,activeforeground='white',relief='flat',font=('Segoe UI Semibold',10),padx=22,pady=14,cursor='hand2')
            b.pack(fill='x',pady=1); self.nav_buttons[page]=b
        tk.Frame(self.nav,bg=LINE,height=1).pack(fill='x',padx=18,pady=15)
        tk.Label(self.nav,text='RACE DAY STATUS',fg=MUTED,bg='#101318',font=('Segoe UI Semibold',8)).pack(anchor='w',padx=22)
        self.mx_status_label=tk.Label(self.nav,text='● SYNCING MX BIKES…',fg=GOLD,bg='#101318',font=('Segoe UI Semibold',9),wraplength=165,justify='left')
        self.mx_status_label.pack(anchor='w',padx=22,pady=(8,3))
        self.mx_counts_label=tk.Label(self.nav,text='Game content: scanning',fg=MUTED,bg='#101318',font=('Segoe UI',8),wraplength=165,justify='left')
        self.mx_counts_label.pack(anchor='w',padx=22,pady=(0,6))
        tk.Label(self.nav,text='Payments: DEMO MODE',fg=MUTED,bg='#101318',font=('Segoe UI',8)).pack(anchor='w',padx=22)
        self.content=tk.Frame(body,bg=BG); self.content.pack(side='left',fill='both',expand=True)

    def clear(self):
        try:self.unbind_all('<MouseWheel>')
        except Exception:pass
        for w in self.content.winfo_children():w.destroy()
        self._image_refs=[]
    def show(self,name):
        if name=='ADMIN' and not self.is_admin():
            name='PROFILE'
        self.current_page=name
        self.clear()
        for n,b in self.nav_buttons.items():b.configure(bg=PANEL2 if n==name else '#101318',fg=ACCENT if n==name else TEXT)
        getattr(self,'page_'+name.lower().replace(' ','_'))()
    def titlebar(self,title,sub=''):
        f=tk.Frame(self.content,bg=BG); f.pack(fill='x',padx=28,pady=(24,16))
        tk.Label(f,text=title,fg=TEXT,bg=BG,font=('Segoe UI Black',24)).pack(anchor='w')
        if sub:tk.Label(f,text=sub,fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=1100,justify='left').pack(anchor='w',pady=(3,0))
        return f
    def card(self,parent):return tk.Frame(parent,bg=PANEL,highlightbackground=LINE,highlightthickness=1)
    def stat(self,parent,label,value,accent=False):
        c=self.card(parent); c.pack(side='left',fill='both',expand=True,padx=5)
        tk.Label(c,text=label,fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=16,pady=(14,2))
        tk.Label(c,text=value,fg=GOLD if accent else TEXT,bg=PANEL,font=('Segoe UI Black',20)).pack(anchor='w',padx=16,pady=(0,14))
    def rider(self):return self.conn.execute('SELECT * FROM riders WHERE username=?',(self.current_rider,)).fetchone()
    def is_admin(self):
        r=self.rider(); return bool(r and str(r['role']).upper() in ('OWNER','ADMIN'))
    def overall_rank(self,rider=None):
        rider=rider or self.rider()
        return self.conn.execute('SELECT COUNT(*)+1 FROM riders WHERE skill_rating>?',(rider['skill_rating'],)).fetchone()[0]
    def etiquette_text(self,rider=None):
        rider=rider or self.rider()
        names={'S':'ELITE','A':'CLEAN','B':'GOOD','C':'WATCH','D':'POOR','F':'RESTRICTED'}
        return names.get((rider['racecraft_grade'] or '').upper(),'UNRATED')
    def eligible(self,race,rider=None):
        rider=rider or self.rider()
        return race['min_skill']<=rider['skill_rating']<=race['max_skill'] and rider['racecraft_score']>=race['min_racecraft']

    def _load_profile_photo(self,path,size):
        if not path or not Path(path).exists() or Image is None or ImageTk is None:
            return None
        try:
            from PIL import ImageOps
            with Image.open(path) as im:
                im=im.convert('RGB')
                im=ImageOps.fit(im,size,method=Image.Resampling.LANCZOS)
                im.load()
                photo=ImageTk.PhotoImage(im.copy())
            self._image_refs.append(photo)
            return photo
        except Exception:
            return None

    def _store_profile_image(self,source,rider_id,kind):
        source=Path(source)
        target_dir=APPDATA/'profile_media'/f'rider_{rider_id}'
        target_dir.mkdir(parents=True,exist_ok=True)
        target=target_dir/f'{kind}.png'
        if Image is None:
            shutil.copy2(source,target)
            return str(target)
        from PIL import ImageOps
        target_size=(640,640) if kind=='avatar' else (1800,520)
        with Image.open(source) as im:
            im=im.convert('RGB')
            # Store normalized media so JPEG/WebP/GIF/huge phone photos all render the same way.
            im=ImageOps.fit(im,target_size,method=Image.Resampling.LANCZOS)
            im.save(target,'PNG',optimize=True)
        return str(target)

    def _profile_avatar(self,parent,rider,size=108):
        accent=(rider['profile_accent'] or ACCENT) if 'profile_accent' in rider.keys() else ACCENT
        wrap=tk.Frame(parent,bg=PANEL,width=size,height=size,highlightbackground=accent,highlightthickness=3)
        wrap.pack_propagate(False)
        photo=self._load_profile_photo((rider['avatar_path'] or '').strip(),(size,size))
        if photo:
            tk.Label(wrap,image=photo,bg=PANEL).pack(fill='both',expand=True)
            return wrap
        canvas=tk.Canvas(wrap,width=size,height=size,bg=PANEL,highlightthickness=0); canvas.pack(fill='both',expand=True)
        canvas.create_oval(8,8,size-8,size-8,fill=PANEL2,outline=accent,width=3)
        initials=''.join(x[0] for x in rider['username'].split()[:2]).upper() or '?'
        canvas.create_text(size/2,size/2,text=initials,fill=TEXT,font=('Segoe UI Black',28))
        return wrap

    def _profile_header(self,rider):
        accent=(rider['profile_accent'] or ACCENT) if 'profile_accent' in rider.keys() else ACCENT
        header=self.card(self.content); header.pack(fill='x',padx=28,pady=(24,10))
        banner=tk.Frame(header,bg='#0e1115',height=190); banner.pack(fill='x'); banner.pack_propagate(False)
        banner_photo=self._load_profile_photo((rider['banner_path'] or '').strip(),(1180,190)) if 'banner_path' in rider.keys() else None
        if banner_photo:
            tk.Label(banner,image=banner_photo,bg='#0e1115').pack(fill='both',expand=True)
        else:
            can=tk.Canvas(banner,bg='#0e1115',highlightthickness=0); can.pack(fill='both',expand=True)
            can.create_rectangle(0,0,1800,190,fill='#11161c',outline='')
            for x in range(-200,1900,130): can.create_polygon(x,190,x+260,0,x+330,0,x+70,190,fill='#171d24',outline='')
            can.create_text(28,32,text='MXB RACE DAY LIVE',anchor='nw',fill='#3b4652',font=('Segoe UI Black',25,'italic'))
        identity=tk.Frame(header,bg=PANEL); identity.pack(fill='x',padx=18,pady=14)
        avatar=self._profile_avatar(identity,rider,108); avatar.pack(side='left',padx=(0,18))
        info=tk.Frame(identity,bg=PANEL); info.pack(side='left',fill='x',expand=True)
        name_row=tk.Frame(info,bg=PANEL); name_row.pack(fill='x')
        tk.Label(name_row,text=rider['username'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',28)).pack(side='left')
        tk.Label(name_row,text=f"  ◆ #{self.overall_rank(rider)}",fg=GOLD,bg=PANEL,font=('Segoe UI Black',11)).pack(side='left',pady=(9,0))
        meta=[f"#{rider['number']}" if rider['number'] else '',rider['team'] or '',rider['bike_model'] or '',rider['region'] or '']
        tk.Label(info,text='  •  '.join(x for x in meta if x),fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',10)).pack(anchor='w',pady=(2,9))
        badges=tk.Frame(info,bg=PANEL); badges.pack(anchor='w')
        for title,value,color in (
            ('SKILL STATUS',f"{rider['skill_class'].upper()}  •  {rider['skill_rating']} MMR",GOLD),
            ('ETIQUETTE',f"{rider['racecraft_grade']}  •  {self.etiquette_text(rider)}  •  {rider['racecraft_score']}",GREEN if rider['racecraft_score']>=800 else GOLD),
        ):
            box=tk.Frame(badges,bg=PANEL2,highlightbackground=LINE,highlightthickness=1); box.pack(side='left',padx=(0,8))
            tk.Label(box,text=title,fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',7)).pack(anchor='w',padx=10,pady=(6,0))
            tk.Label(box,text=value,fg=color,bg=PANEL2,font=('Segoe UI Black',10)).pack(anchor='w',padx=10,pady=(0,6))
        return header

    def _set_profile_section(self,section):
        self.profile_section=section
        self.show('PROFILE')

    def _profile_subnav(self):
        row=tk.Frame(self.content,bg=BG); row.pack(fill='x',padx=28,pady=(0,12))
        for label,key in [('OVERVIEW','OVERVIEW'),('MY RACES','RACES'),('WALLET','WALLET'),('MEMBERSHIP','MEMBERSHIP'),('PROFILE SETTINGS','SETTINGS')]:
            active=self.profile_section==key
            tk.Button(row,text=label,command=lambda k=key:self._set_profile_section(k),bg=ACCENT if active else PANEL2,fg='white' if active else TEXT,activebackground=ACCENT,activeforeground='white',relief='flat',font=('Segoe UI Black' if active else 'Segoe UI Semibold',9),padx=16,pady=8,cursor='hand2').pack(side='left',padx=(0,6))

    def _bind_click_recursive(self, widget, callback):
        try:
            widget.configure(cursor='hand2')
        except Exception:
            pass
        widget.bind('<Button-1>',lambda e:callback())
        for child in widget.winfo_children():
            self._bind_click_recursive(child,callback)

    def _scrollable(self, parent, padx=28, pady=(0,24)):
        outer=tk.Frame(parent,bg=BG); outer.pack(fill='both',expand=True,padx=padx,pady=pady)
        canvas=tk.Canvas(outer,bg=BG,highlightthickness=0)
        bar=ttk.Scrollbar(outer,orient='vertical',command=canvas.yview)
        canvas.configure(yscrollcommand=bar.set); bar.pack(side='right',fill='y'); canvas.pack(side='left',fill='both',expand=True)
        inner=tk.Frame(canvas,bg=BG); win=canvas.create_window((0,0),window=inner,anchor='nw')
        inner.bind('<Configure>',lambda e:canvas.configure(scrollregion=canvas.bbox('all')))
        canvas.bind('<Configure>',lambda e:canvas.itemconfigure(win,width=e.width))
        canvas.bind_all('<MouseWheel>',lambda e:canvas.yview_scroll(int(-1*(e.delta/120)),'units'))
        return inner

    def _load_track_tk(self, path, size=(330,186)):
        if not path or not Path(path).exists() or Image is None or ImageTk is None:
            return None
        try:
            with Image.open(path) as im:
                im=im.convert('RGB'); im.thumbnail(size,Image.Resampling.LANCZOS)
                canvas=Image.new('RGB',size,(21,25,30)); x=(size[0]-im.width)//2; y=(size[1]-im.height)//2; canvas.paste(im,(x,y))
                photo=ImageTk.PhotoImage(canvas)
            self._image_refs.append(photo); return photo
        except Exception:
            return None

    def _track_photo(self,parent,discipline,track,size=(330,186),on_click=None,on_resolved=None):
        wrap=tk.Frame(parent,bg='#0f1216',width=size[0],height=size[1],highlightbackground=LINE,highlightthickness=1)
        wrap.pack_propagate(False)
        label=tk.Label(wrap,text='MXB-SHOP TRACK PHOTO\nLOADING…',fg=MUTED,bg='#0f1216',font=('Segoe UI Semibold',9),justify='center')
        label.pack(fill='both',expand=True)
        if on_click:
            label.configure(cursor='hand2'); label.bind('<Button-1>',lambda e:on_click())
        def apply(media):
            try:
                if not label.winfo_exists(): return
            except Exception:
                return
            photo=self._load_track_tk(media.local_path,size)
            if photo:
                label.configure(image=photo,text='')
            elif media.status in ('ERROR','NOT_FOUND'):
                label.configure(text='MXB-SHOP TRACK PHOTO\nSOURCE RETRY AVAILABLE',fg=GOLD)
            if on_resolved:
                try:on_resolved(media)
                except Exception:pass
        cached=self.track_media.get_cached(discipline,track)
        if cached.status=='READY' and cached.local_path and Path(cached.local_path).exists():
            apply(cached)
        else:
            self.track_media.resolve_async(discipline,track,callback=lambda m:self.after(0,lambda:apply(m)))
        return wrap

    def _start_mx_sync(self):
        if self._mx_sync_started:
            return
        self._mx_sync_started=True
        self._run_mx_sync()

    def _run_mx_sync(self):
        if not self.winfo_exists(): return
        try:
            self.mx_status_label.configure(text='● SYNCING MX BIKES…',fg=GOLD)
        except Exception:
            pass
        def done(env):
            try:self.after(0,lambda:self._apply_mx_environment(env))
            except Exception:pass
        self.mx_agent.sync_async(done)
        try:
            interval=int(self.conn.execute("SELECT value FROM admin_settings WHERE key='mx_sync_interval_seconds'").fetchone()[0])
        except Exception:
            interval=60
        self.after(max(20,interval)*1000,self._run_mx_sync)

    def _apply_mx_environment(self,env):
        try:
            if env.found:
                self.mx_status_label.configure(text='● MX BIKES CONNECTED',fg=GREEN)
                self.mx_counts_label.configure(text=f"{env.tracks_found} tracks • {env.bikes_found} bikes\nProfile: {env.profile_name or 'detected'}")
            else:
                self.mx_status_label.configure(text='● MX BIKES NOT FOUND',fg=RED)
                self.mx_counts_label.configure(text=env.error or 'Install path not detected')
        except Exception:
            pass

    def _on_close(self):
        try:
            if self.mx_agent.live_client:self.mx_agent.live_client.stop()
        except Exception:
            pass
        try:self.announcer.stop()
        except Exception:pass
        try:self.conn.close()
        except Exception:pass
        self.destroy()

    # ---------- RIDER PROFILE ----------
    def page_profile(self):
        r=self.rider(); self._profile_header(r); self._profile_subnav()
        if self.profile_section=='RACES': return self._profile_my_races(r)
        if self.profile_section=='WALLET': return self._profile_wallet(r)
        if self.profile_section=='MEMBERSHIP': return self._profile_membership(r)
        if self.profile_section=='SETTINGS': return self._profile_settings(r)
        return self._profile_overview(r)

    def _profile_overview(self,r):
        top=tk.Frame(self.content,bg=BG); top.pack(fill='x',padx=23)
        self.stat(top,'WALLET',f"${wallet_balance(self.conn,r['id']):,.2f}",True)
        self.stat(top,'CAREER STARTS',f"{r['starts']}")
        self.stat(top,'WINS / PODIUMS',f"{r['wins']} / {r['podiums']}")
        self.stat(top,'CHAMPIONSHIPS',f"{r['championships']}")
        self.stat(top,'CAREER EARNINGS',f"${r['career_earnings']:,.0f}",True)
        body=tk.Frame(self.content,bg=BG); body.pack(fill='both',expand=True,padx=28,pady=16)
        left=tk.Frame(body,bg=BG); left.pack(side='left',fill='both',expand=True,padx=(0,7))
        right=tk.Frame(body,bg=BG); right.pack(side='left',fill='both',expand=True,padx=(7,0))

        nextcard=self.card(left); nextcard.pack(fill='x')
        tk.Label(nextcard,text='UPCOMING RACES',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,7))
        eligible=[x for x in self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY entry_fee,start_time") if self.eligible(x,r)]
        for race in eligible[:3]:
            paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id'])
            f=tk.Frame(nextcard,bg=PANEL2); f.pack(fill='x',padx=14,pady=4)
            tk.Label(f,text=f"{self.race_class_label(race)}  •  {race['track']}",fg=ACCENT,bg=PANEL2,font=('Segoe UI Black',9)).pack(anchor='w',padx=10,pady=(9,1))
            tk.Label(f,text=race['name'],fg=TEXT,bg=PANEL2,font=('Segoe UI Black',12)).pack(anchor='w',padx=10)
            tk.Label(f,text=f"${race['entry_fee']:.2f} entry  •  ${purse:,.0f} purse  •  ${fast:,.0f} fastest lap",fg=MUTED,bg=PANEL2,font=('Segoe UI',9)).pack(anchor='w',padx=10,pady=(2,9))
            self._bind_click_recursive(f,lambda rid=race['id']:self.open_race_details(rid))
        if not eligible: tk.Label(nextcard,text='No eligible races are open right now.',fg=MUTED,bg=PANEL,font=('Segoe UI',10)).pack(anchor='w',padx=16,pady=(2,14))
        tk.Button(nextcard,text='FIND A RACE',command=lambda:self.show('UPCOMING'),bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',10),pady=9,cursor='hand2').pack(fill='x',padx=14,pady=(10,14))

        about=self.card(left); about.pack(fill='x',pady=(12,0))
        tk.Label(about,text='RIDER CARD',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,5))
        tk.Label(about,text=r['bio'] or 'No bio yet. Add one in Profile Settings.',fg=TEXT,bg=PANEL,font=('Segoe UI',10),wraplength=540,justify='left').pack(anchor='w',padx=16,pady=(0,8))
        for lab,val in [('HOMETOWN',r['hometown'] or '—'),('FAVORITE TRACK',r['favorite_track'] or '—'),('SOCIAL',r['social_link'] or '—')]:
            tk.Label(about,text=f'{lab}:  {val}',fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=16,pady=2)
        tk.Button(about,text='CUSTOMIZE PROFILE',command=lambda:self._set_profile_section('SETTINGS'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),pady=8,cursor='hand2').pack(fill='x',padx=14,pady=14)

        hist=self.card(right); hist.pack(fill='both',expand=True)
        tk.Label(hist,text='RECENT RESULTS',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,7))
        rows=list(self.conn.execute('''SELECT rs.position,rs.payout,rs.fast_lap_bonus,rs.skill_delta,rc.name,rc.track FROM results rs JOIN races rc ON rc.id=rs.race_id WHERE rs.rider_id=? ORDER BY rc.start_time DESC LIMIT 6''',(r['id'],)))
        if not rows: tk.Label(hist,text='Completed race results will appear here automatically after MX Bikes sync.',fg=MUTED,bg=PANEL,font=('Segoe UI',10),wraplength=540,justify='left').pack(anchor='w',padx=16,pady=12)
        for x in rows:
            f=tk.Frame(hist,bg=PANEL2); f.pack(fill='x',padx=14,pady=4)
            tk.Label(f,text=f"P{x['position']}  {x['name']}",fg=TEXT,bg=PANEL2,font=('Segoe UI Semibold',10)).pack(anchor='w',padx=10,pady=(8,1))
            bonus=f"  •  +${x['fast_lap_bonus']:.0f} FAST LAP" if x['fast_lap_bonus'] else ''
            tk.Label(f,text=f"{x['track']}  •  ${x['payout']:.0f}{bonus}  •  MMR {x['skill_delta']:+d}",fg=GOLD,bg=PANEL2,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=10,pady=(0,8))
        tk.Button(hist,text='VIEW ALL MY RACES',command=lambda:self._set_profile_section('RACES'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),pady=8,cursor='hand2').pack(fill='x',padx=14,pady=14)

    def _profile_my_races(self,r):
        body=self._scrollable(self.content,pady=(0,24))
        tk.Label(body,text='MY RACES',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',pady=(4,2))
        tk.Label(body,text='Everything you have entered or completed, kept with your rider profile.',fg=MUTED,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=(0,12))
        upcoming=self.card(body); upcoming.pack(fill='x',pady=(0,12))
        tk.Label(upcoming,text='UPCOMING REGISTRATIONS',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(14,7))
        rows=list(self.conn.execute('''SELECT rc.*,rg.amount_paid,rg.signed_up_at FROM registrations rg JOIN races rc ON rc.id=rg.race_id WHERE rg.rider_id=? AND rc.status!='COMPLETE' ORDER BY rc.start_time''',(r['id'],)))
        if not rows: tk.Label(upcoming,text='You have no upcoming paid registrations.',fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=16,pady=(0,14))
        for race in rows:
            f=tk.Frame(upcoming,bg=PANEL2); f.pack(fill='x',padx=14,pady=4)
            tk.Label(f,text=race['name'],fg=TEXT,bg=PANEL2,font=('Segoe UI Black',11)).pack(side='left',padx=10,pady=11)
            tk.Label(f,text=f"{race['track']}  •  {datetime.fromisoformat(race['start_time']).strftime('%b %d %I:%M %p')}  •  PAID ${race['amount_paid']:.2f}",fg=GOLD,bg=PANEL2,font=('Segoe UI Semibold',9)).pack(side='right',padx=10)
        completed=self.card(body); completed.pack(fill='x')
        tk.Label(completed,text='RACE HISTORY',fg=TEXT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(14,7))
        cols=('Finish','Race','Track','Best Lap','Prize','Fast Lap','MMR'); t=ttk.Treeview(completed,columns=cols,show='headings',height=10)
        for c in cols:t.heading(c,text=c); t.column(c,width=140 if c!='Race' else 260,anchor='center')
        for x in self.conn.execute('''SELECT rs.*,rc.name,rc.track FROM results rs JOIN races rc ON rc.id=rs.race_id WHERE rs.rider_id=? ORDER BY rc.start_time DESC''',(r['id'],)):
            t.insert('', 'end',values=(f"P{x['position']}",x['name'],x['track'],x['best_lap'] or '—',f"${x['payout']:.2f}",f"${x['fast_lap_bonus']:.2f}" if x['fast_lap_bonus'] else '—',f"{x['skill_delta']:+d}"))
        t.pack(fill='x',padx=14,pady=(0,14))

    def _profile_wallet(self,r):
        body=self._scrollable(self.content,pady=(0,24))
        hero=self.card(body); hero.pack(fill='x',pady=(0,12))
        top=tk.Frame(hero,bg=PANEL); top.pack(fill='x',padx=18,pady=18)
        tk.Label(top,text='RACE WALLET',fg=MUTED,bg=PANEL,font=('Segoe UI Black',10)).pack(anchor='w')
        tk.Label(top,text=f"${wallet_balance(self.conn,r['id']):,.2f}",fg=GOLD,bg=PANEL,font=('Segoe UI Black',38)).pack(anchor='w')
        tk.Label(top,text='Available for race entries',fg=TEXT,bg=PANEL,font=('Segoe UI Semibold',10)).pack(anchor='w')
        quick=tk.Frame(top,bg=PANEL); quick.pack(anchor='w',pady=(14,0))
        for amt in (10,25,50,100):
            tk.Button(quick,text=f'+ ${amt}',command=lambda a=amt:self._wallet_quick_add(a),bg=ACCENT if amt==25 else PANEL2,fg='white' if amt==25 else TEXT,relief='flat',font=('Segoe UI Black',9),padx=14,pady=8,cursor='hand2').pack(side='left',padx=(0,6))
        tk.Button(quick,text='CUSTOM AMOUNT',command=self.add_funds_dialog,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=14,pady=8,cursor='hand2').pack(side='left')
        tk.Label(hero,text='No-refund race entry policy: once a race entry is purchased, it is final except where mandatory law or payment-network rules require otherwise. Wallet funding is in DEMO MODE until an approved real-money provider is connected.',fg=MUTED,bg=PANEL,font=('Segoe UI',8),wraplength=1050,justify='left').pack(anchor='w',padx=18,pady=(0,16))
        statement=self.card(body); statement.pack(fill='x')
        tk.Label(statement,text='WALLET ACTIVITY',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,7))
        cols=('Date','Activity','Race','Amount','Balance'); t=ttk.Treeview(statement,columns=cols,show='headings',height=12)
        for c,w in [('Date',170),('Activity',150),('Race',330),('Amount',120),('Balance',120)]:t.heading(c,text=c); t.column(c,width=w,anchor='w' if c in ('Activity','Race') else 'center')
        for x in wallet_statement(self.conn,r['id'],100):
            try: dt=datetime.fromisoformat(x['created_at']).strftime('%b %d, %Y %I:%M %p')
            except Exception: dt=x['created_at']
            t.insert('', 'end',values=(dt,x['kind'].replace('_',' ').title(),x['race_name'] or x['note'] or '—',f"{x['amount_cents']/100:+.2f}",f"${x['balance_after_cents']/100:.2f}"))
        t.pack(fill='x',padx=14,pady=(0,14))

    def _wallet_quick_add(self,amount):
        r=self.rider()
        try:
            wallet_credit(self.conn,r['id'],float(amount),kind='TOP_UP',provider='DEMO',note='Demo wallet top-up')
            self._set_profile_section('WALLET')
        except Exception as e: messagebox.showerror('Race Wallet',str(e))


    def _profile_membership(self,r):
        body=self._scrollable(self.content,pady=(0,24))
        sub=get_subscription(self.conn,r['id']); used=usage_today(self.conn,r['id'])
        tk.Label(body,text='RACE MEMBERSHIP',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',pady=(4,2))
        tk.Label(body,text='Save on Community races with automatic daily limits. Cash and Premier events always keep their normal entry price.',fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=1050,justify='left').pack(anchor='w',pady=(0,12))
        status=self.card(body); status.pack(fill='x',pady=(0,12))
        if sub and sub.get('active') and sub.get('plan'):
            plan=sub['plan']; remaining=max(0,int(plan['daily_races'])-used)
            tk.Label(status,text=f"{plan['name'].upper()} • ACTIVE",fg=GREEN,bg=PANEL,font=('Segoe UI Black',14)).pack(anchor='w',padx=16,pady=(14,3))
            tk.Label(status,text=f"${plan['monthly_price']:.2f}/month  •  Community ${plan['community_price']:.2f}  •  {remaining}/{plan['daily_races']} member-priced races remaining today",fg=TEXT,bg=PANEL,font=('Segoe UI Semibold',10)).pack(anchor='w',padx=16,pady=(0,4))
            try: renewal=datetime.fromisoformat(sub['current_period_end']).strftime('%b %d, %Y')
            except Exception: renewal=sub.get('current_period_end','—')
            renew='AUTO-RENEW ON' if int(sub.get('auto_renew') or 0) else 'AUTO-RENEW OFF'
            tk.Label(status,text=f"{renew}  •  Current period through {renewal}  •  Provider: {sub.get('provider') or 'NOT CONNECTED'}",fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=16,pady=(0,10))
            if int(sub.get('auto_renew') or 0):
                tk.Button(status,text='TURN OFF AUTO-RENEW',command=lambda:self._cancel_membership_renewal(r['id']),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=8,cursor='hand2').pack(anchor='w',padx=16,pady=(0,14))
        else:
            tk.Label(status,text='NO ACTIVE MEMBERSHIP',fg=MUTED,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,3))
            tk.Label(status,text='Pick a plan below. Membership discounts are enforced automatically at race signup.',fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=16,pady=(0,14))

        plans=tk.Frame(body,bg=BG); plans.pack(fill='x')
        for key in ('PIT','RACE','FACTORY'):
            plan=PLANS[key]
            card=self.card(plans); card.pack(side='left',fill='both',expand=True,padx=(0,8) if key!='FACTORY' else 0)
            tk.Label(card,text=plan['name'].upper(),fg=ACCENT if key!='FACTORY' else GOLD,bg=PANEL,font=('Segoe UI Black',14)).pack(anchor='w',padx=16,pady=(15,2))
            tk.Label(card,text=f"${plan['monthly_price']:.2f} / MONTH",fg=TEXT,bg=PANEL,font=('Segoe UI Black',20)).pack(anchor='w',padx=16)
            tk.Label(card,text=f"{plan['daily_races']} discounted Community race{'s' if plan['daily_races']!=1 else ''} per day",fg=TEXT,bg=PANEL,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=16,pady=(8,2))
            tk.Label(card,text=f"Member Community entry: ${plan['community_price']:.2f}",fg=GREEN,bg=PANEL,font=('Segoe UI Black',10)).pack(anchor='w',padx=16,pady=2)
            tk.Label(card,text='After the daily allowance: normal $3 Community price. Cash/Premier: normal price.',fg=MUTED,bg=PANEL,font=('Segoe UI',8),wraplength=290,justify='left').pack(anchor='w',padx=16,pady=(2,10))
            active=bool(sub and sub.get('active') and sub.get('plan_key')==key)
            label='CURRENT PLAN' if active else ('SWITCH TO '+plan['name'].upper() if sub and sub.get('active') else 'ACTIVATE DEMO '+plan['name'].upper())
            tk.Button(card,text=label,state='disabled' if active else 'normal',command=lambda k=key:self._activate_membership_demo(r['id'],k),bg=GREEN if active else ACCENT,fg='white',relief='flat',font=('Segoe UI Black',9),pady=9,cursor='hand2').pack(fill='x',padx=14,pady=(2,14))

        note=self.card(body); note.pack(fill='x',pady=(12,0))
        tk.Label(note,text='AUTOMATION STATUS',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',11)).pack(anchor='w',padx=16,pady=(14,5))
        tk.Label(note,text='Daily member limits, member pricing, wallet rebates, plan status, usage tracking and renewal periods are automatic. The app wallet and membership billing are still in DEMO MODE until a real recurring-payment provider is connected; production billing will use the provider fields already built into this system.',fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=1040,justify='left').pack(anchor='w',padx=16,pady=(0,14))

    def _activate_membership_demo(self,rider_id,plan_key):
        plan=PLANS[plan_key]
        if not messagebox.askyesno('Membership Demo',f"Activate {plan['name']} in DEMO billing mode?\n\nProduction recurring billing is not connected yet."):
            return
        activate_demo_subscription(self.conn,rider_id,plan_key)
        messagebox.showinfo('Membership',f"{plan['name']} is active in DEMO mode. Daily member pricing is now enforced automatically.")
        self._set_profile_section('MEMBERSHIP')

    def _cancel_membership_renewal(self,rider_id):
        cancel_auto_renew(self.conn,rider_id)
        messagebox.showinfo('Membership','Auto-renew is off. Membership remains active through the current period.')
        self._set_profile_section('MEMBERSHIP')

    def _profile_settings(self,r):
        body=self._scrollable(self.content,pady=(0,24))
        tk.Label(body,text='PROFILE SETTINGS',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',pady=(4,2))
        tk.Label(body,text='Customize how your rider profile looks and how MX Bikes identifies you. Verified race statistics, MMR and etiquette scores stay protected.',fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=1050,justify='left').pack(anchor='w',pady=(0,12))
        media=self.card(body); media.pack(fill='x',pady=(0,12))
        tk.Label(media,text='PROFILE MEDIA',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(14,6))
        choices={'avatar':r['avatar_path'] or '', 'banner':r['banner_path'] or ''}
        def choose(kind):
            src=filedialog.askopenfilename(title='Choose Profile Picture' if kind=='avatar' else 'Choose Profile Banner',filetypes=[('Images','*.png *.jpg *.jpeg *.webp *.gif *.bmp'),('All files','*.*')])
            if not src:return
            try:
                choices[kind]=self._store_profile_image(src,r['id'],kind)
                messagebox.showinfo('Profile Media',('Profile picture' if kind=='avatar' else 'Profile banner')+' selected. Click SAVE PROFILE to apply it.')
            except Exception as exc:messagebox.showerror('Profile Media',str(exc))
        media_btns=tk.Frame(media,bg=PANEL); media_btns.pack(fill='x',padx=16,pady=(0,14))
        for label,kind in [('CHANGE PROFILE PICTURE','avatar'),('CHANGE BANNER','banner')]:
            tk.Button(media_btns,text=label,command=lambda k=kind:choose(k),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=8,cursor='hand2').pack(side='left',padx=(0,7))
        tk.Button(media_btns,text='REMOVE PICTURE',command=lambda:choices.update(avatar=''),bg=PANEL2,fg=MUTED,relief='flat',font=('Segoe UI',8),padx=9,pady=8).pack(side='left',padx=(8,4))
        tk.Button(media_btns,text='REMOVE BANNER',command=lambda:choices.update(banner=''),bg=PANEL2,fg=MUTED,relief='flat',font=('Segoe UI',8),padx=9,pady=8).pack(side='left')

        form=self.card(body); form.pack(fill='x')
        tk.Label(form,text='RIDER INFORMATION',fg=TEXT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(14,8))
        grid=tk.Frame(form,bg=PANEL); grid.pack(fill='x',padx=16)
        fields={}
        field_defs=[('RIDER NAME','username',r['username']),('RACE NUMBER','number',str(r['number'] or '')),('TEAM','team',r['team'] or ''),('BIKE MODEL','bike_model',r['bike_model'] or ''),('BIKE SIZE','bike_size',r['bike_size'] or ''),('REGION','region',r['region'] or ''),('HOMETOWN','hometown',r['hometown'] or ''),('FAVORITE TRACK','favorite_track',r['favorite_track'] or ''),('SOCIAL / LINK','social_link',r['social_link'] or ''),('PROFILE ACCENT (HEX)','profile_accent',r['profile_accent'] or ACCENT),('STEAM ID','steam_id',r['steam_id'] or ''),('MX BIKES GUID','mx_guid',r['mx_guid'] or ''),('MX BIKES PROFILE','game_profile_name',r['game_profile_name'] or '')]
        for i,(label,key,value) in enumerate(field_defs):
            row=i//2; col=i%2
            cell=tk.Frame(grid,bg=PANEL); cell.grid(row=row,column=col,sticky='ew',padx=(0,10) if col==0 else (10,0),pady=5); grid.columnconfigure(col,weight=1)
            tk.Label(cell,text=label,fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',8)).pack(anchor='w')
            v=tk.StringVar(value=value); fields[key]=v
            tk.Entry(cell,textvariable=v,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI',10)).pack(fill='x',ipady=7,pady=(3,0))
        tk.Label(form,text='BIO',fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=16,pady=(10,3))
        bio=tk.Text(form,height=4,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI',10),wrap='word'); bio.pack(fill='x',padx=16); bio.insert('1.0',r['bio'] or '')
        status=self.conn.execute("SELECT value FROM game_sync_state WHERE key='last_sync'").fetchone()
        tk.Label(form,text=f"MX Bikes sync: {status['value'] if status else 'not synced yet'}",fg=GREEN if status else MUTED,bg=PANEL,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=16,pady=(10,2))
        def save_profile():
            name=fields['username'].get().strip()
            if not name:messagebox.showerror('Profile Settings','Rider name cannot be blank.'); return
            try:number=int(fields['number'].get().strip()) if fields['number'].get().strip() else None
            except Exception:messagebox.showerror('Profile Settings','Race number must be a whole number.'); return
            accent=fields['profile_accent'].get().strip()
            if not re.fullmatch(r'#[0-9a-fA-F]{6}',accent): messagebox.showerror('Profile Settings','Profile accent must be a 6-digit hex color such as #f26a21.'); return
            try:
                self.conn.execute('''UPDATE riders SET username=?,number=?,team=?,bike_model=?,bike_size=?,region=?,hometown=?,favorite_track=?,social_link=?,profile_accent=?,steam_id=?,mx_guid=?,game_profile_name=?,bio=?,avatar_path=?,banner_path=? WHERE id=?''',
                    (name,number,fields['team'].get().strip(),fields['bike_model'].get().strip(),fields['bike_size'].get().strip(),fields['region'].get().strip(),fields['hometown'].get().strip(),fields['favorite_track'].get().strip(),fields['social_link'].get().strip(),accent,fields['steam_id'].get().strip(),fields['mx_guid'].get().strip(),fields['game_profile_name'].get().strip(),bio.get('1.0','end').strip(),choices['avatar'],choices['banner'],r['id']))
                self.conn.commit()
            except Exception as exc: messagebox.showerror('Profile Settings',f'Could not save profile: {exc}'); return
            self.current_rider=name; self.mx_agent.current_username=name
            self.profile_section='OVERVIEW'; self.show('PROFILE')
        tk.Button(form,text='SAVE PROFILE',command=save_profile,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',10),pady=10,cursor='hand2').pack(fill='x',padx=16,pady=16)

    def add_funds_dialog(self):
        rider=self.rider(); dlg=tk.Toplevel(self); dlg.title('Add Money'); dlg.geometry('520x430'); dlg.configure(bg=BG); dlg.transient(self); dlg.grab_set()
        tk.Label(dlg,text='ADD MONEY',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',padx=24,pady=(24,4))
        tk.Label(dlg,text=f"Current balance  ${wallet_balance(self.conn,rider['id']):,.2f}",fg=GOLD,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',padx=24,pady=(0,14))
        amount=tk.StringVar(value='25.00'); quick=tk.Frame(dlg,bg=BG); quick.pack(fill='x',padx=20,pady=5)
        for v in (10,25,50,100,250):tk.Button(quick,text=f'${v}',command=lambda x=v:amount.set(f'{x:.2f}'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=10,pady=8).pack(side='left',padx=3)
        tk.Label(dlg,text='AMOUNT',fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=24,pady=(12,3))
        tk.Entry(dlg,textvariable=amount,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI Black',20)).pack(fill='x',padx=24,ipady=9)
        tk.Label(dlg,text='Fund once, then use the wallet for one-click race entries. Real deposits remain disabled until an approved payment provider is connected; this build uses demo funds.',fg=MUTED,bg=BG,font=('Segoe UI',9),wraplength=460,justify='left').pack(anchor='w',padx=24,pady=14)
        def add():
            try:val=round(float(amount.get().replace('$','').replace(',','').strip()),2); assert val>0
            except Exception:messagebox.showerror('Wallet','Enter a valid positive amount.',parent=dlg); return
            try:newbal=wallet_credit(self.conn,rider['id'],val,kind='TOP_UP',provider='DEMO',note='Demo wallet top-up')
            except Exception as exc:messagebox.showerror('Wallet',str(exc),parent=dlg); return
            dlg.destroy(); self.profile_section='WALLET'; self.show('PROFILE'); messagebox.showinfo('Wallet',f'Balance updated to ${newbal:,.2f}.')
        tk.Button(dlg,text='ADD TO WALLET',command=add,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',11),pady=11,cursor='hand2').pack(fill='x',padx=24)

    # ---------- FIND A RACE ----------
    def race_class_label(self,race):
        skill=str(race['skill_class']); bike=str(race['bike_class'])
        if skill=='Rookie': return '250 C' if '250' in bike else '450 C' if '450' in bike else 'C CLASS'
        if skill=='Amateur': return '250 B' if '250' in bike else '450 B' if '450' in bike else 'B CLASS'
        if skill=='Expert': return '250 PRO'
        if skill=='Pro': return '450 PRO'
        return skill.upper()

    def _set_race_filter(self,value):
        self.race_filter=value; self.show('UPCOMING')

    def page_upcoming(self):
        rider=self.rider(); body=self._scrollable(self.content,pady=(20,24))
        head=tk.Frame(body,bg=BG); head.pack(fill='x',pady=(0,14))
        tk.Label(head,text='FIND YOUR GATE',fg=TEXT,bg=BG,font=('Segoe UI Black',25)).pack(anchor='w')
        tk.Label(head,text='Pick the stakes you want. Low Entry races are just $3 at every skill level; higher-stakes Cash and Premier races are still available.',fg=MUTED,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=(2,10))
        wallet=tk.Frame(head,bg=PANEL,highlightbackground=LINE,highlightthickness=1); wallet.pack(fill='x')
        tk.Label(wallet,text='YOUR WALLET',fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',8)).pack(side='left',padx=(14,6),pady=11)
        tk.Label(wallet,text=f"${wallet_balance(self.conn,rider['id']):,.2f}",fg=GOLD,bg=PANEL,font=('Segoe UI Black',15)).pack(side='left',pady=8)
        tk.Button(wallet,text='ADD MONEY',command=self.add_funds_dialog,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',8),padx=10,pady=7,cursor='hand2').pack(side='right',padx=10,pady=7)
        filters=tk.Frame(body,bg=BG); filters.pack(fill='x',pady=(0,12))
        for lab,val in [('ALL RACES','ALL'),('LOW ENTRY','LOW ENTRY'),('CASH','CASH'),('PREMIER','PREMIER'),('MOTOCROSS','MX'),('SUPERCROSS','SX')]:
            active=self.race_filter==val
            tk.Button(filters,text=lab,command=lambda v=val:self._set_race_filter(v),bg=ACCENT if active else PANEL2,fg='white' if active else TEXT,relief='flat',font=('Segoe UI Black' if active else 'Segoe UI Semibold',8),padx=13,pady=8,cursor='hand2').pack(side='left',padx=(0,6))
        races=list(self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY entry_fee,start_time"))
        def keep(r):
            f=self.race_filter
            if f=='ALL':return True
            if f=='LOW ENTRY':return r['lobby_tier']=='Low Entry'
            if f in ('CASH','PREMIER'):return str(r['lobby_tier']).upper()==f
            return r['discipline']==f
        races=[r for r in races if keep(r)]
        races.sort(key=lambda x:(0 if self.eligible(x,rider) else 1,float(x['entry_fee']),x['start_time']))
        grid=tk.Frame(body,bg=BG); grid.pack(fill='x')
        if not races:tk.Label(grid,text='No open races match this filter.',fg=MUTED,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=20); return
        for i,race in enumerate(races):
            tile=self.card(grid); tile.grid(row=i//2,column=i%2,sticky='nsew',padx=6,pady=6); grid.columnconfigure(i%2,weight=1,uniform='races')
            top=tk.Frame(tile,bg=PANEL); top.pack(fill='x',padx=14,pady=(12,5))
            ok=self.eligible(race,rider); tag='LOW ENTRY' if race['lobby_tier']=='Low Entry' else str(race['lobby_tier']).upper()
            tk.Label(top,text=f"{self.race_class_label(race)}  •  {race['discipline']}  •  {tag}",fg=ACCENT if ok else MUTED,bg=PANEL,font=('Segoe UI Black',9)).pack(side='left')
            quote=member_quote(self.conn,rider['id'],race); price_text=(f"${quote['member_price']:.2f} MEMBER" if quote['eligible'] else f"${race['entry_fee']:.2f}")
            tk.Label(top,text=price_text,fg=GREEN if quote['eligible'] else GOLD,bg=PANEL,font=('Segoe UI Black',14)).pack(side='right')
            tk.Label(tile,text=race['name'],fg=TEXT if ok else MUTED,bg=PANEL,font=('Segoe UI Black',14),wraplength=480,justify='left').pack(anchor='w',padx=14)
            try: when=datetime.fromisoformat(race['start_time']).strftime('%a %b %d • %I:%M %p')
            except Exception: when=race['start_time']
            tk.Label(tile,text=f"{race['track']}  •  {when}",fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=14,pady=(2,7))
            photo=self._track_photo(tile,race['discipline'],race['track'],size=(520,170),on_click=lambda rid=race['id']:self.open_race_details(rid)); photo.pack(fill='x',padx=12,pady=(0,8))
            paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id'])
            purse_text=f'${purse:,.0f}'
            fast_text=f'${fast:,.0f}'
            if race['lobby_tier']=='Low Entry':
                display_riders=max(paid,int(race['min_riders']))
                display_purse=display_riders*float(race['prize_contribution'])
                display_fast=display_riders*float(race['fast_lap_contribution'] or 0)
                grow='+' if paid<int(race['max_riders']) else ''
                purse_text=f'${display_purse:,.0f}{grow}'
                fast_text=f'${display_fast:,.0f}{grow}'
            cash=tk.Frame(tile,bg=PANEL2); cash.pack(fill='x',padx=12,pady=(0,8))
            for lab,val,col in [('PURSE',purse_text,GOLD),('FASTEST LAP',fast_text,GREEN),('RIDERS',f"{paid}/{race['max_riders']}",TEXT)]:
                box=tk.Frame(cash,bg=PANEL2); box.pack(side='left',fill='x',expand=True,pady=9)
                tk.Label(box,text=lab,fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',7)).pack(); tk.Label(box,text=val,fg=col,bg=PANEL2,font=('Segoe UI Black',12)).pack()
            text='VIEW & ENTER' if ok else 'VIEW REQUIREMENTS'
            tk.Button(tile,text=text,command=lambda rid=race['id']:self.open_race_details(rid),bg=ACCENT if ok else PANEL2,fg='white' if ok else MUTED,relief='flat',font=('Segoe UI Black',9),pady=9,cursor='hand2').pack(fill='x',padx=12,pady=(0,12))

    def open_race_details(self,race_id):
        self.clear()
        for b in self.nav_buttons.values():b.configure(bg='#101318',fg=TEXT)
        race=self.conn.execute('SELECT * FROM races WHERE id=?',(race_id,)).fetchone()
        if not race:return self.show('UPCOMING')
        rider=self.rider(); ok=self.eligible(race,rider)
        head=self.titlebar(race['name'],f"{self.race_class_label(race)} • {race['discipline']} • {race['track']}")
        tk.Button(head,text='‹ BACK TO FIND A RACE',command=lambda:self.show('UPCOMING'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=7,cursor='hand2').pack(anchor='w',pady=(10,0))
        body=self._scrollable(self.content)
        hero=self.card(body); hero.pack(fill='x')
        photo=self._track_photo(hero,race['discipline'],race['track'],size=(1080,330)); photo.pack(fill='x',padx=14,pady=14)
        paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id']); payouts=[round(purse*x,2) for x in payout_split(paid)]
        money=tk.Frame(hero,bg=PANEL2); money.pack(fill='x',padx=14,pady=(0,12))
        vals=[('ENTRY',f"${race['entry_fee']:.2f}",TEXT),('MAIN PURSE',f"${purse:,.2f}",GOLD),('FASTEST LAP',f"${fast:,.2f}",GREEN),('RIDERS',f"{paid}/{race['max_riders']}",TEXT)]
        for lab,val,col in vals:
            f=tk.Frame(money,bg=PANEL2); f.pack(side='left',expand=True,fill='x',pady=11); tk.Label(f,text=lab,fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',7)).pack(); tk.Label(f,text=val,fg=col,bg=PANEL2,font=('Segoe UI Black',15)).pack()
        paytxt='  •  '.join(f"P{i+1} ${amt:,.2f}" for i,amt in enumerate(payouts)) if payouts else 'Payouts grow as paid riders enter.'
        tk.Label(hero,text=f"CURRENT PROJECTED PAYOUTS: {paytxt}\nFASTEST LAP BONUS: ${fast:,.2f} • FINAL PURSE LOCKS BEFORE THE GATE DROPS",fg=GOLD,bg=PANEL,font=('Segoe UI Semibold',9),justify='left').pack(anchor='w',padx=16,pady=(0,8))
        tk.Label(hero,text='ALL PAID RACE ENTRIES ARE FINAL • NO REFUNDS',fg=RED,bg=PANEL,font=('Segoe UI Black',9)).pack(anchor='w',padx=16,pady=(0,12))
        if not ok:tk.Label(hero,text=f"LOCKED — requires {race['min_skill']}–{race['max_skill']} MMR and Racecraft {race['min_racecraft']}+.",fg=RED,bg=PANEL,font=('Segoe UI Black',10)).pack(anchor='w',padx=16,pady=(0,12))
        roster=self.card(body); roster.pack(fill='x',pady=12)
        tk.Label(roster,text='SIGNED UP RIDERS',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(14,7))
        cols=('Rider','Bike','Size','Signed Up','Skill','Etiquette'); tree=ttk.Treeview(roster,columns=cols,show='headings',height=7)
        for c in cols:tree.heading(c,text=c); tree.column(c,width=150 if c!='Rider' else 210,anchor='center')
        for x in self.conn.execute('''SELECT rd.*,rg.signed_up_at FROM registrations rg JOIN riders rd ON rd.id=rg.rider_id WHERE rg.race_id=? AND rg.payment_status='PAID' ORDER BY rg.signed_up_at''',(race['id'],)):
            tree.insert('', 'end',values=(f"#{x['number']} {x['username']}",x['bike_model'],x['bike_size'],datetime.fromisoformat(x['signed_up_at']).strftime('%m/%d %I:%M %p'),f"{x['skill_class']} {x['skill_rating']}",f"{x['racecraft_grade']} {x['racecraft_score']}"))
        tree.pack(fill='x',padx=14,pady=(0,12))
        quote=member_quote(self.conn,rider['id'],race)
        already=self.conn.execute('SELECT 1 FROM registrations WHERE race_id=? AND rider_id=?',(race['id'],rider['id'])).fetchone()
        if already:text,state,color='✓ YOU ARE REGISTERED','disabled',GREEN
        elif ok and quote['eligible']:text,state,color=f"ENTER RACE • MEMBER ${quote['member_price']:.2f}",'normal',GREEN
        elif ok:text,state,color=f"ENTER RACE • ${race['entry_fee']:.2f}",'normal',ACCENT
        else:text,state,color='RACE LOCKED','disabled',LINE
        tk.Button(body,text=text,command=lambda:self.signup_demo(race),state=state,bg=color,fg='white',relief='flat',font=('Segoe UI Black',12),pady=12,cursor='hand2').pack(fill='x',pady=(0,14))

    def signup_demo(self,race):
        rider=self.rider()
        if self.conn.execute('SELECT 1 FROM registrations WHERE race_id=? AND rider_id=?',(race['id'],rider['id'])).fetchone(): messagebox.showinfo('Already Registered','You are already registered for this race.'); return
        if not self.eligible(race,rider): messagebox.showerror('Race Locked','Your current skill/etiquette rating does not qualify for this lobby.'); return
        quote=member_quote(self.conn,rider['id'],race); member_entry=quote['member_price'] if quote['eligible'] else float(race['entry_fee'])
        bal=wallet_balance(self.conn,rider['id']); paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id'])
        dlg=tk.Toplevel(self); dlg.title('Enter Race'); dlg.geometry('560x470'); dlg.configure(bg=BG); dlg.transient(self); dlg.grab_set()
        tk.Label(dlg,text='READY TO RACE?',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',padx=24,pady=(24,4))
        tk.Label(dlg,text=race['name'],fg=ACCENT,bg=BG,font=('Segoe UI Black',12)).pack(anchor='w',padx=24)
        summary=tk.Frame(dlg,bg=PANEL); summary.pack(fill='x',padx=24,pady=16)
        for lab,val,col in [('WALLET',f'${bal:,.2f}',TEXT),('ENTRY',f"${member_entry:.2f}",GREEN if quote['eligible'] else GOLD),('CURRENT PURSE',f'${purse:,.2f}',GOLD),('FASTEST LAP',f'${fast:,.2f}',GREEN)]:
            row=tk.Frame(summary,bg=PANEL); row.pack(fill='x',padx=14,pady=4); tk.Label(row,text=lab,fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',8)).pack(side='left'); tk.Label(row,text=val,fg=col,bg=PANEL,font=('Segoe UI Black',10)).pack(side='right')
        if bal<race['entry_fee']:
            tk.Button(dlg,text=f"ADD ${race['entry_fee']-bal:.2f} OR MORE TO WALLET",command=lambda:[dlg.destroy(),self.add_funds_dialog()],bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Black',9),pady=9).pack(fill='x',padx=24,pady=(0,10))
        if quote['eligible']:
            tk.Label(dlg,text=f"{quote['plan']['name'].upper()} MEMBER PRICE • SAVE ${quote['discount']:.2f} • {quote['remaining_today']} MEMBER-PRICED RACE(S) REMAIN TODAY AFTER THIS ENTRY. The wallet registers the normal race amount first, then returns your member savings instantly so purse funding stays exact.",fg=GREEN,bg=PANEL,justify='left',font=('Segoe UI Semibold',9),padx=12,pady=12,wraplength=480).pack(fill='x',padx=24,pady=(0,8))
        tk.Label(dlg,text='ALL SALES ARE FINAL — NO REFUNDS. The final purse and fastest-lap bonus will be shown and locked before racing begins.',fg=GOLD,bg=PANEL,justify='left',font=('Segoe UI Semibold',9),padx=12,pady=12,wraplength=480).pack(fill='x',padx=24)
        ack=tk.BooleanVar(False); tk.Checkbutton(dlg,text='I understand and accept the no-refund policy.',variable=ack,bg=BG,fg=TEXT,selectcolor=PANEL,activebackground=BG,activeforeground=TEXT,font=('Segoe UI',10)).pack(anchor='w',padx=24,pady=13)
        def confirm():
            try:
                newbal=register_with_wallet(self.conn,rider['id'],race['id'],ack.get())
                if quote['eligible'] and quote['discount']>0:
                    wallet_credit(self.conn,rider['id'],quote['discount'],kind='SUBSCRIPTION_REBATE',provider='MEMBERSHIP',note=f"{quote['plan']['name']} Community race savings")
                    record_member_use(self.conn,rider['id'],race['id'],quote)
                    newbal=wallet_balance(self.conn,rider['id'])
            except ValueError as exc:messagebox.showerror('Race Entry',str(exc),parent=dlg); return
            except Exception as exc:messagebox.showerror('Membership','Race registered, but the membership rebate could not be completed: '+str(exc),parent=dlg); return
            now=datetime.now().replace(microsecond=0).isoformat()
            self.conn.execute('INSERT INTO payment_transactions(rider_id,race_id,provider,provider_ref,amount,status,created_at) VALUES(?,?,?,?,?,?,?)',(rider['id'],race['id'],'RACE_WALLET',None,race['entry_fee'],'PAID',now)); self.conn.commit()
            dlg.destroy(); messagebox.showinfo('Gate Reserved',f"You are officially registered.\nWallet remaining: ${newbal:,.2f}"); self.open_race_details(race['id'])
        confirm_text=f"CONFIRM MEMBER ENTRY • ${member_entry:.2f}" if quote['eligible'] else f"CONFIRM ENTRY • ${race['entry_fee']:.2f}"
        tk.Button(dlg,text=confirm_text,command=confirm,bg=GREEN if quote['eligible'] else ACCENT,fg='white',relief='flat',font=('Segoe UI Black',11),pady=10,cursor='hand2').pack(fill='x',padx=24)

    # ---------- OTHER RIDER PAGES ----------
    def _live_active_session(self):
        return self.conn.execute("""SELECT rs.*,rc.name race_name,rc.track,rc.discipline,rc.skill_class,rc.lobby_tier,
                                  rc.fast_lap_contribution,rc.prize_contribution,rc.entry_fee
                                  FROM race_sessions rs JOIN races rc ON rc.id=rs.race_id
                                  WHERE rs.status IN ('RUNNING','PREPARED') ORDER BY CASE rs.status WHEN 'RUNNING' THEN 0 ELSE 1 END,rs.id DESC LIMIT 1""").fetchone()

    @staticmethod
    def _lap_display(ms):
        try:ms=int(ms or 0)
        except Exception:return '—'
        if ms<=0:return '—'
        m,rem=divmod(ms,60000); sec=rem/1000
        return f'{m}:{sec:06.3f}' if m else f'{sec:.3f}'

    def _live_rider_name(self,race_id,race_number):
        row=self.conn.execute('SELECT name FROM live_riders WHERE race_id=? AND race_number=?',(race_id,int(race_number or 0))).fetchone()
        return row['name'] if row and row['name'] else None

    def _process_commentary_events(self,race_id):
        rows=list(self.conn.execute('SELECT * FROM live_events WHERE race_id=? AND id>? ORDER BY id LIMIT 100',(race_id,self.commentary_last_event_id)))
        for row in rows:
            self.commentary_last_event_id=max(self.commentary_last_event_id,row['id'])
            try:event=__import__('json').loads(row['event_json'])
            except Exception:continue
            cues=self.commentary_director.cues_from_event(event,lambda rn:self._live_rider_name(race_id,rn))
            for cue in cues:
                self.commentary_history.append(cue.text)
                self.commentary_history=self.commentary_history[-12:]
                try:self.announcer.speak(cue.text,cue.priority)
                except Exception:pass

    def _refresh_live_widgets(self,race_id):
        if self.current_page!='LIVE' or not hasattr(self,'live_tower') or not self.live_tower.winfo_exists():return
        self._process_commentary_events(race_id)
        session=self.conn.execute('SELECT * FROM race_sessions WHERE race_id=?',(race_id,)).fetchone()
        race=self.conn.execute('SELECT * FROM races WHERE id=?',(race_id,)).fetchone()
        riders=list(self.conn.execute('SELECT * FROM live_riders WHERE race_id=? ORDER BY COALESCE(position,999),race_number',(race_id,)))
        for w in self.live_tower.winfo_children():w.destroy()
        session_name=(session['session'] or 'WAITING').replace('QUALIFYPRACTICE','QUALIFY PRACTICE') if session else 'WAITING'
        state=(session['session_state'] or 'WAITING') if session else 'WAITING'
        top=f"{self.race_class_label(race)} • {session_name} • {state}" if race else f'{session_name} • {state}'
        tk.Label(self.live_tower,text=top,fg=GOLD,bg='#11161c',font=('Segoe UI Black',8),wraplength=230,justify='left').pack(fill='x',padx=10,pady=10)
        if not riders:
            tk.Label(self.live_tower,text='Waiting for riders to join the MX Bikes server…',fg=MUTED,bg='#11161c',font=('Segoe UI',9),wraplength=220,justify='left').pack(anchor='w',padx=10,pady=8)
        for r in riders[:12]:
            f=tk.Frame(self.live_tower,bg=PANEL2); f.pack(fill='x',padx=8,pady=2)
            pos=r['position'] if r['position'] else '—'; name=r['name'] or f"#{r['race_number']}"
            gap='LEADER' if r['position']==1 else (r['gap'] or self._lap_display(r['best_lap_ms']))
            tk.Label(f,text=str(pos),fg=ACCENT,bg=PANEL2,font=('Segoe UI Black',11),width=2).pack(side='left',padx=5,pady=6)
            tk.Label(f,text=f"#{r['race_number']} {name}" if not str(name).startswith('#') else name,fg=TEXT,bg=PANEL2,font=('Segoe UI Semibold',8),wraplength=120,justify='left').pack(side='left')
            tk.Label(f,text=str(gap),fg=MUTED,bg=PANEL2,font=('Segoe UI',7)).pack(side='right',padx=6)
        if hasattr(self,'live_commentary_frame') and self.live_commentary_frame.winfo_exists():
            for w in self.live_commentary_frame.winfo_children():w.destroy()
            if not self.commentary_history:
                tk.Label(self.live_commentary_frame,text='Commentary will appear automatically as official MX Bikes timing events arrive.',fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=330,justify='left').pack(fill='x',padx=14,pady=10)
            for text in reversed(self.commentary_history[-6:]):
                tk.Label(self.live_commentary_frame,text='“'+text+'”',fg=TEXT,bg=PANEL2,wraplength=330,justify='left',font=('Segoe UI',9),padx=11,pady=10).pack(fill='x',padx=12,pady=4)
        self.after(1000,lambda rid=race_id:self._refresh_live_widgets(rid))

    def page_live(self):
        self.titlebar('LIVE','Official MX Bikes live timing, race-day coverage and spoken play-by-play in one place.')
        active=self._live_active_session()
        wrap=tk.Frame(self.content,bg=BG); wrap.pack(fill='both',expand=True,padx=28,pady=(0,24))
        vid=tk.Frame(wrap,bg='#050607',highlightbackground=LINE,highlightthickness=1); vid.pack(side='left',fill='both',expand=True)
        if not active:
            tk.Label(vid,text='OFF AIR',fg='white',bg=PANEL2,font=('Segoe UI Black',10),padx=10,pady=5).place(x=16,y=16)
            tk.Label(vid,text='NO RACE IS LIVE RIGHT NOW',fg='#56616d',bg='#050607',font=('Segoe UI Black',26)).place(relx=.5,rely=.40,anchor='center')
            upcoming=self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' AND broadcast=1 ORDER BY start_time LIMIT 1").fetchone()
            if upcoming:
                try:when=datetime.fromisoformat(upcoming['start_time']).strftime('%a %b %d • %I:%M %p')
                except Exception:when=upcoming['start_time']
                tk.Label(vid,text=f"NEXT BROADCAST\n{upcoming['name']}\n{upcoming['track']} • {when}",fg=TEXT,bg='#050607',font=('Segoe UI Semibold',12),justify='center').place(relx=.5,rely=.53,anchor='center')
            side=self.card(wrap); side.pack(side='left',fill='y',padx=(12,0)); side.configure(width=390); side.pack_propagate(False)
            tk.Label(side,text='BROADCAST BOOTH',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(16,6))
            tk.Label(side,text='When a Race Day Live server starts, this page automatically switches to the official timing tower and commentary feed. Video capture/stream input is a separate broadcast source and will plug into this same page.',fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=340,justify='left').pack(anchor='w',padx=16,pady=8)
            return
        race_id=active['race_id']
        # Do not speak old timing events when somebody merely opens the LIVE page.
        row=self.conn.execute('SELECT COALESCE(MAX(id),0) m FROM live_events WHERE race_id=?',(race_id,)).fetchone(); self.commentary_last_event_id=int(row['m'] or 0)
        self.commentary_director=CommentaryDirector(); self.commentary_history=[]
        tk.Label(vid,text='LIVE',fg='white',bg=RED,font=('Segoe UI Black',10),padx=10,pady=5).place(x=16,y=16)
        tk.Label(vid,text=active['race_name'],fg=TEXT,bg='#050607',font=('Segoe UI Black',22),wraplength=700,justify='center').place(relx=.55,rely=.36,anchor='center')
        tk.Label(vid,text=f"{active['track']} • MX BIKES OFFICIAL LIVE TIMING",fg=MUTED,bg='#050607',font=('Segoe UI Semibold',10)).place(relx=.55,rely=.43,anchor='center')
        tk.Label(vid,text='BROADCAST VIDEO INPUT',fg='#3b4652',bg='#050607',font=('Segoe UI Black',28)).place(relx=.55,rely=.56,anchor='center')
        tk.Label(vid,text='Timing + commentary are live now. Spectator video capture can be connected without changing the race-data pipeline.',fg='#596470',bg='#050607',font=('Segoe UI',9),wraplength=620,justify='center').place(relx=.55,rely=.62,anchor='center')
        self.live_tower=tk.Frame(vid,bg='#11161c'); self.live_tower.place(x=18,y=65,width=270,height=500)
        side=self.card(wrap); side.pack(side='left',fill='y',padx=(12,0)); side.configure(width=390); side.pack_propagate(False)
        tk.Label(side,text='AI RACE CALL',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(16,3))
        tk.Label(side,text='Classic 90s supercross broadcast energy using a distinct system/licensed voice — not a clone of a real announcer.',fg=MUTED,bg=PANEL,font=('Segoe UI',8),wraplength=340,justify='left').pack(anchor='w',padx=16,pady=(0,7))
        self.live_commentary_frame=tk.Frame(side,bg=PANEL); self.live_commentary_frame.pack(fill='both',expand=True)
        cash=tk.Frame(side,bg=PANEL2); cash.pack(fill='x',padx=12,pady=12)
        paid,purse=current_purse(self.conn,race_id); fast=fastest_lap_pool(self.conn,race_id)
        tk.Label(cash,text=f"LIVE PURSE  ${purse:,.0f}    •    FASTEST LAP  ${fast:,.0f}",fg=GOLD,bg=PANEL2,font=('Segoe UI Black',9),pady=10).pack(fill='x')
        self._refresh_live_widgets(race_id)

    def page_my_races(self):
        self.profile_section='RACES'; self.show('PROFILE')

    def page_results(self):
        self.titlebar('RESULTS','Official finishing order, fastest-lap bonuses, payouts and rating movement.')
        races=list(self.conn.execute("SELECT * FROM races WHERE status='COMPLETE' ORDER BY start_time DESC")); top=tk.Frame(self.content,bg=BG); top.pack(fill='both',expand=True,padx=28)
        for race in races:
            c=self.card(top); c.pack(fill='x',pady=6); tk.Label(c,text=f"{race['name']}   •   {race['track']}   •   {datetime.fromisoformat(race['start_time']).strftime('%b %d, %Y')}",fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(12,4))
            photo=self._track_photo(c,race['discipline'],race['track'],size=(920,210)); photo.pack(fill='x',padx=16,pady=(4,8))
            cols=('Pos','Rider','Bike','Best Lap','Finish Prize','Fast Lap','MMR'); t=ttk.Treeview(c,columns=cols,show='headings',height=4)
            for col in cols:t.heading(col,text=col); t.column(col,width=125,anchor='center')
            for x in self.conn.execute('''SELECT rs.*,rd.username,rd.number,rd.bike_model FROM results rs JOIN riders rd ON rd.id=rs.rider_id WHERE rs.race_id=? ORDER BY position''',(race['id'],)):
                t.insert('', 'end',values=(x['position'],f"#{x['number']} {x['username']}",x['bike_model'],x['best_lap'],f"${x['payout']:.0f}",f"${x['fast_lap_bonus']:.0f}" if x['fast_lap_bonus'] else '—',f"{x['skill_delta']:+d}"))
            t.pack(fill='x',padx=16,pady=(2,14))

    def page_championships(self):
        self.titlebar('SERIES','Choose a championship to enter its race-weekend page. MXB-Shop track photography is attached to every round and cached locally after first load.')
        nb=ttk.Notebook(self.content); nb.pack(fill='both',expand=True,padx=28,pady=(0,24))
        for discipline in ('MX','SX'):
            page=tk.Frame(nb,bg=BG); nb.add(page,text=f' {discipline} SERIES ')
            inner=tk.Frame(page,bg=BG); inner.pack(fill='both',expand=True,padx=4,pady=4)
            for c in self.conn.execute("""SELECT * FROM championships WHERE discipline=? ORDER BY CASE class_name WHEN '250 C' THEN 1 WHEN '450 C' THEN 2 WHEN '250 B' THEN 3 WHEN '450 B' THEN 4 WHEN '250 Pro' THEN 5 WHEN '450 Pro' THEN 6 ELSE 99 END, id""",(discipline,)):
                card=self.card(inner); card.pack(fill='x',pady=6)
                top=tk.Frame(card,bg=PANEL); top.pack(fill='x',padx=16,pady=(12,4))
                tk.Label(top,text=c['name'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(side='left')
                tk.Label(top,text=f"{c['rounds']} ROUNDS • ${c['per_round_fee']:.0f}/ROUND  ›",fg=GOLD,bg=PANEL,font=('Segoe UI Black',10)).pack(side='right')
                tk.Label(card,text=f"{c['class_name']}  •  {c['bike_class']}cc  •  Skill: {c['skill_class']}  •  Racecraft {c['min_racecraft']}+",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',9)).pack(anchor='w',padx=16,pady=(0,5))
                rounds=list(self.conn.execute('SELECT * FROM championship_rounds WHERE championship_id=? ORDER BY round_no LIMIT 6',(c['id'],)))
                tk.Label(card,text='  •  '.join(f"R{rr['round_no']} {rr['track']}" for rr in rounds)+(' …' if c['rounds']>6 else ''),fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=1000,justify='left').pack(anchor='w',padx=16,pady=(0,12))
                cid=c['id']; self._bind_click_recursive(card,lambda cid=cid:self.open_championship(cid))

    def open_championship(self,championship_id):
        self.clear()
        for b in self.nav_buttons.values(): b.configure(bg='#101318',fg=TEXT)
        self.page_championship_detail(championship_id)

    def page_championship_detail(self,championship_id):
        c=self.conn.execute('SELECT * FROM championships WHERE id=?',(championship_id,)).fetchone()
        if not c:
            self.show('CHAMPIONSHIPS'); return
        head=self.titlebar(c['name'],f"{c['discipline']} • {c['class_name']} • {c['rounds']} rounds • ${c['per_round_fee']:.0f}/round • Points: {c['points_system']}")
        tk.Button(head,text='‹ BACK TO SERIES',command=lambda:self.show('CHAMPIONSHIPS'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=7).pack(anchor='w',pady=(10,0))
        body=self._scrollable(self.content)
        hero=self.card(body); hero.pack(fill='x',pady=(0,14))
        tk.Label(hero,text=f"{c['class_name']}  {c['discipline']} CHAMPIONSHIP",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',11)).pack(anchor='w',padx=18,pady=(14,2))
        tk.Label(hero,text='Click any track photo for that exact round’s Event Details.',fg=TEXT,bg=PANEL,font=('Segoe UI Semibold',10)).pack(anchor='w',padx=18,pady=(0,12))
        grid=tk.Frame(body,bg=BG); grid.pack(fill='x')
        rounds=list(self.conn.execute('SELECT * FROM championship_rounds WHERE championship_id=? ORDER BY round_no',(championship_id,)))
        for i,rr in enumerate(rounds):
            row=i//3; col=i%3
            tile=self.card(grid); tile.grid(row=row,column=col,sticky='nsew',padx=6,pady=6)
            grid.columnconfigure(col,weight=1,uniform='round')
            rid=rr['id']
            photo=self._track_photo(tile,c['discipline'],rr['track'],size=(340,191),on_click=lambda rid=rid:self.open_round(rid))
            photo.pack(fill='x',padx=10,pady=(10,8))
            tk.Label(tile,text=f"ROUND {rr['round_no']}",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',9)).pack(anchor='w',padx=12)
            tk.Label(tile,text=rr['track'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=12,pady=(1,1))
            try: date=datetime.fromisoformat(rr['race_date']).strftime('%a, %b %d, %Y')
            except Exception: date=rr['race_date']
            tk.Label(tile,text=date,fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=12,pady=(0,10))
            tk.Button(tile,text='EVENT DETAILS  ›',command=lambda rid=rid:self.open_round(rid),bg=PANEL2,fg=TEXT,activebackground=ACCENT,activeforeground='white',relief='flat',font=('Segoe UI Semibold',9),pady=7,cursor='hand2').pack(fill='x',padx=10,pady=(0,10))

    def open_round(self,round_id):
        self.clear()
        for b in self.nav_buttons.values(): b.configure(bg='#101318',fg=TEXT)
        self.page_round_detail(round_id)

    def page_round_detail(self,round_id):
        rr=self.conn.execute("""SELECT cr.*,c.name championship_name,c.discipline,c.skill_class,c.class_name,c.bike_class,
                                c.per_round_fee,c.championship_contribution,c.platform_fee,c.points_system,c.min_racecraft
                                FROM championship_rounds cr JOIN championships c ON c.id=cr.championship_id WHERE cr.id=?""",(round_id,)).fetchone()
        if not rr:
            self.show('CHAMPIONSHIPS'); return
        head=self.titlebar(f"ROUND {rr['round_no']} • {rr['track']}",f"{rr['championship_name']} • {rr['class_name']} • {rr['discipline']}")
        tk.Button(head,text='‹ BACK TO CHAMPIONSHIP',command=lambda:self.open_championship(rr['championship_id']),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=7).pack(anchor='w',pady=(10,0))
        body=self._scrollable(self.content)
        top=tk.Frame(body,bg=BG); top.pack(fill='x')
        left=self.card(top); left.pack(side='left',fill='both',expand=True,padx=(0,7))
        media=self.track_media.get_cached(rr['discipline'],rr['track'])
        source_var=tk.StringVar(value=media.source_url or 'MXB-Shop source is being resolved and cached locally…')
        def resolved_media(m):
            if m.source_url:source_var.set(m.source_url)
            elif m.status in ('ERROR','NOT_FOUND'):source_var.set('Track photo source not matched yet. Use retry after the source is available.')
        photo=self._track_photo(left,rr['discipline'],rr['track'],size=(760,428),on_resolved=resolved_media)
        photo.pack(fill='x',padx=12,pady=12)
        tk.Label(left,textvariable=source_var,fg=MUTED,bg=PANEL,font=('Segoe UI',8),wraplength=700,justify='left').pack(anchor='w',padx=14,pady=(0,6))
        def open_source():
            m=self.track_media.get_cached(rr['discipline'],rr['track'])
            if m.source_url:webbrowser.open(m.source_url)
            else:messagebox.showinfo('Track Source','The track source is still being resolved. Try again in a few seconds.')
        tk.Button(left,text='OPEN TRACK SOURCE PAGE',command=open_source,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),pady=8,cursor='hand2').pack(fill='x',padx=12,pady=(0,12))

        info=self.card(top); info.pack(side='left',fill='y',padx=(7,0))
        tk.Label(info,text='EVENT DETAILS',fg=TEXT,bg=PANEL,font=('Segoe UI Black',15)).pack(anchor='w',padx=18,pady=(16,10))
        try: date=datetime.fromisoformat(rr['race_date']).strftime('%A, %B %d, %Y')
        except Exception: date=rr['race_date']
        details=[('DATE',date),('CLASS',rr['class_name']),('BIKE',f"{rr['bike_class']}cc"),('ROUND ENTRY',f"${rr['per_round_fee']:.2f}"),('POINTS',rr['points_system']),('RACECRAFT MIN',str(rr['min_racecraft']))]
        for lab,val in details:
            tk.Label(info,text=lab,fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',7)).pack(anchor='w',padx=18,pady=(4,0))
            tk.Label(info,text=val,fg=GOLD if lab=='ROUND ENTRY' else TEXT,bg=PANEL,font=('Segoe UI Black',10)).pack(anchor='w',padx=18,pady=(0,4))
        installed=self.conn.execute("SELECT 1 FROM game_content WHERE content_type='track' AND (display_name LIKE ? OR content_id LIKE ?) LIMIT 1",(f"%{rr['track']}%",f"%{rr['track']}%")).fetchone()
        tk.Label(info,text='✓ TRACK FOUND IN MX BIKES' if installed else '○ TRACK INSTALL NOT MATCHED YET',fg=GREEN if installed else GOLD,bg=PANEL,font=('Segoe UI Black',9),wraplength=260,justify='left').pack(anchor='w',padx=18,pady=(12,16))

        roster=self.card(body); roster.pack(fill='x',pady=14)
        tk.Label(roster,text='REGISTERED RIDERS',fg=TEXT,bg=PANEL,font=('Segoe UI Black',14)).pack(anchor='w',padx=16,pady=(14,8))
        if rr['race_id']:
            rows=list(self.conn.execute("""SELECT rd.username,rd.number,rd.bike_model,rd.skill_rating,rd.racecraft_grade,rg.signed_up_at
                                          FROM registrations rg JOIN riders rd ON rd.id=rg.rider_id
                                          WHERE rg.race_id=? AND rg.payment_status='PAID' ORDER BY rg.signed_up_at""",(rr['race_id'],)))
        else:
            rows=[]
        if rows:
            cols=('Rider','Bike','MMR','Etiquette','Signed Up'); tree=ttk.Treeview(roster,columns=cols,show='headings',height=min(10,len(rows)))
            for col in cols:tree.heading(col,text=col); tree.column(col,width=180,anchor='center')
            for x in rows:tree.insert('', 'end',values=(f"#{x['number']} {x['username']}",x['bike_model'],x['skill_rating'],x['racecraft_grade'],x['signed_up_at']))
            tree.pack(fill='x',padx=14,pady=(0,14))
        else:
            tk.Label(roster,text='Registration has not opened for this round yet. When the admin publishes the round, paid entrants will appear here automatically.',fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=920,justify='left').pack(anchor='w',padx=16,pady=(0,16))

    def page_rankings(self):
        self.titlebar('RANKINGS','Skill controls speed class. Racecraft controls access to clean, higher-stakes competition.')
        cols=('Rank','Rider','Class','MMR','Racecraft','Starts','Wins','Podiums','Earnings'); tree=ttk.Treeview(self.content,columns=cols,show='headings')
        for c in cols:tree.heading(c,text=c); tree.column(c,width=120,anchor='center')
        for i,r in enumerate(self.conn.execute('SELECT * FROM riders ORDER BY skill_rating DESC'),1):tree.insert('', 'end',values=(i,f"#{r['number']} {r['username']}",r['skill_class'],r['skill_rating'],f"{r['racecraft_grade']} {r['racecraft_score']}",r['starts'],r['wins'],r['podiums'],f"${r['career_earnings']:,.0f}"))
        tree.pack(fill='both',expand=True,padx=28,pady=(0,24))

    # ---------- ADMIN ----------
    def page_admin(self):
        if not self.is_admin(): return self.show('PROFILE')
        self.titlebar('ADMIN','Owner-only controls. Financial margins and platform economics are private and never exposed on rider-facing pages.')
        nb=ttk.Notebook(self.content); nb.pack(fill='both',expand=True,padx=28,pady=(0,24)); tabs={}
        for n in ['Race Economy','Finance','Race Builder','Championships','Servers','Broadcast','Race Vault','Settings']:
            f=tk.Frame(nb,bg=BG); nb.add(f,text=f' {n} '); tabs[n]=f
        f=tabs['Race Economy']; tk.Label(f,text='DEFAULT LOBBY LADDER',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        data=[('Rookie','Low Entry','$3'),('Rookie','Open','$10'),('Amateur','Low Entry','$3'),('Amateur','Premier','$35'),('Expert','Low Entry','$3'),('Expert','Cash','$25–30'),('Expert','Premier','$50+'),('Pro','Low Entry','$3'),('Pro','Cash','$50+'),('Pro','Premier','$100+')]
        t=ttk.Treeview(f,columns=('Skill','Lobby','Entry'),show='headings',height=11)
        for c in ('Skill','Lobby','Entry'):t.heading(c,text=c); t.column(c,width=210,anchor='center')
        for x in data:t.insert('', 'end',values=x)
        t.pack(fill='x'); tk.Label(f,text='Lower-cost races reduce the barrier to entry. Pro still has the highest ceiling and biggest featured purses.',fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(anchor='w',pady=10)

        f=tabs['Finance']; tk.Label(f,text='OWNER PROFIT CHECK',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=(16,4))
        reserve=setting_float(self.conn,'processor_reserve_pct',.06); fixed=setting_float(self.conn,'race_fixed_ops_reserve',4); floor=setting_float(self.conn,'minimum_owner_profit',4)
        tk.Label(f,text=f"Conservative planning reserve: {reserve*100:.1f}% of entries + ${fixed:.2f} fixed race operations. Minimum projected owner profit: ${floor:.2f}.",fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(anchor='w',pady=(0,10))
        cols=('Race','Entry','Min','Prizes @ Min','Platform @ Min','Reserve/Ops','Projected Owner Net','Status'); ft=ttk.Treeview(f,columns=cols,show='headings',height=13)
        widths={'Race':280,'Entry':80,'Min':60,'Prizes @ Min':120,'Platform @ Min':120,'Reserve/Ops':120,'Projected Owner Net':150,'Status':90}
        for c in cols:ft.heading(c,text=c); ft.column(c,width=widths[c],anchor='center' if c!='Race' else 'w')
        all_good=True
        for race in self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY skill_class,entry_fee"):
            fin=race_financials(self.conn,race['id'],race['min_riders']); good=fin['owner_projected_net']>=floor; all_good &= good
            ft.insert('', 'end',values=(race['name'],f"${race['entry_fee']:.2f}",race['min_riders'],f"${fin['total_prizes']:.2f}",f"${fin['platform_gross']:.2f}",f"${fin['processor_reserve']+fin['fixed_ops_reserve']:.2f}",f"${fin['owner_projected_net']:.2f}",'PROFITABLE' if good else 'FIX PRICE'))
        ft.pack(fill='both',expand=True)
        tk.Label(f,text='✓ ALL OPEN RACES CLEAR THE PROFIT FLOOR AT THEIR MINIMUM RIDER COUNT' if all_good else '⚠ One or more races fall below the configured profit floor.',fg=GREEN if all_good else RED,bg=BG,font=('Segoe UI Black',10)).pack(anchor='w',pady=10)
        tk.Label(f,text='Projected net is a planning estimate, not a guarantee. Actual processor, chargeback, hosting, tax and compliance costs can differ.',fg=MUTED,bg=BG,font=('Segoe UI',8)).pack(anchor='w')

        f=tabs['Race Builder']; tk.Label(f,text='RACE BUILDER',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        for x in ['Entry fee','Main purse contribution per rider','Fastest-lap contribution per rider','Platform/operations share','Minimum/maximum riders','Skill/MMR range','Racecraft minimum','Track and bike class','Practice / qualifying / moto format','Purse lock time','Broadcast enabled']:
            tk.Label(f,text='✓ '+x,fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=2)
        tk.Label(f,text='Publishing will eventually block any paid race whose minimum-rider projection falls below your configured owner-profit floor.',fg=GOLD,bg=BG,font=('Segoe UI Semibold',9),wraplength=950,justify='left').pack(anchor='w',pady=12)

        f=tabs['Championships']; tk.Label(f,text='SEASON CONTROL',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Default: MX May–September • SX November–March. Admin can change every date, track, round, fee, purse and points rule.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        f=tabs['Servers']; tk.Label(f,text='MX BIKES RACE AGENT',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=(16,4))
        tk.Label(f,text='Automatic local sync + dedicated server control. The agent discovers MX Bikes, installed tracks/bikes, imports official XML results/replays, and listens to Live Timing during hosted races.',fg=MUTED,bg=BG,font=('Segoe UI',9),wraplength=1000,justify='left').pack(anchor='w',pady=(0,10))
        diag=ttk.Treeview(f,columns=('Check','Status','Details'),show='headings',height=7)
        for col,w in (('Check',220),('Status',90),('Details',650)):diag.heading(col,text=col); diag.column(col,width=w,anchor='w' if col!='Status' else 'center')
        try: checks=self.mx_agent.diagnostics()
        except Exception as exc: checks=[('MX Bikes integration',False,str(exc))]
        for label,ok,details in checks:diag.insert('', 'end',values=(label,'READY' if ok else 'CHECK',details))
        diag.pack(fill='x',pady=(0,10))
        buttons=tk.Frame(f,bg=BG); buttons.pack(fill='x',pady=(0,10))
        def sync_now():
            self.mx_status_label.configure(text='● SYNCING MX BIKES…',fg=GOLD)
            self.mx_agent.sync_async(lambda env:self.after(0,lambda:(self._apply_mx_environment(env),messagebox.showinfo('MX Bikes Sync',f"Sync finished. {env.tracks_found} tracks and {env.bikes_found} bikes found." if env.found else env.error))))
        tk.Button(buttons,text='SYNC MX BIKES NOW',command=sync_now,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',9),padx=14,pady=8).pack(side='left',padx=(0,8))
        open_races=list(self.conn.execute("SELECT id,name FROM races WHERE status='REGISTRATION' ORDER BY start_time"))
        race_map={x['name']:x['id'] for x in open_races}; selected=tk.StringVar(value=open_races[0]['name'] if open_races else '')
        combo=ttk.Combobox(buttons,textvariable=selected,values=list(race_map),state='readonly',width=36); combo.pack(side='left',padx=(0,8))
        def chosen(): return race_map.get(selected.get())
        def prep():
            try:
                pkg=self.mx_agent.prepare_race(chosen()); missing=pkg.get('missing_identities') or []
                messagebox.showinfo('Race Prepared',f"Dedicated config and whitelist created.\nMissing linked identities: {', '.join(missing) if missing else 'None'}")
            except Exception as exc: messagebox.showerror('Prepare Failed',str(exc))
        def start_server():
            try:
                pkg=self.mx_agent.start_race_server(chosen()); messagebox.showinfo('Server Started',f"MX Bikes dedicated server started on port {pkg['game_port']}. Live timing is listening on {pkg['live_port']}.")
            except Exception as exc: messagebox.showerror('Start Failed',str(exc))
        def stop_server():
            try:self.mx_agent.stop_race_server(chosen()); messagebox.showinfo('Server','Race server stop command sent.')
            except Exception as exc:messagebox.showerror('Stop Failed',str(exc))
        tk.Button(buttons,text='PREPARE',command=prep,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=12,pady=8).pack(side='left',padx=4)
        tk.Button(buttons,text='START SERVER',command=start_server,bg=GREEN,fg='#07140d',relief='flat',font=('Segoe UI Black',9),padx=12,pady=8).pack(side='left',padx=4)
        tk.Button(buttons,text='STOP',command=stop_server,bg=RED,fg='white',relief='flat',font=('Segoe UI Black',9),padx=12,pady=8).pack(side='left',padx=4)
        tk.Label(f,text='Paid riders must have a linked Steam ID or MX Bikes GUID before the whitelist can be launched.',fg=GOLD,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w')

        f=tabs['Broadcast']; tk.Label(f,text='BROADCAST DIRECTOR',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        tk.Label(f,text='Live spectator feed • timing tower • AI play-by-play • fastest-lap cash chase • championship context • sponsor slots.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        tk.Label(f,text='Voice target: classic 1990s American supercross television — energetic, authoritative, knowledgeable and dramatic. The system can capture that era and cadence while using a distinct licensed voice rather than cloning a real announcer.',fg=MUTED,bg=BG,font=('Segoe UI',9),wraplength=980,justify='left').pack(anchor='w',pady=(8,0))
        f=tabs['Race Vault']; tk.Label(f,text='OWNER-ONLY RACE VAULT',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Hidden from riders: official results, full replays, broadcasts, logs, payment audit records and steward evidence.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        f=tabs['Settings']; tk.Label(f,text='PLATFORM DEFAULTS',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        for x in self.conn.execute('SELECT * FROM admin_settings ORDER BY key'):tk.Label(f,text=f"{x['key']}:  {x['value']}",fg=TEXT,bg=BG,font=('Consolas',10)).pack(anchor='w',pady=2)

    def _silent_update_check(self):
        def worker():
            try:
                m=check_for_update()
                if m.get('available'):self.after(0,lambda:self.update_btn.configure(text=f"UPDATE TO {m['version']}"))
            except Exception:pass
        threading.Thread(target=worker,daemon=True).start()
    def do_update(self):
        self.update_btn.configure(state='disabled',text='REFRESHING UPDATE FEED…')
        def worker():
            try:
                m=check_for_update()
                if not m.get('available'):
                    self.after(0,lambda:(self.update_btn.configure(state='normal',text='UPDATE'),messagebox.showinfo('MXB Race Day Live',f'You are on the latest version: v{VERSION}')))
                    return
                self.after(0,lambda:self.update_btn.configure(text=f"DOWNLOADING {m['version']}…"))
                z=download_update(m)
                launch_update(z)
                def close_for_update():
                    try:self.update_btn.configure(text='INSTALLING & RESTARTING…')
                    except Exception:pass
                    self.after(300,self._on_close)
                self.after(0,close_for_update)
            except Exception as e:
                msg=str(e)
                def fail(msg=msg):
                    self.update_btn.configure(state='normal',text='UPDATE')
                    messagebox.showerror('Update Failed',msg)
                self.after(0,fail)
        threading.Thread(target=worker,daemon=True).start()

def main():RaceDayLiveApp().mainloop()
