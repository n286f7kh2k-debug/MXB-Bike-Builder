# MXB Race Control v0.1.3

Developer build of the MX Bikes paid-racing platform.

## v0.1.3 changes
- My Paddock now opens as a true rider profile header with profile picture/initials, rider name and overall ranking badge.
- Current skill status and etiquette ranking are visible directly in the rider header.
- Riders can choose a PNG/GIF profile picture; it is stored under `%APPDATA%\MXB Race Control\profile_images` so updates do not overwrite it.
- Championship classes now use bike-specific names:
  - 250 C / 450 C
  - 250 B / 450 B
  - 250 Pro
  - 450 Pro
- Rookie and Amateur championships are split into separate 250 and 450 series for both MX and SX.
- Existing Expert championships migrate to 250 Pro; existing Pro championships migrate to 450 Pro.
- Existing databases migrate automatically to schema version 4.

Run `run_windows.bat`.

The UPDATE button checks the permanent Race Control update feed, verifies SHA-256, installs the update and restarts the app.
