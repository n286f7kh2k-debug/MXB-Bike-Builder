import hashlib
import json
import os
import subprocess
import sys
import tempfile
import time
import uuid
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path

from .config import VERSION, load_settings


class UpdateError(Exception):
    pass


def parse_ver(v):
    try:
        return tuple(int(x) for x in str(v).strip().lstrip('v').split('.'))
    except Exception:
        return (0,)


def _cache_bust(url):
    """Avoid stale raw-GitHub manifests after a release is published."""
    if not url:
        return url
    parts = urllib.parse.urlsplit(url)
    q = urllib.parse.parse_qsl(parts.query, keep_blank_values=True)
    q.append(('_mxbts', str(time.time_ns())))
    q.append(('_mxbnonce', uuid.uuid4().hex))
    return urllib.parse.urlunsplit((parts.scheme, parts.netloc, parts.path, urllib.parse.urlencode(q), parts.fragment))


def _request(url):
    return urllib.request.Request(
        _cache_bust(url),
        headers={
            'User-Agent': 'MXB-Race-Day-Live-Updater/0.3.3',
            'Cache-Control': 'no-cache, no-store, max-age=0',
            'Pragma': 'no-cache',
            'Accept': '*/*',
        },
    )


def _manifest_from_github_api():
    """Read latest.json through GitHub's Contents API to avoid raw.githubusercontent.com edge caches."""
    api = 'https://api.github.com/repos/n286f7kh2k-debug/MXB-Bike-Builder/contents/race-control/latest.json?ref=main'
    req = urllib.request.Request(
        _cache_bust(api),
        headers={
            'User-Agent': 'MXB-Race-Day-Live-Updater/0.3.3',
            'Cache-Control': 'no-cache, no-store, max-age=0',
            'Pragma': 'no-cache',
            'Accept': 'application/vnd.github+json',
        },
    )
    with urllib.request.urlopen(req, timeout=15) as r:
        payload = json.loads(r.read().decode('utf-8-sig'))
    import base64
    encoded = str(payload.get('content') or '').replace('\n', '')
    if not encoded:
        raise UpdateError('GitHub API returned no update manifest content.')
    return json.loads(base64.b64decode(encoded).decode('utf-8-sig'))


def check_for_update():
    # Canonical source first: GitHub Contents API gives the current branch blob and
    # is not subject to the stale raw-file edge cache that affected v0.2.4/v0.2.5.
    errors = []
    try:
        manifest = _manifest_from_github_api()
    except Exception as exc:
        errors.append(f'GitHub API: {exc}')
        feed = load_settings().get('update_feed')
        if not feed:
            raise UpdateError('The update feed is not configured.')
        try:
            with urllib.request.urlopen(_request(feed), timeout=15) as r:
                manifest = json.loads(r.read().decode('utf-8-sig'))
        except Exception as exc2:
            errors.append(f'raw feed: {exc2}')
            raise UpdateError('Could not contact the update server: ' + ' | '.join(errors)) from exc2
    if not isinstance(manifest, dict) or not manifest.get('version') or not manifest.get('url'):
        raise UpdateError('The update server returned an invalid manifest.')
    manifest['available'] = parse_ver(manifest.get('version', '0')) > parse_ver(VERSION)
    return manifest


def _validate_zip(path):
    if not zipfile.is_zipfile(path):
        raise UpdateError('Downloaded update is not a valid ZIP.')
    with zipfile.ZipFile(path, 'r') as zf:
        names = {n.replace('\\', '/').lstrip('./') for n in zf.namelist()}
        # Permit either a flat update ZIP or a single top-level folder.
        def has_suffix(suffix):
            return any(n == suffix or n.endswith('/' + suffix) for n in names)
        required = ('app.py', 'src/app.py', 'src/config.py', 'src/updater.py')
        missing = [x for x in required if not has_suffix(x)]
        if missing:
            raise UpdateError('Update package is incomplete. Missing: ' + ', '.join(missing))


def download_update(manifest, progress=None):
    url = manifest['url']
    out = Path(tempfile.gettempdir()) / f"MXB_Race_Day_Live_{manifest['version']}_update.zip"
    try:
        with urllib.request.urlopen(_request(url), timeout=45) as r, open(out, 'wb') as f:
            total = int(r.headers.get('Content-Length', '0') or 0)
            got = 0
            while True:
                chunk = r.read(1024 * 256)
                if not chunk:
                    break
                f.write(chunk)
                got += len(chunk)
                if progress and total:
                    progress(min(100, int(got * 100 / total)))
    except Exception as exc:
        raise UpdateError(f'Could not download the update: {exc}') from exc

    expected = (manifest.get('sha256') or '').strip().lower()
    if expected:
        actual = hashlib.sha256(out.read_bytes()).hexdigest().lower()
        if actual != expected:
            try:
                out.unlink(missing_ok=True)
            except Exception:
                pass
            raise UpdateError(f'Update verification failed. Expected {expected}, got {actual}')
    _validate_zip(out)
    return out


def launch_update(zip_path):
    """Launch a detached Python helper to apply the update after this process exits.

    This deliberately avoids PowerShell/execution-policy dependencies and uses the same
    Python runtime that is already running the app. The helper logs every step and keeps
    a last-good code backup for recovery.
    """
    root = Path(__file__).resolve().parents[1]
    pid = os.getpid()
    helper = Path(tempfile.gettempdir()) / 'mxb_race_day_live_apply_update.py'
    log = Path(tempfile.gettempdir()) / 'MXB_Race_Day_Live_update.log'

    helper_code = r'''import os, shutil, subprocess, sys, tempfile, time, traceback, zipfile
from pathlib import Path

PID = int(sys.argv[1])
ZIP = Path(sys.argv[2])
INSTALL = Path(sys.argv[3])
LOG = Path(sys.argv[4])
PYTHON = sys.argv[5]
CREATE_NO_WINDOW = 0x08000000 if os.name == 'nt' else 0

def L(msg):
    try:
        with LOG.open('a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%dT%H:%M:%S') + ' ' + str(msg) + '\n')
    except Exception:
        pass

def wait_for_parent(pid, timeout_ms=30000):
    if os.name == 'nt':
        try:
            import ctypes
            SYNCHRONIZE = 0x00100000
            WAIT_TIMEOUT = 0x00000102
            kernel32 = ctypes.windll.kernel32
            handle = kernel32.OpenProcess(SYNCHRONIZE, False, pid)
            if handle:
                result = kernel32.WaitForSingleObject(handle, timeout_ms)
                kernel32.CloseHandle(handle)
                L('Parent wait result=' + str(result))
                return
        except Exception as exc:
            L('Parent wait API failed: ' + repr(exc))
    # Fallback: the GUI normally exits within a fraction of a second.
    time.sleep(1.5)

def find_source(stage):
    items = list(stage.iterdir())
    if len(items) == 1 and items[0].is_dir():
        return items[0]
    return stage

def copy_tree(source, dest):
    for item in source.iterdir():
        target = dest / item.name
        if item.is_dir():
            shutil.copytree(item, target, dirs_exist_ok=True)
        else:
            shutil.copy2(item, target)

def schedule_restart():
    """Start a detached watchdog which relaunches after this updater has exited."""
    watchdog = Path(tempfile.gettempdir()) / 'mxb_race_day_live_restart_watchdog.py'
    watchdog_code = r"""import os, subprocess, sys, time, traceback
from pathlib import Path

INSTALL = Path(sys.argv[1])
LOG = Path(sys.argv[2])
PYTHON = sys.argv[3]

def L(msg):
    try:
        with LOG.open('a', encoding='utf-8') as f:
            f.write(time.strftime('%Y-%m-%dT%H:%M:%S') + ' restart-watchdog ' + str(msg) + '\n')
    except Exception:
        pass

def popen(args):
    flags = 0
    if os.name == 'nt':
        flags = 0x08000000 | 0x00000200 | 0x00000008
    try:
        return subprocess.Popen(args, cwd=str(INSTALL), creationflags=flags, close_fds=True)
    except Exception as exc:
        L('Detached launch failed for %r: %r' % (args, exc))
        return subprocess.Popen(args, cwd=str(INSTALL), creationflags=(0x08000000 if os.name == 'nt' else 0), close_fds=True)

try:
    time.sleep(1.8)
    vbs = INSTALL / 'Start MXB Race Day Live.vbs'
    legacy_vbs = INSTALL / 'Start MXB Race Control.vbs'
    if os.name == 'nt' and vbs.exists():
        popen(['wscript.exe', str(vbs)])
        L('Launched current VBS')
        raise SystemExit(0)
    if os.name == 'nt' and legacy_vbs.exists():
        popen(['wscript.exe', str(legacy_vbs)])
        L('Launched legacy VBS')
        raise SystemExit(0)

    app = INSTALL / 'app.py'
    py = INSTALL / '.venv' / 'Scripts' / 'pythonw.exe'
    if not py.exists():
        py = Path(PYTHON)
        if os.name == 'nt' and py.name.lower() == 'python.exe':
            candidate = py.with_name('pythonw.exe')
            if candidate.exists():
                py = candidate
    popen([str(py), str(app)])
    L('Launched app directly with ' + str(py))
except SystemExit:
    raise
except Exception:
    L('RESTART WATCHDOG FAILED\n' + traceback.format_exc())
"""
    watchdog.write_text(watchdog_code, encoding='utf-8')
    flags = 0
    if os.name == 'nt':
        flags = 0x08000000 | 0x00000200 | 0x00000008
    try:
        subprocess.Popen([PYTHON, str(watchdog), str(INSTALL), str(LOG), PYTHON], cwd=str(INSTALL), creationflags=flags, close_fds=True)
        L('Detached restart watchdog scheduled')
    except Exception as exc:
        L('Detached watchdog failed, falling back to launcher: ' + repr(exc))
        vbs = INSTALL / 'Start MXB Race Day Live.vbs'
        if os.name == 'nt' and vbs.exists():
            subprocess.Popen(['wscript.exe', str(vbs)], cwd=str(INSTALL), creationflags=CREATE_NO_WINDOW, close_fds=True)
        else:
            app = INSTALL / 'app.py'
            subprocess.Popen([PYTHON, str(app)], cwd=str(INSTALL), creationflags=CREATE_NO_WINDOW, close_fds=True)

L('Update helper started; zip=' + str(ZIP) + '; install=' + str(INSTALL))
try:
    wait_for_parent(PID)
    stage = Path(tempfile.mkdtemp(prefix='MXBRDL_STAGE_'))
    with zipfile.ZipFile(ZIP, 'r') as zf:
        zf.extractall(stage)
    source = find_source(stage)
    required = [source / 'app.py', source / 'src' / 'app.py', source / 'src' / 'config.py', source / 'src' / 'updater.py']
    missing = [str(p.relative_to(source)) for p in required if not p.exists()]
    if missing:
        raise RuntimeError('Staged update is incomplete: ' + ', '.join(missing))

    appdata = Path(os.environ.get('APPDATA', str(INSTALL))) / 'MXB Race Day Live' / 'updates'
    appdata.mkdir(parents=True, exist_ok=True)
    backup = appdata / ('last-good-' + time.strftime('%Y%m%d-%H%M%S'))
    backup.mkdir(parents=True, exist_ok=True)
    for rel in ('app.py', 'src', 'run_windows.bat', 'Start MXB Race Day Live.vbs'):
        old = INSTALL / rel
        if old.exists():
            dst = backup / rel
            if old.is_dir(): shutil.copytree(old, dst, dirs_exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(old, dst)
    L('Backup created at ' + str(backup))

    # Retry copy briefly in case antivirus/indexing has a transient file handle.
    last_exc = None
    for attempt in range(1, 11):
        try:
            copy_tree(source, INSTALL)
            last_exc = None
            break
        except Exception as exc:
            last_exc = exc
            L('Copy attempt %d failed: %r' % (attempt, exc))
            time.sleep(0.75)
    if last_exc:
        raise last_exc

    marker = appdata / 'last_update_success.txt'
    marker.write_text(time.strftime('%Y-%m-%d %H:%M:%S') + '\n' + str(ZIP), encoding='utf-8')
    L('Update files applied successfully')
    shutil.rmtree(stage, ignore_errors=True)
    schedule_restart()
    L('Update completed; restart scheduled')
except Exception:
    L('UPDATE FAILED\n' + traceback.format_exc())
'''
    helper.write_text(helper_code, encoding='utf-8')
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    if os.name == 'nt':
        flags |= getattr(subprocess, 'CREATE_NEW_PROCESS_GROUP', 0) | getattr(subprocess, 'DETACHED_PROCESS', 0)
    try:
        subprocess.Popen(
            [sys.executable, str(helper), str(pid), str(zip_path), str(root), str(log), sys.executable],
            cwd=str(root),
            creationflags=flags,
            close_fds=True,
        )
    except Exception as exc:
        raise UpdateError(f'Could not start the update installer: {exc}') from exc
    return log
