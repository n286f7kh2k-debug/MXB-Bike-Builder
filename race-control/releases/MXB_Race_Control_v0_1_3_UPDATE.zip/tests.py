import os, tempfile
os.environ['APPDATA'] = tempfile.mkdtemp(prefix='mxb_rc_test_')
from src.database import connect, seed, current_purse, payout_split, wallet_balance, wallet_credit, wallet_debit, race_financials
from src.updater import parse_ver
from src.config import VERSION

def main():
    seed(); c=connect()
    assert VERSION == '0.1.3'
    assert parse_ver('0.1.3') > parse_ver('0.1.2')
    assert c.execute('select count(*) from riders').fetchone()[0] >= 8
    assert c.execute("select count(*) from races where status='REGISTRATION'").fetchone()[0] >= 9
    assert c.execute("select value from meta where key='schema_version'").fetchone()[0] == '4'
    assert c.execute("select count(*) from registrations where payment_status!='PAID'").fetchone()[0] == 0

    # v0.1.3 profile header data and championship class structure.
    assert 'avatar_path' in [x['name'] for x in c.execute('pragma table_info(riders)')]
    expected_classes={'250 C','450 C','250 B','450 B','250 Pro','450 Pro'}
    for discipline in ('MX','SX'):
        got={x['class_name'] for x in c.execute('select class_name from championships where discipline=?',(discipline,))}
        assert expected_classes.issubset(got), (discipline,got)
        assert c.execute("select count(*) from championships where discipline=? and skill_class='Rookie'",(discipline,)).fetchone()[0] == 2
        assert c.execute("select count(*) from championships where discipline=? and skill_class='Amateur'",(discipline,)).fetchone()[0] == 2
        assert c.execute("select name from championships where discipline=? and skill_class='Expert'",(discipline,)).fetchone()[0].startswith('2027 250 Pro')
        assert c.execute("select name from championships where discipline=? and skill_class='Pro'",(discipline,)).fetchone()[0].startswith('2027 450 Pro')


    # Low-entry lobbies exist at every skill level.
    for cls in ('Rookie','Amateur','Expert','Pro'):
        assert c.execute("select count(*) from races where status='REGISTRATION' and skill_class=? and lobby_tier='Low Entry'",(cls,)).fetchone()[0] >= 1

    # Every open race fully accounts for the entry fee and is profitable at its hard minimum.
    floor=float(c.execute("select value from admin_settings where key='minimum_owner_profit'").fetchone()[0])
    for r in c.execute("select * from races where status='REGISTRATION'"):
        assert abs(r['entry_fee'] - (r['prize_contribution'] + r['fast_lap_contribution'] + r['platform_fee'])) < 0.001, r['name']
        f=race_financials(c,r['id'],r['min_riders'])
        assert abs(f['total_prizes'] - (f['main_purse'] + f['fast_lap_bonus'])) < 0.001
        assert f['owner_projected_net'] >= floor, (r['name'],f['owner_projected_net'])

    r=c.execute("select * from races where name='Friday Night Expert Cash'").fetchone(); n,p=current_purse(c,r['id'])
    assert n >= 4 and p == n*r['prize_contribution']
    assert r['fast_lap_contribution'] > 0
    assert abs(sum(payout_split(4))-1) < 1e-9 and abs(sum(payout_split(20))-1) < 1e-9

    rider=c.execute("select id from riders where username='Welchy'").fetchone(); b0=wallet_balance(c,rider['id']); b1=wallet_credit(c,rider['id'],25.50,note='test'); assert round(b1-b0,2)==25.50
    b2=wallet_debit(c,rider['id'],10.25,note='test debit'); assert round(b1-b2,2)==10.25
    assert c.execute('select count(*) from wallet_transactions where rider_id=?',(rider['id'],)).fetchone()[0] >= 3
    c.close(); print('MXB Race Control v0.1.3 tests passed')
if __name__=='__main__': main()
