from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def application_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def _powershell_escape_single(value: str) -> str:
    return value.replace("'", "''")


def desktop_shortcut_script(root: Path | None = None) -> str:
    root = Path(root or application_root()).resolve()
    if getattr(sys, "frozen", False):
        target = Path(sys.executable).resolve()
        args = ""
    else:
        target = root / "run_windows.bat"
        args = ""
    root_s = _powershell_escape_single(str(root))
    target_s = _powershell_escape_single(str(target))
    args_s = _powershell_escape_single(args)
    return (
        '$ErrorActionPreference = "Stop"\n'
        '$Desktop = [Environment]::GetFolderPath("Desktop")\n'
        'if (-not $Desktop) { throw "Windows Desktop folder could not be resolved." }\n'
        '$ShortcutPath = Join-Path $Desktop "MXB Bike Builder.lnk"\n'
        '$Shell = New-Object -ComObject WScript.Shell\n'
        '$Shortcut = $Shell.CreateShortcut($ShortcutPath)\n'
        f"$Shortcut.TargetPath = '{target_s}'\n"
        f"$Shortcut.Arguments = '{args_s}'\n"
        f"$Shortcut.WorkingDirectory = '{root_s}'\n"
        "$Shortcut.Description = 'MXB Bike Builder'\n"
        '$Shortcut.Save()\n'
        'Write-Output $ShortcutPath\n'
    )


def create_desktop_shortcut() -> tuple[bool, str]:
    if os.name != "nt":
        return False, "Desktop shortcuts are only created on Windows."
    try:
        result = subprocess.run(
            [
                "powershell.exe",
                "-NoProfile",
                "-ExecutionPolicy",
                "Bypass",
                "-Command",
                desktop_shortcut_script(),
            ],
            capture_output=True,
            text=True,
            timeout=15,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception as exc:
        return False, str(exc)
    if result.returncode != 0:
        return False, (result.stderr or result.stdout or "Unknown shortcut error").strip()
    return True, (result.stdout or "Desktop shortcut created.").strip()


def ensure_desktop_shortcut() -> None:
    """Best-effort shortcut creation; startup must never fail because of it."""
    if os.name != "nt":
        return
    try:
        create_desktop_shortcut()
    except Exception:
        pass
