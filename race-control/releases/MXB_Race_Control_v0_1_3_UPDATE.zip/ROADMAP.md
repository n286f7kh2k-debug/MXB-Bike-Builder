# MXB Race Control Roadmap

Current foundation: rider profiles, wallet ledger, paid race registration, dynamic purses, fastest-lap bonuses, MMR, etiquette/Racecraft, bike-specific MX/SX championships, results, admin finance checks and one-click updating.

Next major milestones:
1. Production authentication/accounts.
2. Approved real-money payment and payout provider.
3. MX Bikes Race Agent: dedicated server launch, whitelist, live timing, results and replay capture.
4. Live broadcast spectator pipeline and AI announcer.
5. Complete admin race/championship editor.
6. Stewarding, protests, penalties and anti-sandbagging.
7. Production hosting, backups and monitoring.
