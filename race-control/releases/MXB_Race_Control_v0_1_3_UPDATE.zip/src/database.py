import sqlite3
from datetime import datetime, timedelta
from .config import DB_FILE

SCHEMA = '''
PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS meta (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL, action TEXT NOT NULL,
    entity_type TEXT, entity_id TEXT, details TEXT, created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS riders (
    id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL, number INTEGER,
    team TEXT, bike_model TEXT, bike_size TEXT, region TEXT, bio TEXT,
    skill_rating INTEGER NOT NULL DEFAULT 1200, skill_class TEXT NOT NULL DEFAULT 'Rookie',
    racecraft_score INTEGER NOT NULL DEFAULT 900, racecraft_grade TEXT NOT NULL DEFAULT 'A',
    career_earnings REAL NOT NULL DEFAULT 0, starts INTEGER NOT NULL DEFAULT 0,
    wins INTEGER NOT NULL DEFAULT 0, podiums INTEGER NOT NULL DEFAULT 0,
    championships INTEGER NOT NULL DEFAULT 0, avatar_path TEXT
);
CREATE TABLE IF NOT EXISTS championships (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, discipline TEXT NOT NULL,
    skill_class TEXT NOT NULL, season TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1,
    rounds INTEGER NOT NULL DEFAULT 8, per_round_fee REAL NOT NULL,
    championship_contribution REAL NOT NULL, platform_fee REAL NOT NULL,
    points_system TEXT NOT NULL DEFAULT '26-23-21', min_racecraft INTEGER NOT NULL DEFAULT 700,
    class_name TEXT NOT NULL DEFAULT '', bike_class TEXT NOT NULL DEFAULT 'Open'
);
CREATE TABLE IF NOT EXISTS races (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, discipline TEXT NOT NULL,
    skill_class TEXT NOT NULL, lobby_tier TEXT NOT NULL, track TEXT NOT NULL,
    bike_class TEXT NOT NULL, start_time TEXT NOT NULL, signup_cutoff TEXT NOT NULL,
    purse_lock_time TEXT NOT NULL, entry_fee REAL NOT NULL, prize_contribution REAL NOT NULL,
    fast_lap_contribution REAL NOT NULL DEFAULT 0, platform_fee REAL NOT NULL,
    min_riders INTEGER NOT NULL DEFAULT 4, max_riders INTEGER NOT NULL DEFAULT 20,
    min_skill INTEGER NOT NULL DEFAULT 0, max_skill INTEGER NOT NULL DEFAULT 9999,
    min_racecraft INTEGER NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'REGISTRATION',
    featured INTEGER NOT NULL DEFAULT 0, broadcast INTEGER NOT NULL DEFAULT 1
);
CREATE TABLE IF NOT EXISTS wallets (
    rider_id INTEGER PRIMARY KEY, balance_cents INTEGER NOT NULL DEFAULT 0,
    currency TEXT NOT NULL DEFAULT 'USD', updated_at TEXT NOT NULL,
    FOREIGN KEY(rider_id) REFERENCES riders(id)
);
CREATE TABLE IF NOT EXISTS wallet_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, rider_id INTEGER NOT NULL, kind TEXT NOT NULL,
    amount_cents INTEGER NOT NULL, balance_after_cents INTEGER NOT NULL,
    status TEXT NOT NULL DEFAULT 'POSTED', provider TEXT, provider_ref TEXT,
    race_id INTEGER, note TEXT, created_at TEXT NOT NULL,
    FOREIGN KEY(rider_id) REFERENCES riders(id), FOREIGN KEY(race_id) REFERENCES races(id)
);
CREATE TABLE IF NOT EXISTS payment_transactions (
    id INTEGER PRIMARY KEY AUTOINCREMENT, rider_id INTEGER, race_id INTEGER,
    provider TEXT NOT NULL, provider_ref TEXT, amount REAL NOT NULL,
    status TEXT NOT NULL, created_at TEXT NOT NULL,
    FOREIGN KEY(rider_id) REFERENCES riders(id), FOREIGN KEY(race_id) REFERENCES races(id)
);
CREATE TABLE IF NOT EXISTS payouts (
    id INTEGER PRIMARY KEY AUTOINCREMENT, rider_id INTEGER NOT NULL, race_id INTEGER,
    championship_id INTEGER, amount REAL NOT NULL, status TEXT NOT NULL DEFAULT 'PENDING',
    provider_ref TEXT, created_at TEXT NOT NULL,
    FOREIGN KEY(rider_id) REFERENCES riders(id), FOREIGN KEY(race_id) REFERENCES races(id),
    FOREIGN KEY(championship_id) REFERENCES championships(id)
);
CREATE TABLE IF NOT EXISTS registrations (
    id INTEGER PRIMARY KEY AUTOINCREMENT, race_id INTEGER NOT NULL, rider_id INTEGER NOT NULL,
    signed_up_at TEXT NOT NULL, payment_status TEXT NOT NULL, amount_paid REAL NOT NULL DEFAULT 0,
    no_refund_ack INTEGER NOT NULL DEFAULT 0, UNIQUE(race_id, rider_id),
    FOREIGN KEY(race_id) REFERENCES races(id), FOREIGN KEY(rider_id) REFERENCES riders(id)
);
CREATE TABLE IF NOT EXISTS results (
    id INTEGER PRIMARY KEY AUTOINCREMENT, race_id INTEGER NOT NULL, rider_id INTEGER NOT NULL,
    position INTEGER NOT NULL, laps INTEGER NOT NULL, best_lap TEXT, gap TEXT,
    points INTEGER NOT NULL DEFAULT 0, payout REAL NOT NULL DEFAULT 0,
    fast_lap_bonus REAL NOT NULL DEFAULT 0, skill_delta INTEGER NOT NULL DEFAULT 0,
    racecraft_delta INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY(race_id) REFERENCES races(id), FOREIGN KEY(rider_id) REFERENCES riders(id)
);
CREATE TABLE IF NOT EXISTS incidents (
    id INTEGER PRIMARY KEY AUTOINCREMENT, race_id INTEGER NOT NULL,
    reporter_rider_id INTEGER, accused_rider_id INTEGER, category TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'OPEN', steward_decision TEXT,
    racecraft_delta INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL,
    FOREIGN KEY(race_id) REFERENCES races(id), FOREIGN KEY(reporter_rider_id) REFERENCES riders(id),
    FOREIGN KEY(accused_rider_id) REFERENCES riders(id)
);
CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT, rider_id INTEGER, kind TEXT NOT NULL,
    message TEXT NOT NULL, read_at TEXT, created_at TEXT NOT NULL,
    FOREIGN KEY(rider_id) REFERENCES riders(id)
);
CREATE TABLE IF NOT EXISTS championship_rounds (
    id INTEGER PRIMARY KEY AUTOINCREMENT, championship_id INTEGER NOT NULL,
    round_no INTEGER NOT NULL, track TEXT NOT NULL, race_date TEXT NOT NULL,
    FOREIGN KEY(championship_id) REFERENCES championships(id)
);
CREATE TABLE IF NOT EXISTS admin_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS race_vault (
    id INTEGER PRIMARY KEY AUTOINCREMENT, race_id INTEGER NOT NULL, kind TEXT NOT NULL,
    path TEXT NOT NULL, created_at TEXT NOT NULL, FOREIGN KEY(race_id) REFERENCES races(id)
);
'''

def _columns(conn, table):
    return {r['name'] for r in conn.execute(f'PRAGMA table_info({table})')}

def _migrate(conn):
    # v0.1.2: main-purse and fastest-lap bonus are separate, while old databases stay intact.
    if 'fast_lap_contribution' not in _columns(conn, 'races'):
        conn.execute('ALTER TABLE races ADD COLUMN fast_lap_contribution REAL NOT NULL DEFAULT 0')
    if 'fast_lap_bonus' not in _columns(conn, 'results'):
        conn.execute('ALTER TABLE results ADD COLUMN fast_lap_bonus REAL NOT NULL DEFAULT 0')

    # v0.1.3: rider avatars and bike-specific championship display classes.
    if 'avatar_path' not in _columns(conn, 'riders'):
        conn.execute('ALTER TABLE riders ADD COLUMN avatar_path TEXT')
    if 'class_name' not in _columns(conn, 'championships'):
        conn.execute("ALTER TABLE championships ADD COLUMN class_name TEXT NOT NULL DEFAULT ''")
    if 'bike_class' not in _columns(conn, 'championships'):
        conn.execute("ALTER TABLE championships ADD COLUMN bike_class TEXT NOT NULL DEFAULT 'Open'")

    # Convert existing championship rows without touching the underlying skill/MMR ladder.
    # This branch only runs when upgrading an existing install; fresh installs are seeded below.
    if conn.execute('SELECT COUNT(*) FROM championships').fetchone()[0] > 0:
        renames = {
            ('MX','Rookie'): ('2027 250 C MX Championship','250 C','250'),
            ('MX','Amateur'): ('2027 250 B MX Championship','250 B','250'),
            ('MX','Expert'): ('2027 250 Pro MX Championship','250 Pro','250'),
            ('MX','Pro'): ('2027 450 Pro MX Championship','450 Pro','450'),
            ('SX','Rookie'): ('2027 250 C SX Championship','250 C','250'),
            ('SX','Amateur'): ('2027 250 B SX Championship','250 B','250'),
            ('SX','Expert'): ('2027 250 Pro SX Championship','250 Pro','250'),
            ('SX','Pro'): ('2027 450 Pro SX Championship','450 Pro','450'),
        }
        for (discipline,skill),(name,class_name,bike) in renames.items():
            row=conn.execute('SELECT id FROM championships WHERE discipline=? AND skill_class=? ORDER BY id LIMIT 1',(discipline,skill)).fetchone()
            if row:
                conn.execute('UPDATE championships SET name=?, class_name=?, bike_class=? WHERE id=?',(name,class_name,bike,row['id']))

        # Rookie and Amateur each get separate 250 and 450 series. Existing 250 row is preserved; create 450 sibling if needed.
        for discipline,season in (('MX','2027 Outdoor'),('SX','2027 Winter')):
            for skill,class_name,fee,champ,platform,min_rc in (
                ('Rookie','450 C',10,2,3,650),
                ('Amateur','450 B',20,4,6,700),
            ):
                if not conn.execute('SELECT 1 FROM championships WHERE discipline=? AND class_name=?',(discipline,class_name)).fetchone():
                    rounds = 8 if skill=='Rookie' else 10
                    conn.execute('''INSERT INTO championships(name,discipline,skill_class,season,active,rounds,per_round_fee,championship_contribution,platform_fee,points_system,min_racecraft,class_name,bike_class)
                                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                                 (f'2027 {class_name} {discipline} Championship',discipline,skill,season,1,rounds,fee,champ,platform,'26-23-21',min_rc,class_name,'450'))

def connect():
    conn = sqlite3.connect(DB_FILE)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    _migrate(conn)
    conn.commit()
    return conn

def _insert_race_if_missing(conn, row):
    if conn.execute('SELECT 1 FROM races WHERE name=?', (row[0],)).fetchone():
        return
    conn.execute('''INSERT INTO races(name,discipline,skill_class,lobby_tier,track,bike_class,start_time,signup_cutoff,purse_lock_time,
                    entry_fee,prize_contribution,fast_lap_contribution,platform_fee,min_riders,max_riders,min_skill,max_skill,min_racecraft,status,featured,broadcast)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', row)

def seed():
    conn = connect()
    if conn.execute('SELECT COUNT(*) FROM riders').fetchone()[0] == 0:
        riders = [
            ('Welchy',311,'WRS Racing','Kawasaki KX450','450cc','Ohio','Motocross lifer. Chasing the next gate drop.',1874,'Expert',934,'A',1840,42,8,19,3),
            ('Ripper27',27,'Privateer','Honda CRF450R','450cc','Michigan','Late braker. Clean racer.',1914,'Expert',905,'A',2120,51,12,26,2),
            ('Apex771',771,'Factory Blue','Yamaha YZ450F','450cc','Texas','SX specialist.',1881,'Expert',842,'B',1495,37,6,14,1),
            ('MotoKid18',18,'Northline MX','KTM 250 SX-F','250cc','Florida','Grinding toward Expert.',1540,'Amateur',952,'A',610,29,4,11,0),
            ('GateDrop96',96,'Independent','Husqvarna FC 250','250cc','California','Smooth is fast.',1488,'Amateur',781,'B',455,24,2,8,0),
            ('DirtyFast44',44,'Independent','GasGas MC 450F','450cc','Nevada','',1810,'Expert',418,'D',720,35,5,10,0),
            ('Rookie222',222,'Independent','Kawasaki KX250','250cc','Ohio','New to paid racing.',1125,'Rookie',910,'A',80,7,0,1,0),
            ('ProOne1',1,'Elite Moto','Honda CRF450R','450cc','Georgia','Defending Pro champion.',2235,'Pro',967,'S',9350,93,31,61,5),
            ('ProSeven7',7,'Redline','KTM 450 SX-F','450cc','Arizona','',2160,'Pro',918,'A',6840,80,21,48,3),
        ]
        conn.executemany('''INSERT INTO riders(username,number,team,bike_model,bike_size,region,bio,skill_rating,skill_class,racecraft_score,racecraft_grade,career_earnings,starts,wins,podiums,championships)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', riders)

    now = datetime.now()
    def dt(days=0,hours=0):
        return (now + timedelta(days=days,hours=hours)).replace(microsecond=0).isoformat()

    # Every entry fee is an explicit three-way split: main purse + fastest-lap pool + platform/operations.
    # Low-entry lobbies exist at every skill level while higher divisions still have access to larger-money races.
    races = [
        ('Rookie $5 Gate Drop','MX','Rookie','Low Entry','Millville Club','250/450',dt(1,1),dt(1,.5),dt(1,.65),5,2.00,.50,2.50,4,20,0,1299,600,'REGISTRATION',1,1),
        ('Amateur $8 Gate Drop','MX','Amateur','Low Entry','RedBud Club','250/450',dt(1,2),dt(1,1.5),dt(1,1.65),8,3.50,.50,4.00,4,20,1300,1649,650,'REGISTRATION',0,1),
        ('Expert $12 Sprint','MX','Expert','Low Entry','Fox Raceway','250/450',dt(1,2.5),dt(1,2),dt(1,2.15),12,5.50,.75,5.75,4,20,1650,1999,650,'REGISTRATION',1,1),
        ('Pro $20 Warm-Up','SX','Pro','Low Entry','Anaheim Stadium','450',dt(1,3),dt(1,2.5),dt(1,2.65),20,9.50,1.50,9.00,4,20,2000,9999,800,'REGISTRATION',0,1),
        ('Friday Night Expert Cash','MX','Expert','Cash','Fox Raceway','450',dt(2,3),dt(2,2),dt(2,2.2),25,15,2,8,4,20,1650,1999,650,'REGISTRATION',1,1),
        ('Saturday Amateur Premier','MX','Amateur','Premier','RedBud','250/450',dt(3,4),dt(3,3),dt(3,3.2),35,22,2,11,4,20,1300,1649,700,'REGISTRATION',0,1),
        ('Sunday Rookie Open','MX','Rookie','Open','Spring Creek','250/450',dt(4,2),dt(4,1),dt(4,1.2),10,5.25,.75,4,4,20,0,1299,600,'REGISTRATION',0,1),
        ('Pro Premier Main','SX','Pro','Premier','Anaheim Stadium','450',dt(5,5),dt(5,4),dt(5,4.2),100,65,7,28,4,20,2000,9999,850,'REGISTRATION',1,1),
        ('Expert Winter SX Cash','SX','Expert','Cash','San Diego Stadium','250/450',dt(6,3),dt(6,2),dt(6,2.2),30,18,2,10,4,20,1650,1999,700,'REGISTRATION',0,1),
    ]
    for race in races:
        _insert_race_if_missing(conn, race)

    # Existing v0.1.0/v0.1.1 races get their former prize contribution split into main purse + fast-lap pool
    # without changing what the rider pays or the platform fee.
    split_defaults = {
        'Friday Night Expert Cash': (15.0, 2.0),
        'Saturday Amateur Premier': (22.0, 2.0),
        'Sunday Rookie Open': (5.25, .75),
        'Pro Premier Main': (65.0, 7.0),
        'Expert Winter SX Cash': (18.0, 2.0),
        'Expert MX Cash - Round Zero': (15.0, 2.0),
        'Pro SX Invitational': (65.0, 7.0),
    }
    for name,(main,fast) in split_defaults.items():
        if conn.execute('SELECT 1 FROM races WHERE name=?',(name,)).fetchone():
            conn.execute('UPDATE races SET prize_contribution=?, fast_lap_contribution=? WHERE name=?',(main,fast,name))

    # Seed official paid entry lists only on a fresh registration dataset.
    if conn.execute('SELECT COUNT(*) FROM registrations').fetchone()[0] == 0:
        rider_ids = {r['username']: r['id'] for r in conn.execute('SELECT id,username FROM riders')}
        reg_plan = {
            'Friday Night Expert Cash':['Welchy','Ripper27','Apex771','DirtyFast44'],
            'Saturday Amateur Premier':['MotoKid18','GateDrop96'],
            'Sunday Rookie Open':['Rookie222'],
            'Pro Premier Main':['ProOne1','ProSeven7'],
            'Expert Winter SX Cash':['Welchy','Apex771'],
            'Expert $12 Sprint':['Welchy','Ripper27','Apex771'],
        }
        for race,names in reg_plan.items():
            rr=conn.execute('SELECT id,entry_fee FROM races WHERE name=?',(race,)).fetchone()
            if not rr: continue
            for i,name in enumerate(names):
                conn.execute('''INSERT OR IGNORE INTO registrations(race_id,rider_id,signed_up_at,payment_status,amount_paid,no_refund_ack)
                                VALUES(?,?,?,?,?,1)''',(rr['id'],rider_ids[name],dt(hours=-i*.35),'PAID',rr['entry_fee']))

    if conn.execute('SELECT COUNT(*) FROM championships').fetchone()[0] == 0:
        champs = [
            ('2027 250 C MX Championship','MX','Rookie','2027 Outdoor',1,8,10,2,3,'26-23-21',650,'250 C','250'),
            ('2027 450 C MX Championship','MX','Rookie','2027 Outdoor',1,8,10,2,3,'26-23-21',650,'450 C','450'),
            ('2027 250 B MX Championship','MX','Amateur','2027 Outdoor',1,10,20,4,6,'26-23-21',700,'250 B','250'),
            ('2027 450 B MX Championship','MX','Amateur','2027 Outdoor',1,10,20,4,6,'26-23-21',700,'450 B','450'),
            ('2027 250 Pro MX Championship','MX','Expert','2027 Outdoor',1,10,35,7,10,'26-23-21',750,'250 Pro','250'),
            ('2027 450 Pro MX Championship','MX','Pro','2027 Outdoor',1,12,75,18,20,'26-23-21',850,'450 Pro','450'),
            ('2027 250 C SX Championship','SX','Rookie','2027 Winter',1,8,10,2,3,'26-23-21',650,'250 C','250'),
            ('2027 450 C SX Championship','SX','Rookie','2027 Winter',1,8,10,2,3,'26-23-21',650,'450 C','450'),
            ('2027 250 B SX Championship','SX','Amateur','2027 Winter',1,10,20,4,6,'26-23-21',700,'250 B','250'),
            ('2027 450 B SX Championship','SX','Amateur','2027 Winter',1,10,20,4,6,'26-23-21',700,'450 B','450'),
            ('2027 250 Pro SX Championship','SX','Expert','2027 Winter',1,12,35,7,10,'26-23-21',750,'250 Pro','250'),
            ('2027 450 Pro SX Championship','SX','Pro','2027 Winter',1,14,85,20,25,'26-23-21',850,'450 Pro','450'),
        ]
        conn.executemany('''INSERT INTO championships(name,discipline,skill_class,season,active,rounds,per_round_fee,championship_contribution,platform_fee,points_system,min_racecraft,class_name,bike_class)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''', champs)

    # Make sure every championship, including newly-added 450 C/B rows on upgraded installs, gets a full schedule.
    mx_tracks=['Fox Raceway','Hangtown','Thunder Valley','High Point','RedBud','Spring Creek','Washougal','Unadilla','Budds Creek','Ironman','Southwick','Pala Finale']
    sx_tracks=['Anaheim 1','San Diego','Anaheim 2','Glendale','Arlington','Daytona','Indianapolis','Seattle','St. Louis','Foxborough','Nashville','Denver','Salt Lake City 1','Salt Lake City 2']
    for c in conn.execute('SELECT * FROM championships'):
        have=conn.execute('SELECT COUNT(*) FROM championship_rounds WHERE championship_id=?',(c['id'],)).fetchone()[0]
        if have >= c['rounds']:
            continue
        tracks=mx_tracks if c['discipline']=='MX' else sx_tracks
        base=datetime(datetime.now().year+1,5,1) if c['discipline']=='MX' else datetime(datetime.now().year+1,1,10)
        existing={x['round_no'] for x in conn.execute('SELECT round_no FROM championship_rounds WHERE championship_id=?',(c['id'],))}
        for n in range(1,c['rounds']+1):
            if n in existing: continue
            conn.execute('INSERT INTO championship_rounds(championship_id,round_no,track,race_date) VALUES(?,?,?,?)',(c['id'],n,tracks[(n-1)%len(tracks)],(base+timedelta(days=7*(n-1))).date().isoformat()))

    if conn.execute('SELECT COUNT(*) FROM results').fetchone()[0] == 0:
        hist=[
            ('Expert MX Cash - Round Zero','MX','Expert','Cash','Budds Creek','450',(now-timedelta(days=7)).isoformat(),(now-timedelta(days=7,hours=1)).isoformat(),(now-timedelta(days=7,hours=.8)).isoformat(),25,15,2,8,4,20,1650,1999,650,'COMPLETE',0,1),
            ('Pro SX Invitational','SX','Pro','Premier','Anaheim Stadium','450',(now-timedelta(days=4)).isoformat(),(now-timedelta(days=4,hours=1)).isoformat(),(now-timedelta(days=4,hours=.8)).isoformat(),100,65,7,28,4,20,2000,9999,850,'COMPLETE',1,1),
        ]
        for race in hist: _insert_race_if_missing(conn,race)
        riders={r['username']:r['id'] for r in conn.execute('SELECT id,username FROM riders')}
        rid={r['name']:r['id'] for r in conn.execute("SELECT id,name FROM races WHERE status='COMPLETE'")}
        rows=[
            (rid['Expert MX Cash - Round Zero'],riders['Ripper27'],1,12,'1:39.422','—',26,68,8,18,2),
            (rid['Expert MX Cash - Round Zero'],riders['Welchy'],2,12,'1:40.011','+4.282',23,41,0,9,1),
            (rid['Expert MX Cash - Round Zero'],riders['Apex771'],3,12,'1:40.510','+8.601',21,27,0,-3,0),
            (rid['Pro SX Invitational'],riders['ProOne1'],1,20,'0:52.884','—',26,216,28,12,1),
            (rid['Pro SX Invitational'],riders['ProSeven7'],2,20,'0:53.102','+2.113',23,130,0,5,0),
        ]
        conn.executemany('''INSERT INTO results(race_id,rider_id,position,laps,best_lap,gap,points,payout,fast_lap_bonus,skill_delta,racecraft_delta)
                            VALUES(?,?,?,?,?,?,?,?,?,?,?)''',rows)

    now_wallet=datetime.now().replace(microsecond=0).isoformat()
    for rr in conn.execute('SELECT id FROM riders'):
        conn.execute('INSERT OR IGNORE INTO wallets(rider_id,balance_cents,currency,updated_at) VALUES(?,?,?,?)',(rr['id'],0,'USD',now_wallet))
    welchy=conn.execute("SELECT id FROM riders WHERE username='Welchy'").fetchone()
    if welchy and conn.execute('SELECT COUNT(*) FROM wallet_transactions WHERE rider_id=?',(welchy['id'],)).fetchone()[0]==0:
        conn.execute('UPDATE wallets SET balance_cents=?,updated_at=? WHERE rider_id=?',(15000,now_wallet,welchy['id']))
        conn.execute('''INSERT INTO wallet_transactions(rider_id,kind,amount_cents,balance_after_cents,status,provider,note,created_at)
                        VALUES(?,?,?,?,?,?,?,?)''',(welchy['id'],'TOP_UP',15000,15000,'POSTED','DEMO','Starter demo wallet balance',now_wallet))

    defaults={
        'no_refunds':'true', 'minimum_riders':'4', 'purse_lock_minutes':'5',
        'broadcast_ai_announcer':'true', 'mx_warm_months':'May-September',
        'sx_winter_months':'November-March', 'payment_provider':'DEMO / APPROVAL REQUIRED',
        'platform_name':'MXB Race Control', 'wallet_enabled':'true', 'wallet_max_balance':'0',
        'wallet_real_money_mode':'false', 'processor_reserve_pct':'0.06',
        'race_fixed_ops_reserve':'4.00', 'minimum_owner_profit':'4.00',
        'fastest_lap_bonus_enabled':'true', 'start_page':'PROFILE'
    }
    for k,v in defaults.items(): conn.execute('INSERT OR IGNORE INTO admin_settings(key,value) VALUES(?,?)',(k,v))
    conn.execute("INSERT INTO meta(key,value) VALUES('schema_version','4') ON CONFLICT(key) DO UPDATE SET value='4'")
    conn.commit(); conn.close()

def money_to_cents(amount):
    from decimal import Decimal, ROUND_HALF_UP
    return int((Decimal(str(amount))*100).quantize(Decimal('1'),rounding=ROUND_HALF_UP))

def wallet_balance(conn,rider_id):
    row=conn.execute('SELECT balance_cents FROM wallets WHERE rider_id=?',(rider_id,)).fetchone()
    return int(row['balance_cents'])/100.0 if row else 0.0

def wallet_credit(conn,rider_id,amount,kind='TOP_UP',provider='DEMO',provider_ref=None,race_id=None,note=''):
    cents=money_to_cents(amount)
    if cents<=0: raise ValueError('Wallet credit must be greater than zero.')
    now=datetime.now().replace(microsecond=0).isoformat()
    with conn:
        conn.execute('INSERT OR IGNORE INTO wallets(rider_id,balance_cents,currency,updated_at) VALUES(?,?,?,?)',(rider_id,0,'USD',now))
        row=conn.execute('SELECT balance_cents FROM wallets WHERE rider_id=?',(rider_id,)).fetchone()
        new=int(row['balance_cents'])+cents
        conn.execute('UPDATE wallets SET balance_cents=?,updated_at=? WHERE rider_id=?',(new,now,rider_id))
        conn.execute('''INSERT INTO wallet_transactions(rider_id,kind,amount_cents,balance_after_cents,status,provider,provider_ref,race_id,note,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?,?)''',(rider_id,kind,cents,new,'POSTED',provider,provider_ref,race_id,note,now))
    return new/100.0

def wallet_debit(conn,rider_id,amount,kind='RACE_ENTRY',race_id=None,note=''):
    cents=money_to_cents(amount)
    if cents<=0: raise ValueError('Wallet debit must be greater than zero.')
    now=datetime.now().replace(microsecond=0).isoformat()
    with conn:
        row=conn.execute('SELECT balance_cents FROM wallets WHERE rider_id=?',(rider_id,)).fetchone()
        bal=int(row['balance_cents']) if row else 0
        if bal<cents: raise ValueError(f'Insufficient Race Wallet balance. Need ${cents/100:.2f}; available ${bal/100:.2f}.')
        new=bal-cents
        conn.execute('UPDATE wallets SET balance_cents=?,updated_at=? WHERE rider_id=?',(new,now,rider_id))
        conn.execute('''INSERT INTO wallet_transactions(rider_id,kind,amount_cents,balance_after_cents,status,provider,race_id,note,created_at)
                        VALUES(?,?,?,?,?,?,?,?,?)''',(rider_id,kind,-cents,new,'POSTED','WALLET',race_id,note,now))
    return new/100.0

def current_purse(conn,race_id):
    race=conn.execute('SELECT * FROM races WHERE id=?',(race_id,)).fetchone()
    paid=conn.execute("SELECT COUNT(*) FROM registrations WHERE race_id=? AND payment_status='PAID'",(race_id,)).fetchone()[0]
    return paid,paid*float(race['prize_contribution'])

def fastest_lap_pool(conn,race_id,paid_override=None):
    race=conn.execute('SELECT * FROM races WHERE id=?',(race_id,)).fetchone()
    paid=paid_override if paid_override is not None else conn.execute("SELECT COUNT(*) FROM registrations WHERE race_id=? AND payment_status='PAID'",(race_id,)).fetchone()[0]
    return paid*float(race['fast_lap_contribution'] or 0)

def payout_split(riders):
    if riders<=0:return []
    if riders<=5:return [0.70,0.30]
    if riders<=8:return [0.50,0.30,0.20]
    if riders<=14:return [0.45,0.27,0.18,0.10]
    return [0.40,0.25,0.17,0.11,0.07]

def setting_float(conn,key,default):
    row=conn.execute('SELECT value FROM admin_settings WHERE key=?',(key,)).fetchone()
    try:return float(row['value']) if row else float(default)
    except Exception:return float(default)

def race_financials(conn,race_id,paid_override=None):
    race=conn.execute('SELECT * FROM races WHERE id=?',(race_id,)).fetchone()
    if not race: raise ValueError('Race not found.')
    paid=paid_override if paid_override is not None else conn.execute("SELECT COUNT(*) FROM registrations WHERE race_id=? AND payment_status='PAID'",(race_id,)).fetchone()[0]
    gross=paid*float(race['entry_fee'])
    main=paid*float(race['prize_contribution'])
    fast=paid*float(race['fast_lap_contribution'] or 0)
    platform=paid*float(race['platform_fee'])
    reserve_pct=setting_float(conn,'processor_reserve_pct',0.06)
    fixed_ops=setting_float(conn,'race_fixed_ops_reserve',4.0)
    reserve=gross*reserve_pct
    net=platform-reserve-fixed_ops
    return {
        'paid_riders':paid,'gross':gross,'main_purse':main,'fast_lap_bonus':fast,
        'total_prizes':main+fast,'platform_gross':platform,'processor_reserve':reserve,
        'fixed_ops_reserve':fixed_ops,'owner_projected_net':net,
        'owner_margin_pct':(net/gross*100.0 if gross else 0.0),
    }
