from __future__ import annotations

import hashlib
import html
import json
import re
import threading
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional

from .config import APPDATA

try:
    from PIL import Image, ImageOps
except Exception:
    Image = None
    ImageOps = None

USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151 Safari/537.36 '
    'MXB-Race-Day-Live/0.2.9'
)

# The shop sometimes names rounds by city and sometimes by the venue/location.
# These aliases improve matching without hard-coding a single season.
TRACK_ALIASES = {
    'Millville Club': ['Millville', 'Spring Creek'],
    'RedBud Club': ['RedBud', 'Buchanan'],
    'San Diego Stadium': ['San Diego'],
    'Fox Raceway': ['Pala', 'Fox Raceway'],
    'Pala Finale': ['Pala', 'Fox Raceway'],
    'Spring Creek': ['Spring Creek', 'Millville'],
    'RedBud': ['RedBud', 'Buchanan'],
    'Anaheim Stadium': ['Anaheim', 'Angel Stadium'],
    'Anaheim 1': ['Anaheim 1', 'A1', 'Anaheim'],
    'Anaheim 2': ['Anaheim 2', 'A2', 'Anaheim'],
    'Salt Lake City 1': ['Salt Lake City', 'SLC'],
    'Salt Lake City 2': ['Salt Lake City', 'SLC'],
    'St. Louis': ['St Louis', 'St. Louis'],
}


# Known race venues use explicit MX Bikes track pages. This prevents broad search
# results such as rider gear, bike liveries, or similarly-named products from being
# used as race-card artwork.
DIRECT_TRACK_SOURCES = {
    ('MX', 'Millville Club'): ('2024 ARLMX RD7 – MILLVILLE', 'https://mxbikes-shop.com/downloads/2024-arlmx-rd7-millville/'),
    ('MX', 'Spring Creek'): ('2024 ARLMX RD7 – MILLVILLE', 'https://mxbikes-shop.com/downloads/2024-arlmx-rd7-millville/'),
    ('MX', 'RedBud Club'): ('2025 ARLMX RD6 – BUCHANAN', 'https://mxbikes-shop.com/downloads/2025-arlmx-rd6-buchanan/'),
    ('MX', 'RedBud'): ('2025 ARLMX RD6 – BUCHANAN', 'https://mxbikes-shop.com/downloads/2025-arlmx-rd6-buchanan/'),
    ('MX', 'Fox Raceway'): ('2025 ARLMX RD1 – PALA', 'https://mxbikes-shop.com/downloads/2025-arlmx-rd1-pala/'),
    ('MX', 'Pala Finale'): ('2025 ARLMX RD1 – PALA', 'https://mxbikes-shop.com/downloads/2025-arlmx-rd1-pala/'),
    ('SX', 'Anaheim Stadium'): ('2025 FXR ARL Supercross Series presented by MotoOption Rd 1', 'https://mxbikes-shop.com/downloads/2025-fxr-arl-supercross-series-presented-by-motooption-round-1/'),
    ('SX', 'Anaheim 1'): ('2025 FXR ARL Supercross Series presented by MotoOption Rd 1', 'https://mxbikes-shop.com/downloads/2025-fxr-arl-supercross-series-presented-by-motooption-round-1/'),
    ('SX', 'Anaheim'): ('2025 FXR ARL Supercross Series presented by MotoOption Rd 1', 'https://mxbikes-shop.com/downloads/2025-fxr-arl-supercross-series-presented-by-motooption-round-1/'),
    ('SX', 'San Diego Stadium'): ('2023 ARL SX ROUND 02 – SAN DIEGO', 'https://www.mxbikes-shop.com/downloads/2023-arl-sx-round-02-san-diego/'),
    ('SX', 'San Diego'): ('2023 ARL SX ROUND 02 – SAN DIEGO', 'https://www.mxbikes-shop.com/downloads/2023-arl-sx-round-02-san-diego/'),
}

DIRECT_TRACK_IMAGES = {
    ('MX', 'Millville Club'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2024/07/track_image_millville_1200x1200.jpg',
    ('MX', 'Spring Creek'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2024/07/track_image_millville_1200x1200.jpg',
    ('MX', 'RedBud Club'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/07/track_image-2.jpg',
    ('MX', 'RedBud'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/07/track_image-2.jpg',
    ('MX', 'Fox Raceway'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/05/track_image-3.jpg',
    ('MX', 'Pala Finale'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/05/track_image-3.jpg',
    ('SX', 'Anaheim Stadium'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/01/track_image.jpg',
    ('SX', 'Anaheim 1'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/01/track_image.jpg',
    ('SX', 'Anaheim'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2025/01/track_image.jpg',
    ('SX', 'San Diego Stadium'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2023/01/thumbnailfinal-copie-1.png',
    ('SX', 'San Diego'): 'https://cdn.mxbikes-shop.com/wp-content/uploads/2023/01/thumbnailfinal-copie-1.png',
}

VERIFIED_SHOP_HOSTS = {'mxbikes-shop.com', 'www.mxbikes-shop.com'}
VERIFIED_IMAGE_HOSTS = VERIFIED_SHOP_HOSTS | {'cdn.mxbikes-shop.com'}

TRACK_MEDIA_CACHE_EPOCH = 'v0517-tracks-recovery'

NON_TRACK_TERMS = {
    'gear', 'jersey', 'pants', 'gloves', 'helmet', 'livery', 'paint', 'graphics',
    'bike', 'bikes', 'rider kit', 'boots', 'goggles', 'skin', 'skins', 'template',
}

SHOP_SEARCH_ENDPOINTS = ('https://mxbikes-shop.com/wp-json/wp/v2/search',)


@dataclass
class TrackMedia:
    discipline: str
    track_name: str
    source_url: str = ''
    image_url: str = ''
    local_path: str = ''
    status: str = 'PENDING'
    resolved_at: str = ''
    title: str = ''


def _now():
    return datetime.now().replace(microsecond=0).isoformat()


def _request(url: str, timeout=12):
    req = urllib.request.Request(
        url,
        headers={
            'User-Agent': USER_AGENT,
            'Accept': 'text/html,application/xhtml+xml,application/json,image/avif,image/webp,image/apng,image/*,*/*;q=0.8',
        },
    )
    return urllib.request.urlopen(req, timeout=timeout)


def _tokens(text: str):
    return set(re.findall(r'[a-z0-9]+', (text or '').lower()))


def _candidate_score(title: str, url: str, discipline: str, aliases: list[str]):
    hay = f'{title} {url}'.lower()
    score = 0
    for alias in aliases:
        toks = _tokens(alias)
        score += sum(6 for t in toks if t in hay)
    if 'arl' in hay:
        score += 8
    if discipline.upper() == 'SX':
        if 'sx' in hay or 'supercross' in hay:
            score += 7
    else:
        if 'mx' in hay or 'motocross' in hay:
            score += 7
    # Current/newer shop posts are preferable when multiple seasons exist.
    for y, pts in ((2026, 5), (2025, 4), (2024, 3), (2023, 2)):
        if str(y) in hay:
            score += pts
            break
    return score


def _extract_meta_image(page_html: str):
    patterns = [
        r'<meta[^>]+property=["\']og:image(?::secure_url)?["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:image(?::secure_url)?["\']',
        r'<meta[^>]+name=["\']twitter:image["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+name=["\']twitter:image["\']',
    ]
    for pat in patterns:
        m = re.search(pat, page_html, re.I)
        if m:
            return html.unescape(m.group(1).strip())
    # WordPress featured images are often the first substantial wp-content image.
    for src in re.findall(r'<img[^>]+src=["\']([^"\']+)["\']', page_html, re.I):
        src = html.unescape(src)
        if 'wp-content/uploads/' in src and not any(x in src.lower() for x in ('logo', 'avatar', 'icon')):
            return src
    return ''



def _shop_host(url: str):
    try:
        return (urllib.parse.urlparse(url).hostname or '').lower()
    except Exception:
        return ''


def _normal_title(text: str):
    text = html.unescape(text or '').lower().replace('–', '-').replace('—', '-')
    return ' '.join(re.findall(r'[a-z0-9]+', text))


def _extract_page_title(page_html: str):
    pats = [
        r'<meta[^>]+property=["\']og:title["\'][^>]+content=["\']([^"\']+)',
        r'<meta[^>]+content=["\']([^"\']+)["\'][^>]+property=["\']og:title["\']',
        r'<h1[^>]*>(.*?)</h1>',
        r'<title[^>]*>(.*?)</title>',
    ]
    for pat in pats:
        m = re.search(pat, page_html, re.I | re.S)
        if m:
            value = re.sub(r'<[^>]+>', ' ', m.group(1))
            value = html.unescape(re.sub(r'\s+', ' ', value)).strip()
            value = re.sub(r'\s*[-|–]\s*MX Bikes Shop\s*$', '', value, flags=re.I).strip()
            if value:
                return value
    return ''


def _verified_source(expected_title: str, source_url: str, page_html: str):
    if _shop_host(source_url) not in VERIFIED_SHOP_HOSTS:
        return False
    actual = _extract_page_title(page_html)
    a, e = _normal_title(actual), _normal_title(expected_title)
    return bool(a and e and (a == e or a.startswith(e + ' ') or e.startswith(a + ' ')))


def _verified_image(url: str):
    return bool(url and _shop_host(url) in VERIFIED_IMAGE_HOSTS and 'wp-content/uploads/' in url)


class TrackMediaResolver:
    """Resolves MXB-Shop track artwork without redistributing shop images.

    The release ZIP contains no MXB-Shop photography. The app resolves the source
    page on the rider's PC, caches a resized thumbnail under APPDATA, records the
    original source URL, and can always open that source page from Event Details.
    """

    def __init__(self, db_connect: Callable):
        self.db_connect = db_connect
        self.cache_dir = APPDATA / 'track_media'
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self._reset_stale_cache_once()
        self._locks: dict[str, threading.Lock] = {}
        self._guard = threading.Lock()
        self._network_gate = threading.Semaphore(4)

    def _reset_stale_cache_once(self):
        """Drop pre-v0.2.8 track thumbnails so bad gear/random matches cannot survive."""
        marker = self.cache_dir / f'.{TRACK_MEDIA_CACHE_EPOCH}'
        if marker.exists():
            return
        old_paths = []
        conn = self.db_connect()
        try:
            try:
                old_paths = [r[0] for r in conn.execute('SELECT local_path FROM track_media').fetchall() if r[0]]
                conn.execute('DELETE FROM track_media')
                conn.commit()
            except Exception:
                # Database migrations may not have created the table yet on a fresh install.
                pass
        finally:
            conn.close()
        for raw in old_paths:
            try: Path(raw).unlink(missing_ok=True)
            except Exception: pass
        for f in self.cache_dir.iterdir():
            if f.is_file():
                try: f.unlink(missing_ok=True)
                except Exception: pass
        try: marker.write_text(TRACK_MEDIA_CACHE_EPOCH, encoding='utf-8')
        except Exception: pass

    def _key(self, discipline, track):
        return f'{discipline.upper()}::{track.strip().lower()}'

    def _lock_for(self, key):
        with self._guard:
            return self._locks.setdefault(key, threading.Lock())

    def get_cached(self, discipline: str, track: str) -> TrackMedia:
        conn = self.db_connect()
        try:
            row = conn.execute(
                'SELECT * FROM track_media WHERE discipline=? AND track_name=?',
                (discipline.upper(), track),
            ).fetchone()
            if not row:
                return TrackMedia(discipline.upper(), track)
            direct = DIRECT_TRACK_SOURCES.get((discipline.upper(), track))
            if direct and (row['source_url'] or '') != direct[1]:
                # Old builds could cache a false-positive shop result (including gear).
                # Hide that bad match immediately and let resolve_async replace it.
                old_path = row['local_path'] or ''
                conn.execute('DELETE FROM track_media WHERE discipline=? AND track_name=?', (discipline.upper(), track))
                conn.commit()
                if old_path:
                    try: Path(old_path).unlink(missing_ok=True)
                    except Exception: pass
                return TrackMedia(discipline.upper(), track)
            return TrackMedia(
                discipline=row['discipline'], track_name=row['track_name'],
                source_url=row['source_url'] or '', image_url=row['image_url'] or '',
                local_path=row['local_path'] or '', status=row['status'] or 'PENDING',
                resolved_at=row['resolved_at'] or '', title=row['title'] or '',
            )
        finally:
            conn.close()

    def _save(self, media: TrackMedia):
        conn = self.db_connect()
        try:
            conn.execute(
                '''INSERT INTO track_media(discipline,track_name,source_url,image_url,local_path,status,resolved_at,title)
                   VALUES(?,?,?,?,?,?,?,?)
                   ON CONFLICT(discipline,track_name) DO UPDATE SET
                     source_url=excluded.source_url,image_url=excluded.image_url,
                     local_path=excluded.local_path,status=excluded.status,
                     resolved_at=excluded.resolved_at,title=excluded.title''',
                (media.discipline, media.track_name, media.source_url, media.image_url,
                 media.local_path, media.status, media.resolved_at, media.title),
            )
            conn.commit()
        finally:
            conn.close()

    def _search_candidates(self, query: str):
        return []

    def _search_html_fallback(self, query: str):
        return []

    def _find_source(self, discipline: str, track: str):
        direct = DIRECT_TRACK_SOURCES.get((discipline.upper(), track))
        return direct if direct else ('', '')

    def _download_image(self, url: str, discipline: str, track: str):
        if not url:
            return ''
        with _request(url, timeout=20) as r:
            data = r.read(8 * 1024 * 1024 + 1)
            ctype = (r.headers.get('Content-Type') or '').lower()
        if len(data) > 8 * 1024 * 1024:
            raise ValueError('Track image is too large to cache.')
        if ctype and 'image' not in ctype:
            raise ValueError(f'Track photo URL did not return an image ({ctype}).')
        digest = hashlib.sha1(f'{discipline}|{track}|{url}'.encode('utf-8')).hexdigest()[:16]
        raw = self.cache_dir / f'{digest}.download'
        raw.write_bytes(data)
        if Image is None:
            # Pillow should be installed by the launcher. Keep bytes for diagnostics.
            return str(raw)
        out = self.cache_dir / f'{digest}.png'
        with Image.open(raw) as im:
            im = im.convert('RGB')
            im = ImageOps.fit(im, (960, 540), method=Image.Resampling.LANCZOS)
            im.save(out, 'PNG', optimize=True)
        try:
            raw.unlink()
        except Exception:
            pass
        return str(out)

    def resolve(self, discipline: str, track: str, force=False) -> TrackMedia:
        discipline = discipline.upper().strip()
        track = track.strip()
        key = self._key(discipline, track)
        with self._lock_for(key):
            cached = self.get_cached(discipline, track)
            if not force and cached.status == 'READY' and cached.local_path and Path(cached.local_path).exists():
                return cached
            if not force and cached.status == 'NOT_FOUND' and cached.resolved_at:
                try:
                    when = datetime.fromisoformat(cached.resolved_at)
                    if datetime.now() - when < timedelta(hours=12):
                        return cached
                except Exception:
                    pass
            media = TrackMedia(discipline, track, status='RESOLVING', resolved_at=_now())
            self._save(media)
            try:
                with self._network_gate:
                    title, source = self._find_source(discipline, track)
                    if not source:
                        media.status = 'NOT_FOUND'; media.resolved_at = _now(); self._save(media); return media
                    image_url = DIRECT_TRACK_IMAGES.get((discipline, track), '')
                    if not _verified_image(image_url):
                        media.status = 'NOT_FOUND'; media.resolved_at = _now(); self._save(media); return media
                    local = self._download_image(image_url, discipline, track)
                media.title = title
                media.source_url = source
                media.image_url = image_url
                media.local_path = local
                media.status = 'READY' if local else 'NOT_FOUND'
                media.resolved_at = _now()
                self._save(media)
                return media
            except Exception as exc:
                media.status = 'ERROR'
                media.resolved_at = _now()
                self._save(media)
                conn = self.db_connect()
                try:
                    conn.execute('INSERT INTO sync_errors(area,message,created_at) VALUES(?,?,?)',
                                 ('TRACK_MEDIA', f'{discipline} {track}: {exc}', _now()))
                    conn.commit()
                finally:
                    conn.close()
                return media

    def resolve_async(self, discipline: str, track: str, callback: Optional[Callable] = None, force=False):
        def work():
            media = self.resolve(discipline, track, force=force)
            if callback:
                try:
                    callback(media)
                except Exception:
                    pass
        threading.Thread(target=work, daemon=True, name=f'TrackMedia-{track[:18]}').start()
