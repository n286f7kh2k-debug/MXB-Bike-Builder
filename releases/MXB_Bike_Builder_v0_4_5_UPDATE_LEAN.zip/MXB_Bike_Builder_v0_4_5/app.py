from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

from mxb_builder.windows_integration import ensure_desktop_shortcut
ensure_desktop_shortcut()

from mxb_builder.main_window import run_app

if __name__ == "__main__":
    raise SystemExit(run_app())
