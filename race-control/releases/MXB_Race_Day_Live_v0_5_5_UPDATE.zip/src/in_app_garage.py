from __future__ import annotations

import base64
import hashlib
import json
import math
import os
import re
import struct
import threading
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageTk
except Exception:
    Image = ImageDraw = ImageTk = None


class GarageModelError(RuntimeError):
    pass


REGISTRY_URL = 'https://raw.githubusercontent.com/n286f7kh2k-debug/MXB-Bike-Builder/main/race-control/garage-model-registry.json'
REGISTRY_TTL_SECONDS = 21600
USER_AGENT = 'MXB-Race-Day-Live-Garage/0.5.2'


def _appdata_root():
    raw = os.environ.get('APPDATA')
    if raw:
        return Path(raw) / 'MXB Race Day Live'
    return Path.home() / '.mxb_race_day_live'


def _safe_name(value):
    return re.sub(r'[^a-zA-Z0-9._-]+', '_', str(value or '').strip())[:120] or 'bike'


class Mesh:
    MAX_FACES = 5500

    def __init__(self, vertices, faces, source, face_colors=None, model_kind='source'):
        if len(vertices) < 3 or not faces:
            raise GarageModelError('No readable 3D geometry was found in the source model.')
        self.source = source
        self.model_kind = model_kind
        self.vertices = list(vertices)
        raw_faces = list(faces)
        raw_colors = list(face_colors or [])
        if len(raw_faces) > self.MAX_FACES:
            step = max(1, len(raw_faces) // self.MAX_FACES)
            keep = list(range(0, len(raw_faces), step))[:self.MAX_FACES]
            self.faces = [raw_faces[i] for i in keep]
            self.face_colors = [raw_colors[i] if i < len(raw_colors) else None for i in keep]
        else:
            self.faces = raw_faces
            self.face_colors = [raw_colors[i] if i < len(raw_colors) else None for i in range(len(raw_faces))]
        self._normalize()

    def _normalize(self):
        xs = [v[0] for v in self.vertices]
        ys = [v[1] for v in self.vertices]
        zs = [v[2] for v in self.vertices]
        cx = (min(xs) + max(xs)) / 2.0
        cy = (min(ys) + max(ys)) / 2.0
        cz = (min(zs) + max(zs)) / 2.0
        span = max(max(xs)-min(xs), max(ys)-min(ys), max(zs)-min(zs), 1e-6)
        scale = 2.15 / span
        self.vertices = [((x-cx)*scale, (y-cy)*scale, (z-cz)*scale) for x,y,z in self.vertices]


def _load_obj(path: Path):
    verts, faces = [], []
    with path.open('r', encoding='utf-8', errors='ignore') as f:
        for raw in f:
            line = raw.strip()
            if not line or line.startswith('#'):
                continue
            parts = line.split()
            if not parts:
                continue
            if parts[0] == 'v' and len(parts) >= 4:
                try:
                    verts.append((float(parts[1]), float(parts[2]), float(parts[3])))
                except Exception:
                    pass
            elif parts[0] == 'f' and len(parts) >= 4:
                idx = []
                for token in parts[1:]:
                    try:
                        i = int(token.split('/')[0])
                        i = len(verts) + i if i < 0 else i - 1
                        if 0 <= i < len(verts):
                            idx.append(i)
                    except Exception:
                        pass
                if len(idx) >= 3:
                    a = idx[0]
                    for j in range(1, len(idx)-1):
                        faces.append((a, idx[j], idx[j+1]))
    return Mesh(verts, faces, path, model_kind='local')


def _load_ascii_ply(path: Path):
    with path.open('r', encoding='utf-8', errors='ignore') as f:
        header = []
        while True:
            line = f.readline()
            if not line:
                raise GarageModelError('Invalid PLY file.')
            header.append(line.strip())
            if line.strip() == 'end_header':
                break
        if not header or header[0] != 'ply' or 'format ascii 1.0' not in header:
            raise GarageModelError('Only ASCII PLY source geometry is supported in Garage.')
        vcount = fcount = 0
        for line in header:
            p = line.split()
            if len(p) == 3 and p[0] == 'element' and p[1] == 'vertex':
                vcount = int(p[2])
            elif len(p) == 3 and p[0] == 'element' and p[1] == 'face':
                fcount = int(p[2])
        verts = []
        for _ in range(vcount):
            p = f.readline().split()
            if len(p) >= 3:
                verts.append((float(p[0]), float(p[1]), float(p[2])))
        faces = []
        for _ in range(fcount):
            p = f.readline().split()
            if not p:
                continue
            n = int(p[0]); idx = [int(x) for x in p[1:1+n]]
            if len(idx) >= 3:
                a = idx[0]
                for j in range(1, len(idx)-1):
                    faces.append((a, idx[j], idx[j+1]))
        return Mesh(verts, faces, path, model_kind='local')


def _load_stl(path: Path):
    data = path.read_bytes()
    if len(data) >= 84:
        count = struct.unpack_from('<I', data, 80)[0]
        if 84 + count * 50 == len(data):
            verts, faces, lookup = [], [], {}
            offset = 84
            for _ in range(count):
                offset += 12
                tri = []
                for _v in range(3):
                    xyz = struct.unpack_from('<fff', data, offset); offset += 12
                    key = tuple(round(float(x), 6) for x in xyz)
                    idx = lookup.get(key)
                    if idx is None:
                        idx = len(verts); lookup[key] = idx; verts.append(tuple(float(x) for x in xyz))
                    tri.append(idx)
                faces.append(tuple(tri)); offset += 2
            return Mesh(verts, faces, path, model_kind='local')
    verts, faces, tri = [], [], []
    for raw in data.decode('utf-8', errors='ignore').splitlines():
        p = raw.strip().split()
        if len(p) == 4 and p[0].lower() == 'vertex':
            try:
                verts.append((float(p[1]), float(p[2]), float(p[3])))
                tri.append(len(verts)-1)
                if len(tri) == 3:
                    faces.append(tuple(tri)); tri = []
            except Exception:
                pass
    return Mesh(verts, faces, path, model_kind='local')


_COMPONENTS = {
    5120: ('b', 1), 5121: ('B', 1), 5122: ('h', 2), 5123: ('H', 2),
    5125: ('I', 4), 5126: ('f', 4),
}
_TYPE_SIZE = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}


def _read_accessor(doc, buffers, accessor_index):
    acc = doc['accessors'][accessor_index]
    view = doc['bufferViews'][acc['bufferView']]
    comp_type = int(acc['componentType'])
    fmt, comp_bytes = _COMPONENTS[comp_type]
    count = int(acc['count'])
    ncomp = _TYPE_SIZE[acc['type']]
    stride = int(view.get('byteStride') or (comp_bytes * ncomp))
    offset = int(view.get('byteOffset') or 0) + int(acc.get('byteOffset') or 0)
    data = buffers[int(view.get('buffer', 0))]
    out = []
    unpack = struct.Struct('<' + fmt * ncomp)
    for i in range(count):
        pos = offset + i * stride
        out.append(unpack.unpack_from(data, pos))
    return out


def _mesh_from_gltf(doc, buffers, source):
    verts, faces, colors = [], [], []
    materials = doc.get('materials') or []
    for mesh in doc.get('meshes') or []:
        for prim in mesh.get('primitives') or []:
            attrs = prim.get('attributes') or {}
            if 'POSITION' not in attrs or int(prim.get('mode', 4)) != 4:
                continue
            positions = _read_accessor(doc, buffers, int(attrs['POSITION']))
            base = len(verts)
            verts.extend((float(v[0]), float(v[1]), float(v[2])) for v in positions)
            if 'indices' in prim:
                raw_idx = [int(v[0]) for v in _read_accessor(doc, buffers, int(prim['indices']))]
            else:
                raw_idx = list(range(len(positions)))
            mat_color = None
            mi = prim.get('material')
            if mi is not None and int(mi) < len(materials):
                factor = (((materials[int(mi)].get('pbrMetallicRoughness') or {}).get('baseColorFactor')) or [0.62,0.65,0.7,1])
                mat_color = tuple(max(0, min(255, int(float(c)*255))) for c in factor[:3])
            for i in range(0, len(raw_idx)-2, 3):
                faces.append((base+raw_idx[i], base+raw_idx[i+1], base+raw_idx[i+2]))
                colors.append(mat_color)
    return Mesh(verts, faces, source, face_colors=colors, model_kind='local')


def _load_glb(path: Path):
    data = path.read_bytes()
    if len(data) < 20 or data[:4] != b'glTF':
        raise GarageModelError('Invalid GLB file.')
    magic, version, total = struct.unpack_from('<4sII', data, 0)
    if version != 2 or total > len(data):
        raise GarageModelError('Unsupported GLB version.')
    off = 12; doc = None; bins = []
    while off + 8 <= total:
        length, ctype = struct.unpack_from('<II', data, off); off += 8
        chunk = data[off:off+length]; off += length
        if ctype == 0x4E4F534A:
            doc = json.loads(chunk.decode('utf-8').rstrip('\x00 \t\r\n'))
        elif ctype == 0x004E4942:
            bins.append(chunk)
    if doc is None or not bins:
        raise GarageModelError('GLB is missing JSON or binary geometry.')
    return _mesh_from_gltf(doc, bins, path)


def _load_gltf(path: Path):
    doc = json.loads(path.read_text(encoding='utf-8'))
    buffers = []
    for buf in doc.get('buffers') or []:
        uri = str(buf.get('uri') or '')
        if uri.startswith('data:'):
            payload = uri.split(',', 1)[1]
            buffers.append(base64.b64decode(payload))
        else:
            p = (path.parent / uri).resolve()
            buffers.append(p.read_bytes())
    return _mesh_from_gltf(doc, buffers, path)


def load_mesh(path: Path):
    ext = path.suffix.lower()
    if ext == '.obj': return _load_obj(path)
    if ext == '.stl': return _load_stl(path)
    if ext == '.ply': return _load_ascii_ply(path)
    if ext == '.glb': return _load_glb(path)
    if ext == '.gltf': return _load_gltf(path)
    raise GarageModelError(f'Unsupported source format: {ext}')


class _MeshBuilder:
    def __init__(self):
        self.v=[]; self.f=[]; self.c=[]

    def _push(self, verts, faces, color):
        base=len(self.v); self.v.extend(verts)
        for face in faces:
            self.f.append(tuple(base+i for i in face)); self.c.append(color)

    def box(self, center, size, color):
        cx,cy,cz=center; sx,sy,sz=(s/2 for s in size)
        v=[(cx+dx*sx,cy+dy*sy,cz+dz*sz) for dx,dy,dz in
           [(-1,-1,-1),(1,-1,-1),(1,1,-1),(-1,1,-1),(-1,-1,1),(1,-1,1),(1,1,1),(-1,1,1)]]
        f=[(0,1,2),(0,2,3),(4,6,5),(4,7,6),(0,4,5),(0,5,1),
           (3,2,6),(3,6,7),(1,5,6),(1,6,2),(0,3,7),(0,7,4)]
        self._push(v,f,color)

    def tube(self, a, b, radius, color, segments=10):
        ax,ay,az=a; bx,by,bz=b
        dx,dy,dz=bx-ax,by-ay,bz-az
        length=math.sqrt(dx*dx+dy*dy+dz*dz) or 1.0
        ux,uy,uz=dx/length,dy/length,dz/length
        tx,ty,tz=(0.0,0.0,1.0) if abs(uz)<0.9 else (0.0,1.0,0.0)
        vx,vy,vz=uy*tz-uz*ty, uz*tx-ux*tz, ux*ty-uy*tx
        vl=math.sqrt(vx*vx+vy*vy+vz*vz) or 1.0; vx,vy,vz=vx/vl,vy/vl,vz/vl
        wx,wy,wz=uy*vz-uz*vy, uz*vx-ux*vz, ux*vy-uy*vx
        verts=[]
        for p in (a,b):
            px,py,pz=p
            for i in range(segments):
                t=2*math.pi*i/segments; ct,st=math.cos(t),math.sin(t)
                verts.append((px+radius*(vx*ct+wx*st),py+radius*(vy*ct+wy*st),pz+radius*(vz*ct+wz*st)))
        faces=[]
        for i in range(segments):
            j=(i+1)%segments
            faces.extend([(i,j,segments+j),(i,segments+j,segments+i)])
        self._push(verts,faces,color)

    def torus(self, center, major, minor, color, major_segments=22, minor_segments=6):
        cx,cy,cz=center; verts=[]; faces=[]
        for i in range(major_segments):
            u=2*math.pi*i/major_segments; cu,su=math.cos(u),math.sin(u)
            for j in range(minor_segments):
                v=2*math.pi*j/minor_segments; cv,sv=math.cos(v),math.sin(v)
                rr=major+minor*cv
                verts.append((cx+rr*cu, cy+rr*su, cz+minor*sv))
        for i in range(major_segments):
            ni=(i+1)%major_segments
            for j in range(minor_segments):
                nj=(j+1)%minor_segments
                a=i*minor_segments+j; b=ni*minor_segments+j; c=ni*minor_segments+nj; d=i*minor_segments+nj
                faces.extend([(a,b,c),(a,c,d)])
        self._push(verts,faces,color)


def _brand_color(bike_id):
    s=str(bike_id or '').lower()
    table=[
        (('kaw','kx'),(42,190,70)), (('honda','crf','cr250','cr500'),(210,45,42)),
        (('yam','yz','yzf'),(32,80,210)), (('ktm','sxf','sx-f'),(240,105,22)),
        (('husq','fc','tc'),(230,232,235)), (('gasgas','mc ' ,'gas'),(205,35,35)),
        (('suz','rmz','rm-z'),(235,205,25)), (('tm','mx 250','mx 450'),(55,135,220)),
        (('triumph','tf250','tf450'),(210,190,35)), (('beta','rx'),(205,45,45)),
        (('fantic','xxf'),(45,90,185)), (('stark','varg'),(235,235,235)), (('alta',),(185,35,35)),
    ]
    for keys,color in table:
        if any(k in s for k in keys): return color
    return (95,145,205)


def _displacement(bike_id):
    vals=[int(x) for x in re.findall(r'(?<!\d)(\d{2,4})(?!\d)',str(bike_id or ''))]
    vals=[x for x in vals if 50<=x<=700]
    return vals[-1] if vals else 250


def generate_proxy_mesh(bike_id):
    bid=str(bike_id or 'MX Bike')
    cc=_displacement(bid)
    mini=cc<=100
    base=_brand_color(bid); dark=tuple(max(12,int(c*.42)) for c in base)
    black=(24,26,29); metal=(125,132,142); light=(180,184,190)
    b=_MeshBuilder()
    rear=(-0.76,-0.46,0); front=(0.78,-0.46,0)
    rr=0.42 if mini else 0.48; fr=0.45 if mini else 0.52
    b.torus(rear,rr,0.055 if mini else 0.065,black)
    b.torus(front,fr,0.05 if mini else 0.06,black)
    b.torus(rear,rr*0.76,0.022,metal,20,5); b.torus(front,fr*0.76,0.02,metal,20,5)
    # Frame / suspension
    pivot=(-0.14,-0.10,0); head=(0.30,0.47,0); seat=(-0.22,0.50,0)
    b.tube(pivot,rear,0.045,metal,8); b.tube((pivot[0],pivot[1],0.10),(rear[0],rear[1],0.10),0.03,metal,8)
    b.tube(pivot,head,0.045,dark,8); b.tube(seat,head,0.04,dark,8); b.tube(seat,pivot,0.04,dark,8)
    for z in (-0.075,0.075):
        b.tube((front[0],front[1],z),(0.34,0.58,z),0.026,metal,8)
    b.tube((0.29,0.60,-0.23),(0.29,0.60,0.23),0.026,metal,8)
    # Engine / battery
    electric=any(k in bid.lower() for k in ('stark','varg','alta','electric'))
    engine_h=0.27 if cc<200 else 0.34
    b.box((-0.02,0.02,0),(0.38,engine_h,0.30),dark if electric else metal)
    if electric:b.box((-0.20,0.13,0),(0.20,0.42,0.28),(65,70,76))
    # Seat, tank/shrouds, fenders, plates
    b.box((-0.28,0.55,0),(0.58,0.11,0.24),black)
    b.box((0.05,0.43,0),(0.42,0.30,0.34),base)
    b.box((0.34,0.36,0),(0.28,0.34,0.08),base)
    b.box((-0.58,0.55,0),(0.48,0.08,0.20),base)
    b.box((0.57,0.13,0),(0.50,0.055,0.16),base)
    b.box((0.38,0.46,0),(0.10,0.25,0.26),(235,235,235))
    # bars and controls
    b.tube((0.27,0.65,-0.28),(0.27,0.65,0.28),0.018,metal,8)
    b.tube((0.27,0.60,0),(0.27,0.70,0),0.02,metal,8)
    # exhaust on 4-stroke-ish bikes; expansion chamber hint on small/2T.
    two_stroke=('2t' in bid.lower()) or cc in (85,125)
    if two_stroke:
        b.tube((0.05,0.08,0.18),(0.30,0.18,0.20),0.07,light,9)
        b.tube((0.30,0.18,0.20),(-0.28,0.42,0.18),0.045,light,9)
    else:
        b.tube((0.12,0.04,0.18),(-0.10,0.30,0.19),0.028,light,8)
        b.tube((-0.10,0.30,0.19),(-0.52,0.43,0.20),0.03,light,8)
    b.tube((-0.52,0.43,0.20),(-0.72,0.48,0.20),0.055,metal,9)
    return Mesh(b.v,b.f,Path('procedural_'+_safe_name(bid)+'.mesh'),face_colors=b.c,model_kind='procedural')


def _shade_color(color, factor):
    base=color or (130,138,148)
    return tuple(max(10,min(245,int(c*factor))) for c in base)


def render_mesh(mesh: Mesh, yaw: float, pitch: float, zoom: float, width: int, height: int):
    if Image is None or ImageDraw is None:
        raise GarageModelError('Pillow is unavailable, so the in-app 3D renderer cannot draw a frame.')
    width=max(360,min(1100,int(width))); height=max(260,min(700,int(height)))
    image=Image.new('RGB',(width,height),(5,7,9)); draw=ImageDraw.Draw(image,'RGB')
    # subtle floor / shadow keeps the proxy readable without expensive effects
    draw.ellipse((width*.19,height*.72,width*.81,height*.88),fill=(10,12,14))
    cx,cy=width/2.0,height/2.0
    scale=min(width,height)*0.39*max(0.45,min(2.8,zoom))
    cyaw,syaw=math.cos(yaw),math.sin(yaw); cp,sp=math.cos(pitch),math.sin(pitch)
    pts=[]
    for x,y,z in mesh.vertices:
        x1=x*cyaw-z*syaw; z1=x*syaw+z*cyaw
        y2=y*cp-z1*sp; z2=y*sp+z1*cp
        d=4.3+z2; persp=4.3/max(1.15,d)
        pts.append((cx+x1*scale*persp,cy-y2*scale*persp,z2))
    tris=[]
    for fi,face in enumerate(mesh.faces):
        try:
            a,b,c=face; pa,pb,pc=pts[a],pts[b],pts[c]
            cross=(pb[0]-pa[0])*(pc[1]-pa[1])-(pb[1]-pa[1])*(pc[0]-pa[0])
            if cross>=0:continue
            depth=(pa[2]+pb[2]+pc[2])/3.0
            color=mesh.face_colors[fi] if fi<len(mesh.face_colors) else None
            tris.append((depth,pa,pb,pc,color))
        except Exception:pass
    tris.sort(reverse=True,key=lambda t:t[0])
    for depth,pa,pb,pc,color in tris:
        factor=max(.46,min(1.18,.86-depth*.16))
        draw.polygon(((pa[0],pa[1]),(pb[0],pb[1]),(pc[0],pc[1])),fill=_shade_color(color,factor))
    return image


class InAppGarageRenderer:
    """Nonblocking Race Day Live Garage renderer with universal fallback.

    Exact/authorized readable meshes are preferred. Compiled EDF is never decoded or
    launched. When no legal source geometry exists, a lightweight procedural motocross
    bike is generated so every installed bike still has an immediate interactive 3D view.
    """

    SOURCE_EXTS=('.obj','.stl','.ply','.glb','.gltf')

    def __init__(self, garage):
        self.garage=garage
        self.yaw=-0.65; self.pitch=-0.18; self.zoom=1.0
        self._mesh_cache={}; self._source_cache={}; self._registry_cache=None
        self._executor=ThreadPoolExecutor(max_workers=1,thread_name_prefix='RDLGarage3D')
        self._token=0; self._lock=threading.Lock(); self._drag=None; self._after_id=None
        self._canvas=None; self._bike_getter=None; self._status_cb=None

    @property
    def supported(self):return Image is not None and ImageTk is not None

    def invalidate_cache(self):
        self._source_cache.clear(); self._mesh_cache.clear(); self._registry_cache=None

    def _local_source(self,bike_id):
        roots=[]
        try:
            for rec in self.garage.bike_records():
                if str(rec.get('id','')).lower()==bike_id.lower():
                    raw=rec.get('path') or rec.get('folder') or ''
                    if raw:roots.append(Path(raw))
                    break
        except Exception:pass
        try:
            mods=self.garage.mods_root()
            if mods:roots.extend([Path(mods)/'bikes'/bike_id,Path(mods)/'Bikes'/bike_id])
        except Exception:pass
        seen=set()
        for root in roots:
            try:
                root=root if root.is_dir() else root.parent
                key=str(root.resolve()).lower()
                if key in seen or not root.is_dir():continue
                seen.add(key)
                for stem in ('model',bike_id):
                    for ext in self.SOURCE_EXTS:
                        p=root/(stem+ext)
                        if p.is_file():return p
                for sub in ('source','Source','template','Template','3d','3D','garage','Garage'):
                    d=root/sub
                    if not d.is_dir():continue
                    for ext in self.SOURCE_EXTS:
                        found=next(iter(sorted(d.glob('*'+ext))),None)
                        if found:return found
                for ext in self.SOURCE_EXTS:
                    found=next(iter(sorted(root.glob('*'+ext))),None)
                    if found:return found
            except Exception:pass
        return None

    def _registry_paths(self):
        root=_appdata_root()/'garage_models'; root.mkdir(parents=True,exist_ok=True)
        return root,root/'registry.json'

    def _load_registry(self):
        if self._registry_cache is not None:return self._registry_cache
        cache_root,cache_file=self._registry_paths()
        data=None
        try:
            if cache_file.is_file() and time.time()-cache_file.stat().st_mtime<REGISTRY_TTL_SECONDS:
                data=json.loads(cache_file.read_text(encoding='utf-8'))
        except Exception:data=None
        if data is None:
            try:
                req=urllib.request.Request(REGISTRY_URL+'?v='+str(time.time_ns()),headers={'User-Agent':USER_AGENT,'Cache-Control':'no-cache'})
                with urllib.request.urlopen(req,timeout=7) as r:
                    raw=r.read(2_000_000)
                data=json.loads(raw.decode('utf-8-sig'))
                cache_file.write_text(json.dumps(data,indent=2),encoding='utf-8')
            except Exception:
                try:
                    if cache_file.is_file():data=json.loads(cache_file.read_text(encoding='utf-8'))
                except Exception:data=None
        if data is None:
            try:
                bundled=Path(__file__).with_name('garage_model_registry.json')
                if bundled.is_file():data=json.loads(bundled.read_text(encoding='utf-8'))
            except Exception:data=None
        if not isinstance(data,dict):data={'version':1,'models':[]}
        self._registry_cache=data
        return data

    def _registry_entry(self,bike_id):
        bid=bike_id.lower()
        for entry in self._load_registry().get('models') or []:
            if not isinstance(entry,dict) or not entry.get('approved'):continue
            license_name=str(entry.get('license') or '').strip(); source=str(entry.get('source') or '').strip()
            sha=str(entry.get('sha256') or '').strip().lower(); url=str(entry.get('url') or '').strip()
            if not license_name or not source or len(sha)!=64 or any(c not in '0123456789abcdef' for c in sha):continue
            if not url.startswith('https://'):continue
            match=entry.get('match') or {}
            ids=[str(x).lower() for x in (match.get('bike_ids') or [])]
            contains=[str(x).lower() for x in (match.get('contains') or [])]
            if bid in ids or any(x and x in bid for x in contains):
                return entry
        return None

    def _download_registry_model(self,bike_id,entry):
        cache_root,_=self._registry_paths(); model_dir=cache_root/'models'; model_dir.mkdir(parents=True,exist_ok=True)
        sha=str(entry['sha256']).lower(); fmt=str(entry.get('format') or Path(entry['url']).suffix.lstrip('.')).lower()
        if fmt not in ('obj','stl','ply','glb','gltf'):return None
        out=model_dir/f'{_safe_name(bike_id)}_{sha[:12]}.{fmt}'
        if out.is_file():
            try:
                if hashlib.sha256(out.read_bytes()).hexdigest()==sha:return out
            except Exception:pass
            out.unlink(missing_ok=True)
        req=urllib.request.Request(str(entry['url']),headers={'User-Agent':USER_AGENT})
        tmp=out.with_suffix(out.suffix+'.part')
        h=hashlib.sha256(); size=0
        try:
            with urllib.request.urlopen(req,timeout=20) as src,tmp.open('wb') as dst:
                while True:
                    chunk=src.read(1024*1024)
                    if not chunk:break
                    size+=len(chunk)
                    if size>120*1024*1024:raise GarageModelError('Garage model download exceeded 120 MB.')
                    h.update(chunk);dst.write(chunk)
            if h.hexdigest()!=sha:raise GarageModelError('Garage model failed SHA-256 verification.')
            os.replace(tmp,out);return out
        finally:
            try:tmp.unlink(missing_ok=True)
            except Exception:pass

    def _resolve_mesh(self,bike_id):
        local=self._local_source(bike_id)
        if local:return self._mesh_for(local,'local'), 'exact', local.name
        entry=self._registry_entry(bike_id)
        if entry:
            try:
                remote=self._download_registry_model(bike_id,entry)
                if remote:return self._mesh_for(remote,'authorized'), 'authorized', str(entry.get('name') or remote.name)
            except Exception:
                pass
        key=('proxy',bike_id.lower())
        mesh=self._mesh_cache.get(key)
        if mesh is None:
            mesh=generate_proxy_mesh(bike_id);self._mesh_cache[key]=mesh
        return mesh,'proxy',bike_id

    def _mesh_for(self,source:Path,kind='local'):
        try:
            st=source.stat();key=(str(source.resolve()).lower(),int(st.st_mtime_ns),int(st.st_size))
        except Exception:key=(str(source).lower(),0,0)
        mesh=self._mesh_cache.get(key)
        if mesh is None:
            mesh=load_mesh(source);mesh.model_kind=kind
            # one source mesh plus any tiny generated fallback stays bounded
            self._mesh_cache={k:v for k,v in self._mesh_cache.items() if isinstance(k,tuple) and k and k[0]=='proxy'}
            self._mesh_cache[key]=mesh
        return mesh

    def request(self,canvas,bike_id,callback=None,reset=False):
        if reset:self.yaw=-0.65;self.pitch=-0.18;self.zoom=1.0
        self._canvas=canvas
        if callback is not None:self._status_cb=callback
        bike_id=str(bike_id or '').strip()
        try:width=max(500,canvas.winfo_width());height=max(300,canvas.winfo_height())
        except Exception:return
        with self._lock:self._token+=1;token=self._token
        if self._status_cb:
            try:self._status_cb('loading',bike_id)
            except Exception:pass

        def worker():
            try:
                mesh,kind,detail=self._resolve_mesh(bike_id)
                frame=render_mesh(mesh,self.yaw,self.pitch,self.zoom,width,height)
                result=(kind,frame,detail)
            except Exception as exc:result=('error',None,str(exc))

            def apply():
                with self._lock:
                    if token!=self._token:return
                try:
                    if not canvas.winfo_exists():return
                except Exception:return
                status,frame,detail=result
                if frame is not None:
                    try:
                        photo=ImageTk.PhotoImage(frame)
                        canvas.delete('garage3d_frame')
                        canvas.create_image(canvas.winfo_width()/2,canvas.winfo_height()/2,image=photo,anchor='center',tags='garage3d_frame')
                        canvas._garage3d_photo=photo
                    except Exception as exc:status,detail='error',str(exc)
                if self._status_cb:
                    try:self._status_cb(status,detail)
                    except Exception:pass
            try:canvas.after(0,apply)
            except Exception:pass
        self._executor.submit(worker)

    def schedule(self,canvas=None,bike_id=None,callback=None,reset=False,delay=90):
        canvas=canvas or self._canvas
        if canvas is None:return
        if callback is not None:self._status_cb=callback
        if bike_id is None and self._bike_getter is not None:
            try:bike_id=self._bike_getter()
            except Exception:bike_id=''
        try:
            if self._after_id is not None:canvas.after_cancel(self._after_id)
        except Exception:pass
        try:self._after_id=canvas.after(max(0,int(delay)),lambda:self.request(canvas,bike_id,self._status_cb,reset))
        except Exception:self.request(canvas,bike_id,self._status_cb,reset)

    def bind(self,canvas,bike_getter,callback=None):
        self._canvas=canvas;self._bike_getter=bike_getter;self._status_cb=callback
        def down(e):self._drag=(e.x,e.y,self.yaw,self.pitch)
        def move(e):
            if not self._drag:return
            x,y,yaw,pitch=self._drag
            self.yaw=yaw+(e.x-x)*0.012
            self.pitch=max(-1.25,min(1.25,pitch+(e.y-y)*0.009))
            self.schedule(delay=55)
        def up(e):self._drag=None
        def wheel(e):
            factor=1.12 if e.delta>0 else 0.88
            self.zoom=max(0.45,min(2.8,self.zoom*factor))
            self.schedule(delay=70)
        canvas.bind('<ButtonPress-1>',down,add='+');canvas.bind('<B1-Motion>',move,add='+')
        canvas.bind('<ButtonRelease-1>',up,add='+');canvas.bind('<MouseWheel>',wheel,add='+')
        canvas.bind('<Configure>',lambda e:self.schedule(delay=160),add='+')

    def stop(self):
        with self._lock:self._token+=1
        canvas=self._canvas
        if canvas is not None and self._after_id is not None:
            try:canvas.after_cancel(self._after_id)
            except Exception:pass
        self._after_id=None;self._drag=None
