from __future__ import annotations

import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

from . import __version__

USER_AGENT = f"MXB-Bike-Builder/{__version__}"


class UpdateError(RuntimeError):
    pass


@dataclass(frozen=True)
class UpdateInfo:
    version: str
    url: str
    sha256: str = ""
    notes: str = ""


def _version_parts(value: str) -> tuple[int, ...]:
    nums = [int(x) for x in re.findall(r"\d+", value or "")]
    return tuple(nums or [0])


def is_newer_version(candidate: str, current: str = __version__) -> bool:
    a = list(_version_parts(candidate))
    b = list(_version_parts(current))
    size = max(len(a), len(b))
    a += [0] * (size - len(a))
    b += [0] * (size - len(b))
    return tuple(a) > tuple(b)


def parse_update_manifest(data: dict, manifest_url: str) -> UpdateInfo:
    version = str(data.get("version", "")).strip()
    url = str(data.get("url", "")).strip()
    if not version:
        raise UpdateError("The update feed did not include a version number.")
    if not url:
        raise UpdateError("The update feed did not include a download URL.")
    url = urllib.parse.urljoin(manifest_url, url)
    if urllib.parse.urlparse(url).scheme not in {"http", "https"}:
        raise UpdateError("The update download URL must use http or https.")
    sha256 = str(data.get("sha256", "")).strip().lower()
    if sha256 and not re.fullmatch(r"[0-9a-f]{64}", sha256):
        raise UpdateError("The update feed contains an invalid SHA-256 value.")
    notes = str(data.get("notes", "")).strip()
    return UpdateInfo(version=version, url=url, sha256=sha256, notes=notes)


def check_for_update(manifest_url: str, timeout: float = 15.0) -> UpdateInfo | None:
    manifest_url = (manifest_url or "").strip()
    if not manifest_url:
        raise UpdateError("No update feed URL is configured.")
    if urllib.parse.urlparse(manifest_url).scheme not in {"http", "https"}:
        raise UpdateError("The update feed URL must use http or https.")
    request = urllib.request.Request(
        manifest_url,
        headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except Exception as exc:
        raise UpdateError(f"Could not reach the update feed:\n{exc}") from exc
    try:
        data = json.loads(raw.decode("utf-8"))
    except Exception as exc:
        raise UpdateError("The update feed did not return valid JSON.") from exc
    if not isinstance(data, dict):
        raise UpdateError("The update feed must contain a JSON object.")
    info = parse_update_manifest(data, manifest_url)
    return info if is_newer_version(info.version) else None


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def download_update(
    info: UpdateInfo,
    progress: Callable[[int, int], None] | None = None,
    timeout: float = 30.0,
) -> Path:
    request = urllib.request.Request(info.url, headers={"User-Agent": USER_AGENT})
    out = Path(tempfile.gettempdir()) / f"MXB_Bike_Builder_{info.version.replace('.', '_')}.zip"
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response, out.open("wb") as fh:
            total = int(response.headers.get("Content-Length", "0") or 0)
            done = 0
            while True:
                chunk = response.read(1024 * 256)
                if not chunk:
                    break
                fh.write(chunk)
                done += len(chunk)
                if progress:
                    progress(done, total)
    except Exception as exc:
        try:
            out.unlink(missing_ok=True)
        except OSError:
            pass
        raise UpdateError(f"The update could not be downloaded:\n{exc}") from exc
    if info.sha256:
        actual = sha256_file(out)
        if actual.lower() != info.sha256.lower():
            out.unlink(missing_ok=True)
            raise UpdateError(
                "The downloaded update failed its SHA-256 safety check. "
                "Nothing was installed."
            )
    return out


def application_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parents[2]


def _restart_target(root: Path) -> tuple[str, str]:
    if getattr(sys, "frozen", False):
        return "exe", str(Path(sys.executable).resolve())
    bat = root / "run_windows.bat"
    if bat.exists():
        return "bat", str(bat)
    return "python", str(root / "app.py")


def _powershell_script() -> str:
    # The updater runs outside the app, waits for the current process to close,
    # expands the ZIP to a temporary folder, overlays the installation, updates
    # Python requirements when a local venv exists, then relaunches the app.
    return r'''param(
  [int]$PidToWait,
  [string]$ZipPath,
  [string]$InstallRoot,
  [string]$RestartKind,
  [string]$RestartTarget,
  [string]$LogPath
)
$ErrorActionPreference = "Stop"
try {
  "[$(Get-Date -Format o)] MXB Bike Builder updater started" | Out-File -FilePath $LogPath -Encoding utf8
  for ($i = 0; $i -lt 180; $i++) {
    if (-not (Get-Process -Id $PidToWait -ErrorAction SilentlyContinue)) { break }
    Start-Sleep -Milliseconds 500
  }
  if (Get-Process -Id $PidToWait -ErrorAction SilentlyContinue) {
    throw "MXB Bike Builder did not close in time."
  }

  $Stage = Join-Path ([System.IO.Path]::GetTempPath()) ("MXBB_Update_" + [guid]::NewGuid().ToString("N"))
  New-Item -ItemType Directory -Path $Stage -Force | Out-Null
  Expand-Archive -LiteralPath $ZipPath -DestinationPath $Stage -Force

  $Source = $Stage
  $Top = @(Get-ChildItem -LiteralPath $Stage -Force)
  if ($Top.Count -eq 1 -and $Top[0].PSIsContainer) {
    $Candidate = $Top[0].FullName
    if ((Test-Path (Join-Path $Candidate "app.py")) -or (Test-Path (Join-Path $Candidate "run_windows.bat")) -or (Test-Path (Join-Path $Candidate "MXB Bike Builder.exe"))) {
      $Source = $Candidate
    }
  }

  if (-not ((Test-Path (Join-Path $Source "app.py")) -or (Test-Path (Join-Path $Source "MXB Bike Builder.exe")))) {
    throw "The update ZIP does not look like an MXB Bike Builder release."
  }

  New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
  Get-ChildItem -LiteralPath $Source -Force | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination $InstallRoot -Recurse -Force
  }

  $VenvPython = Join-Path $InstallRoot ".venv\Scripts\python.exe"
  $Requirements = Join-Path $InstallRoot "requirements.txt"
  if ((Test-Path $VenvPython) -and (Test-Path $Requirements)) {
    & $VenvPython -m pip install -r $Requirements | Out-File -FilePath $LogPath -Append -Encoding utf8
  }

  Remove-Item -LiteralPath $Stage -Recurse -Force -ErrorAction SilentlyContinue
  Remove-Item -LiteralPath $ZipPath -Force -ErrorAction SilentlyContinue

  if ($RestartKind -eq "bat") {
    # WScript.Shell handles quoted .bat paths with spaces more reliably than
    # cmd.exe /c passed through Start-Process's ArgumentList flattening.
    $Shell = New-Object -ComObject WScript.Shell
    $Shell.CurrentDirectory = $InstallRoot
    $Result = $Shell.Run(('"' + $RestartTarget + '"'), 1, $false)
    "[$(Get-Date -Format o)] Restart requested via WScript.Shell: $RestartTarget (result $Result)" | Out-File -FilePath $LogPath -Append -Encoding utf8
  } elseif ($RestartKind -eq "exe") {
    $Proc = Start-Process -FilePath $RestartTarget -WorkingDirectory $InstallRoot -PassThru
    "[$(Get-Date -Format o)] Restarted executable PID $($Proc.Id)" | Out-File -FilePath $LogPath -Append -Encoding utf8
  } else {
    $Py = Join-Path $InstallRoot ".venv\Scripts\python.exe"
    if (-not (Test-Path $Py)) { $Py = "python" }
    $Proc = Start-Process -FilePath $Py -ArgumentList @($RestartTarget) -WorkingDirectory $InstallRoot -PassThru
    "[$(Get-Date -Format o)] Restarted Python process PID $($Proc.Id)" | Out-File -FilePath $LogPath -Append -Encoding utf8
  }
  "[$(Get-Date -Format o)] Update completed and restart command issued" | Out-File -FilePath $LogPath -Append -Encoding utf8
} catch {
  "[$(Get-Date -Format o)] ERROR: $($_.Exception.Message)" | Out-File -FilePath $LogPath -Append -Encoding utf8
  Add-Type -AssemblyName PresentationFramework -ErrorAction SilentlyContinue
  try { [System.Windows.MessageBox]::Show("MXB Bike Builder update failed.`n`n$($_.Exception.Message)`n`nLog: $LogPath", "MXB Bike Builder Updater") | Out-Null } catch {}
}
'''


def launch_update(zip_path: Path) -> Path:
    if os.name != "nt":
        raise UpdateError("Automatic installation is currently supported on Windows only.")
    zip_path = Path(zip_path).resolve()
    if not zip_path.exists():
        raise UpdateError("The update ZIP no longer exists.")
    root = application_root()
    restart_kind, restart_target = _restart_target(root)
    temp = Path(tempfile.gettempdir())
    script = temp / f"MXBB_apply_update_{os.getpid()}.ps1"
    log = temp / "MXB_Bike_Builder_update.log"
    script.write_text(_powershell_script(), encoding="utf-8-sig")
    args = [
        "powershell.exe",
        "-NoProfile",
        "-ExecutionPolicy", "Bypass",
        "-File", str(script),
        "-PidToWait", str(os.getpid()),
        "-ZipPath", str(zip_path),
        "-InstallRoot", str(root),
        "-RestartKind", restart_kind,
        "-RestartTarget", restart_target,
        "-LogPath", str(log),
    ]
    creationflags = getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0) | getattr(subprocess, "CREATE_NO_WINDOW", 0)
    try:
        subprocess.Popen(args, cwd=str(root), creationflags=creationflags, close_fds=True)
    except Exception as exc:
        raise UpdateError(f"Could not start the updater:\n{exc}") from exc
    return log
