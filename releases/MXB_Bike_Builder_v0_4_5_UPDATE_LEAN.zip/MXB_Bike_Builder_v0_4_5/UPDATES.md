# Updates

## v0.4.5
- Fixes modern Project OEM model loading.
- Detects real visual EDF files stored under `mods/bikes/OEM_Models/MX`.
- Ignores EDF-named placeholders that do not contain an actual `EDF\0` header.
- Keeps the v0.4.4 updater restart and desktop shortcut changes.
