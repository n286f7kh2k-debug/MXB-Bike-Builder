# MXB Race Day Live Windows shell identity: must run before Tk creates the taskbar button.
try:
    from pathlib import Path as _RDLPath
    from src.windows_taskbar import set_process_app_id as _rdl_set_process_app_id
    from src.windows_integration import ensure_desktop_shortcut as _rdl_ensure_desktop_shortcut
    _rdl_set_process_app_id()
    _rdl_ensure_desktop_shortcut(_RDLPath(__file__).resolve().parent)
except Exception:
    pass

from pathlib import Path
from src.app import main
from src.windows_integration import ensure_desktop_shortcut

if __name__ == '__main__':
    try:
        ensure_desktop_shortcut(Path(__file__).resolve().parent)
    except Exception:
        pass
    main()
