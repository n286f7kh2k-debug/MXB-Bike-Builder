# MXB Bike Builder Updates

## v0.4.6

- Fixes a stale saved `model.edf` selection causing the repeated "missing EDF header" error.
- Invalid EDF-named OEM redirect/placeholder files are no longer sent to the binary parser.
- The loader now follows safe local EDF redirect paths when present and otherwise falls back to installed OEM PKZ / `OEM_Models` discovery.

## v0.4.4
- Fixed the Windows updater relaunch path for source/dev installs whose folder names contain spaces.
- The updater now restarts `run_windows.bat` using Windows Script Host rather than fragile `cmd /c` quoting.
- Added automatic Windows desktop shortcut creation.

# MXB Bike Builder Updates

## v0.4.3
- Added direct normal/plain Project OEM `.pkz` reading for real 3D bike references.
- Added automatic installed KX450 OEM PKZ discovery under `mods\bikes`.
- Added full Project OEM ZIP selection with matching nested-bike PKZ discovery.
- Added OEM PKZ donor staging for the Build + Install pipeline.
- Kept the crude placeholder stock meshes hidden when the OEM reference cannot load.
- Renamed the viewer action to `Load OEM Bike / PKZ`.
- Preserved the v0.4.1 in-app updater and manual update-ZIP path.

## v0.4.1
- Added in-app update button, online update feed support, SHA-256 verification, update install/restart, and manual update ZIP fallback.

## v0.4
- Added read-only real MX Bikes EDF preview support.


## Permanent update channel
This build is preconfigured to check:
https://raw.githubusercontent.com/n286f7kh2k-debug/MXB-Bike-Builder/main/latest.json

Older settings files with an empty update-feed value are migrated automatically.
