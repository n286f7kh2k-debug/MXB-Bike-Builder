import os, shutil, threading, tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, filedialog
from datetime import datetime
from .config import VERSION, APP_NAME, APPDATA, load_settings
from .database import (
    connect, seed, current_purse, payout_split, fastest_lap_pool,
    race_financials, wallet_balance, wallet_credit, wallet_debit, setting_float
)
from .updater import check_for_update, download_update, launch_update

BG='#0b0d10'; PANEL='#15191e'; PANEL2='#1d232a'; TEXT='#f3f5f7'; MUTED='#98a2ad'
ACCENT='#f26a21'; GOLD='#ffc247'; GREEN='#45d483'; RED='#ff5757'; LINE='#2b323a'; BLUE='#55aaff'

NAV = [
    ('MY PADDOCK','PROFILE'),
    ('FIND A RACE','UPCOMING'),
    ('LIVE','LIVE'),
    ('MY RACES','MY RACES'),
    ('RESULTS','RESULTS'),
    ('SERIES','CHAMPIONSHIPS'),
    ('RANKINGS','RANKINGS'),
    ('ADMIN','ADMIN'),
]

class RaceControlApp(tk.Tk):
    def __init__(self):
        super().__init__(); seed(); self.conn=connect(); self.settings=load_settings(); self.current_rider='Welchy'
        self.title(f'{APP_NAME}  v{VERSION}'); self.geometry('1480x900'); self.minsize(1180,760); self.configure(bg=BG)
        try:self.iconbitmap(os.path.join(os.path.dirname(os.path.dirname(__file__)),'assets','mxb_race_control.ico'))
        except Exception:pass
        self._styles(); self._layout(); self.show('PROFILE')
        if self.settings.get('auto_check_updates'): self.after(1300,self._silent_update_check)

    def _styles(self):
        s=ttk.Style(self); s.theme_use('clam')
        s.configure('Treeview',background=PANEL,fieldbackground=PANEL,foreground=TEXT,rowheight=34,bordercolor=LINE,font=('Segoe UI',10))
        s.configure('Treeview.Heading',background=PANEL2,foreground=TEXT,font=('Segoe UI Semibold',10),relief='flat')
        s.map('Treeview',background=[('selected','#2d3944')])
        s.configure('TNotebook',background=BG,borderwidth=0); s.configure('TNotebook.Tab',padding=(14,8))

    def _layout(self):
        header=tk.Frame(self,bg=BG,height=74); header.pack(fill='x'); header.pack_propagate(False)
        brand=tk.Frame(header,bg=BG); brand.pack(side='left',padx=24)
        tk.Label(brand,text='MXB',fg=ACCENT,bg=BG,font=('Segoe UI Black',26,'italic')).pack(side='left')
        tk.Label(brand,text=' RACE CONTROL',fg=TEXT,bg=BG,font=('Segoe UI Black',22)).pack(side='left')
        tk.Label(brand,text='  RACE DAY',fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(side='left',padx=10,pady=(10,0))
        self.update_btn=tk.Button(header,text='UPDATE',command=self.do_update,bg=ACCENT,fg='white',activebackground='#ff7a30',relief='flat',font=('Segoe UI Semibold',10),padx=18,pady=8,cursor='hand2'); self.update_btn.pack(side='right',padx=24,pady=18)
        tk.Label(header,text=f'v{VERSION}',fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(side='right')
        tk.Frame(self,bg=ACCENT,height=3).pack(fill='x')
        body=tk.Frame(self,bg=BG); body.pack(fill='both',expand=True)
        self.nav=tk.Frame(body,bg='#101318',width=205); self.nav.pack(side='left',fill='y'); self.nav.pack_propagate(False)
        self.nav_buttons={}
        for label,page in NAV:
            b=tk.Button(self.nav,text=label,anchor='w',command=lambda p=page:self.show(p),bg='#101318',fg=TEXT,activebackground=PANEL2,activeforeground='white',relief='flat',font=('Segoe UI Semibold',10),padx=22,pady=14,cursor='hand2')
            b.pack(fill='x',pady=1); self.nav_buttons[page]=b
        tk.Frame(self.nav,bg=LINE,height=1).pack(fill='x',padx=18,pady=15)
        tk.Label(self.nav,text='RACE DAY STATUS',fg=MUTED,bg='#101318',font=('Segoe UI Semibold',8)).pack(anchor='w',padx=22)
        tk.Label(self.nav,text='● SYSTEM READY',fg=GREEN,bg='#101318',font=('Segoe UI Semibold',10)).pack(anchor='w',padx=22,pady=8)
        tk.Label(self.nav,text='Payments: DEMO MODE',fg=MUTED,bg='#101318',font=('Segoe UI',8)).pack(anchor='w',padx=22)
        self.content=tk.Frame(body,bg=BG); self.content.pack(side='left',fill='both',expand=True)

    def clear(self):
        for w in self.content.winfo_children():w.destroy()
    def show(self,name):
        self.clear()
        for n,b in self.nav_buttons.items():b.configure(bg=PANEL2 if n==name else '#101318',fg=ACCENT if n==name else TEXT)
        getattr(self,'page_'+name.lower().replace(' ','_'))()
    def titlebar(self,title,sub=''):
        f=tk.Frame(self.content,bg=BG); f.pack(fill='x',padx=28,pady=(24,16))
        tk.Label(f,text=title,fg=TEXT,bg=BG,font=('Segoe UI Black',24)).pack(anchor='w')
        if sub:tk.Label(f,text=sub,fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=1100,justify='left').pack(anchor='w',pady=(3,0))
        return f
    def card(self,parent):return tk.Frame(parent,bg=PANEL,highlightbackground=LINE,highlightthickness=1)
    def stat(self,parent,label,value,accent=False):
        c=self.card(parent); c.pack(side='left',fill='both',expand=True,padx=5)
        tk.Label(c,text=label,fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',9)).pack(anchor='w',padx=16,pady=(14,2))
        tk.Label(c,text=value,fg=GOLD if accent else TEXT,bg=PANEL,font=('Segoe UI Black',20)).pack(anchor='w',padx=16,pady=(0,14))
    def rider(self):return self.conn.execute('SELECT * FROM riders WHERE username=?',(self.current_rider,)).fetchone()
    def overall_rank(self,rider=None):
        rider=rider or self.rider()
        return self.conn.execute('SELECT COUNT(*)+1 FROM riders WHERE skill_rating>?',(rider['skill_rating'],)).fetchone()[0]
    def etiquette_text(self,rider=None):
        rider=rider or self.rider()
        names={'S':'ELITE','A':'CLEAN','B':'GOOD','C':'WATCH','D':'POOR','F':'RESTRICTED'}
        return names.get((rider['racecraft_grade'] or '').upper(),'UNRATED')
    def eligible(self,race,rider=None):
        rider=rider or self.rider()
        return race['min_skill']<=rider['skill_rating']<=race['max_skill'] and rider['racecraft_score']>=race['min_racecraft']

    def _profile_avatar(self,parent,rider,size=92):
        wrap=tk.Frame(parent,bg=PANEL,width=size,height=size,highlightbackground=LINE,highlightthickness=1)
        wrap.pack_propagate(False)
        path=(rider['avatar_path'] or '').strip() if 'avatar_path' in rider.keys() else ''
        if path and Path(path).exists():
            try:
                img=tk.PhotoImage(file=path)
                # Tk-only image support keeps the app dependency-free. Fit large PNG/GIF avatars down to the header.
                factor=max(1,(max(img.width(),img.height())+size-1)//size)
                if factor>1: img=img.subsample(factor,factor)
                self._profile_avatar_image=img
                tk.Label(wrap,image=img,bg=PANEL).place(relx=.5,rely=.5,anchor='center')
                return wrap
            except Exception:
                pass
        canvas=tk.Canvas(wrap,width=size,height=size,bg=PANEL,highlightthickness=0)
        canvas.pack(fill='both',expand=True)
        canvas.create_oval(8,8,size-8,size-8,fill=PANEL2,outline=ACCENT,width=3)
        initials=''.join(x[0] for x in rider['username'].split()[:2]).upper() or '?'
        canvas.create_text(size/2,size/2,text=initials,fill=TEXT,font=('Segoe UI Black',24))
        return wrap

    def _profile_header(self,rider):
        header=self.card(self.content); header.pack(fill='x',padx=28,pady=(24,14))
        inner=tk.Frame(header,bg=PANEL); inner.pack(fill='x',padx=18,pady=16)
        avatar=self._profile_avatar(inner,rider,94); avatar.pack(side='left',padx=(0,18))
        info=tk.Frame(inner,bg=PANEL); info.pack(side='left',fill='x',expand=True)
        name_row=tk.Frame(info,bg=PANEL); name_row.pack(fill='x')
        tk.Label(name_row,text=rider['username'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',27)).pack(side='left')
        tk.Label(name_row,text=f"  ★ #{self.overall_rank(rider)}",fg=GOLD,bg=PANEL,font=('Segoe UI Black',11)).pack(side='left',pady=(8,0))
        tk.Label(info,text=f"#{rider['number']}  •  {rider['team']}  •  {rider['bike_model']}  •  {rider['region']}",fg=MUTED,bg=PANEL,font=('Segoe UI Semibold',10)).pack(anchor='w',pady=(2,10))
        badges=tk.Frame(info,bg=PANEL); badges.pack(anchor='w')
        skill=tk.Frame(badges,bg=PANEL2,highlightbackground=LINE,highlightthickness=1); skill.pack(side='left',padx=(0,8))
        tk.Label(skill,text='CURRENT SKILL STATUS',fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',7)).pack(anchor='w',padx=10,pady=(6,0))
        tk.Label(skill,text=f"{rider['skill_class'].upper()}  •  {rider['skill_rating']} MMR",fg=GOLD,bg=PANEL2,font=('Segoe UI Black',10)).pack(anchor='w',padx=10,pady=(0,6))
        etiquette=tk.Frame(badges,bg=PANEL2,highlightbackground=LINE,highlightthickness=1); etiquette.pack(side='left')
        tk.Label(etiquette,text='ETIQUETTE RANKING',fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',7)).pack(anchor='w',padx=10,pady=(6,0))
        tk.Label(etiquette,text=f"{rider['racecraft_grade']} • {self.etiquette_text(rider)}  •  {rider['racecraft_score']}",fg=GREEN if rider['racecraft_score']>=800 else GOLD,bg=PANEL2,font=('Segoe UI Black',10)).pack(anchor='w',padx=10,pady=(0,6))
        return header

    # ---------- MY PADDOCK / PROFILE ----------
    def page_profile(self):
        r=self.rider(); self._profile_header(r)
        top=tk.Frame(self.content,bg=BG); top.pack(fill='x',padx=23)
        self.stat(top,'RACE WALLET',f"${wallet_balance(self.conn,r['id']):,.2f}",True)
        self.stat(top,'CAREER STARTS',f"{r['starts']}")
        self.stat(top,'WINS / PODIUMS',f"{r['wins']} / {r['podiums']}")
        self.stat(top,'CHAMPIONSHIPS',f"{r['championships']}")
        self.stat(top,'CAREER EARNINGS',f"${r['career_earnings']:,.0f}",True)

        body=tk.Frame(self.content,bg=BG); body.pack(fill='both',expand=True,padx=28,pady=18)
        left=tk.Frame(body,bg=BG); left.pack(side='left',fill='both',expand=True,padx=(0,7))
        right=tk.Frame(body,bg=BG); right.pack(side='left',fill='both',expand=True,padx=(7,0))

        wallet=self.card(left); wallet.pack(fill='x')
        tk.Label(wallet,text='RACE WALLET',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=18,pady=(16,3))
        tk.Label(wallet,text=f"${wallet_balance(self.conn,r['id']):,.2f}",fg=GOLD,bg=PANEL,font=('Segoe UI Black',34)).pack(anchor='w',padx=18)
        tk.Label(wallet,text='Load funds before race night, then enter eligible races with one click.',fg=MUTED,bg=PANEL,font=('Segoe UI',10)).pack(anchor='w',padx=18,pady=(0,10))
        btns=tk.Frame(wallet,bg=PANEL); btns.pack(fill='x',padx=18,pady=(0,16))
        tk.Button(btns,text='ADD FUNDS',command=self.add_funds_dialog,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',10),padx=18,pady=10).pack(side='left')
        tk.Button(btns,text='FIND A RACE',command=lambda:self.show('UPCOMING'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',10),padx=18,pady=10).pack(side='left',padx=8)

        profile=self.card(left); profile.pack(fill='x',pady=(12,0))
        tk.Label(profile,text='RIDER PROFILE',fg=TEXT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=18,pady=(16,4))
        tk.Label(profile,text=r['bio'] or 'No bio yet.',fg=TEXT,bg=PANEL,font=('Segoe UI',10),wraplength=540,justify='left').pack(anchor='w',padx=18,pady=(4,8))
        tk.Button(profile,text='EDIT PROFILE',command=self.edit_profile_dialog,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=14,pady=8).pack(anchor='w',padx=18,pady=(0,16))

        # Next eligible race and low-stakes options are front-and-center.
        tk.Label(right,text='YOUR NEXT GATE DROPS',fg=TEXT,bg=BG,font=('Segoe UI Black',14)).pack(anchor='w',pady=(0,6))
        eligible=[x for x in self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY entry_fee,start_time") if self.eligible(x,r)]
        for race in eligible[:4]:
            paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id'])
            c=self.card(right); c.pack(fill='x',pady=5)
            top2=tk.Frame(c,bg=PANEL); top2.pack(fill='x',padx=14,pady=(12,2))
            tag='LOW ENTRY' if race['lobby_tier']=='Low Entry' else race['lobby_tier'].upper()
            tk.Label(top2,text=f"{race['skill_class'].upper()} • {tag}",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',9)).pack(side='left')
            tk.Label(top2,text=f"${race['entry_fee']:.2f} ENTRY",fg=GOLD,bg=PANEL,font=('Segoe UI Black',10)).pack(side='right')
            tk.Label(c,text=race['name'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=14)
            tk.Label(c,text=f"{race['track']}  •  Main purse ${purse:,.2f}  •  Fast lap ${fast:,.2f}  •  {paid}/{race['max_riders']} riders",fg=MUTED,bg=PANEL,font=('Segoe UI',9)).pack(anchor='w',padx=14,pady=(3,10))
        if not eligible:tk.Label(right,text='No eligible races are open right now.',fg=MUTED,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=12)

        hist=self.card(right); hist.pack(fill='both',expand=True,pady=(12,0))
        tk.Label(hist,text='RECENT RESULTS',fg=TEXT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=18,pady=(16,5))
        rows=list(self.conn.execute('''SELECT rs.position,rs.payout,rs.fast_lap_bonus,rs.skill_delta,rc.name FROM results rs JOIN races rc ON rc.id=rs.race_id WHERE rs.rider_id=? ORDER BY rc.start_time DESC LIMIT 5''',(r['id'],)))
        if not rows:tk.Label(hist,text='Your completed race results will appear here automatically.',fg=MUTED,bg=PANEL,font=('Segoe UI',10)).pack(anchor='w',padx=18,pady=12)
        for x in rows:
            f=tk.Frame(hist,bg=PANEL2); f.pack(fill='x',padx=16,pady=5)
            tk.Label(f,text=f"P{x['position']}  {x['name']}",fg=TEXT,bg=PANEL2,font=('Segoe UI Semibold',10)).pack(side='left',padx=10,pady=10)
            bonus=f" + ${x['fast_lap_bonus']:.0f} FAST LAP" if x['fast_lap_bonus'] else ''
            tk.Label(f,text=f"${x['payout']:.0f}{bonus}   MMR {x['skill_delta']:+d}",fg=GOLD,bg=PANEL2,font=('Segoe UI Semibold',9)).pack(side='right',padx=10)

    def edit_profile_dialog(self):
        r=self.rider(); dlg=tk.Toplevel(self); dlg.title('Edit Rider Profile'); dlg.geometry('580x680'); dlg.configure(bg=BG); dlg.transient(self); dlg.grab_set()
        tk.Label(dlg,text='EDIT RIDER PROFILE',fg=TEXT,bg=BG,font=('Segoe UI Black',18)).pack(anchor='w',padx=24,pady=(22,10))

        avatar_choice={'path': (r['avatar_path'] or '') if 'avatar_path' in r.keys() else ''}
        avatar_row=tk.Frame(dlg,bg=BG); avatar_row.pack(fill='x',padx=24,pady=(0,8))
        tk.Label(avatar_row,text='PROFILE PICTURE',fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w')
        avatar_status=tk.StringVar(value=Path(avatar_choice['path']).name if avatar_choice['path'] else 'No picture selected — initials will be shown.')
        tk.Label(avatar_row,textvariable=avatar_status,fg=TEXT,bg=BG,font=('Segoe UI',9)).pack(anchor='w',pady=(3,5))
        def choose_avatar():
            src=filedialog.askopenfilename(parent=dlg,title='Choose Profile Picture',filetypes=[('Profile pictures','*.png *.gif'),('PNG image','*.png'),('GIF image','*.gif')])
            if not src:return
            avatar_dir=APPDATA/'profile_images'; avatar_dir.mkdir(parents=True,exist_ok=True)
            ext=Path(src).suffix.lower() or '.png'; dest=avatar_dir/f"rider_{r['id']}{ext}"
            try:
                shutil.copy2(src,dest); avatar_choice['path']=str(dest); avatar_status.set(dest.name)
            except Exception as e: messagebox.showerror('Profile Picture',str(e),parent=dlg)
        tk.Button(avatar_row,text='CHOOSE PICTURE',command=choose_avatar,bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=14,pady=7).pack(anchor='w')

        fields={}
        for label,key,value in [('TEAM','team',r['team']),('BIKE MODEL','bike_model',r['bike_model']),('BIKE SIZE','bike_size',r['bike_size']),('REGION','region',r['region'])]:
            tk.Label(dlg,text=label,fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=24,pady=(9,3))
            v=tk.StringVar(value=value or ''); fields[key]=v; tk.Entry(dlg,textvariable=v,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI',11)).pack(fill='x',padx=24,ipady=7)
        tk.Label(dlg,text='BIO',fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=24,pady=(9,3))
        bio=tk.Text(dlg,height=4,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI',10),wrap='word'); bio.pack(fill='x',padx=24); bio.insert('1.0',r['bio'] or '')
        tk.Label(dlg,text='Verified statistics, overall rank, MMR, etiquette rating, results and earnings cannot be edited by the rider.',fg=MUTED,bg=BG,font=('Segoe UI',8),wraplength=510,justify='left').pack(anchor='w',padx=24,pady=10)
        def save():
            self.conn.execute('UPDATE riders SET team=?,bike_model=?,bike_size=?,region=?,bio=?,avatar_path=? WHERE id=?',(fields['team'].get().strip(),fields['bike_model'].get().strip(),fields['bike_size'].get().strip(),fields['region'].get().strip(),bio.get('1.0','end').strip(),avatar_choice['path'],r['id']))
            self.conn.commit(); dlg.destroy(); self.show('PROFILE')
        tk.Button(dlg,text='SAVE PROFILE',command=save,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',10),pady=10).pack(fill='x',padx=24,pady=10)

    # ---------- FIND A RACE ----------
    def page_upcoming(self):
        r=self.rider(); self.titlebar('FIND A RACE','Eligible races are shown first. Every event displays the entry price, current main purse and fastest-lap cash bonus before you enter.')
        outer=tk.Frame(self.content,bg=BG); outer.pack(fill='both',expand=True,padx=28,pady=(0,20))
        races=list(self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY start_time"))
        races.sort(key=lambda x:(0 if self.eligible(x,r) else 1, x['entry_fee'], x['start_time']))
        left=self.card(outer); left.pack(side='left',fill='y'); left.configure(width=445); left.pack_propagate(False)
        self.upcoming_detail=self.card(outer); self.upcoming_detail.pack(side='left',fill='both',expand=True,padx=(12,0))
        tk.Label(left,text='OPEN RACES',fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=14,pady=(14,5))
        for race in races:
            paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id']); ok=self.eligible(race,r)
            lock='' if ok else '  🔒'
            tag='LOW ENTRY' if race['lobby_tier']=='Low Entry' else race['lobby_tier'].upper()
            b=tk.Button(left,text=f"{race['skill_class'].upper()} • {tag}{lock}     ${race['entry_fee']:.2f}\n{race['name']}\nMain ${purse:,.0f} + Fast Lap ${fast:,.0f}   •   {paid}/{race['max_riders']} riders",justify='left',anchor='w',command=lambda rr=race:self.render_race(rr),bg=PANEL2,fg=TEXT if ok else MUTED,activebackground='#283039',activeforeground='white',relief='flat',font=('Segoe UI Semibold',9),padx=14,pady=11,cursor='hand2')
            b.pack(fill='x',padx=10,pady=4)
        if races:self.render_race(races[0])

    def render_race(self,race):
        for w in self.upcoming_detail.winfo_children():w.destroy()
        paid,purse=current_purse(self.conn,race['id']); fast=fastest_lap_pool(self.conn,race['id']); split=payout_split(paid); payouts=[round(purse*x,2) for x in split]
        rider=self.rider(); ok=self.eligible(race,rider)
        head=tk.Frame(self.upcoming_detail,bg=PANEL); head.pack(fill='x',padx=20,pady=18)
        tag='LOW ENTRY' if race['lobby_tier']=='Low Entry' else race['lobby_tier'].upper()
        tk.Label(head,text=f"{race['skill_class'].upper()}  /  {tag}",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',10)).pack(anchor='w')
        tk.Label(head,text=race['name'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',20)).pack(anchor='w')
        tk.Label(head,text=f"{race['discipline']} • {race['track']} • {race['bike_class']} • {datetime.fromisoformat(race['start_time']).strftime('%a %b %d  %I:%M %p')}",fg=MUTED,bg=PANEL,font=('Segoe UI',10)).pack(anchor='w',pady=(2,8))
        money=tk.Frame(self.upcoming_detail,bg=PANEL2); money.pack(fill='x',padx=20,pady=(0,12))
        vals=[('ENTRY',f"${race['entry_fee']:.2f}"),('MAIN PURSE',f"${purse:,.2f}"),('FASTEST LAP',f"${fast:,.2f}"),('RIDERS',f"{paid}/{race['max_riders']}")]
        for a,b in vals:
            f=tk.Frame(money,bg=PANEL2); f.pack(side='left',expand=True,fill='x',padx=8,pady=12); tk.Label(f,text=a,fg=MUTED,bg=PANEL2,font=('Segoe UI Semibold',8)).pack(); tk.Label(f,text=b,fg=GOLD if a in ('MAIN PURSE','FASTEST LAP') else TEXT,bg=PANEL2,font=('Segoe UI Black',16)).pack()
        paytxt='  •  '.join(f"P{i+1} ${amt:,.2f}" for i,amt in enumerate(payouts)) if payouts else 'Payouts grow with paid entries.'
        tk.Label(self.upcoming_detail,text=f"PROJECTED FINISH PAYOUTS: {paytxt}\nFASTEST LAP BONUS: ${fast:,.2f} TO THE OFFICIAL FASTEST LAP\nPURSE & BONUS LOCK BEFORE THE GATE DROPS • ALL SALES FINAL • NO REFUNDS",fg=GOLD,bg=PANEL,font=('Segoe UI Semibold',9),justify='left').pack(anchor='w',padx=20,pady=(0,10))
        breakdown=f"Your ${race['entry_fee']:.2f} entry currently allocates ${race['prize_contribution']:.2f} to the main purse, ${race['fast_lap_contribution']:.2f} to the fastest-lap pool, and ${race['platform_fee']:.2f} to race operations/platform."
        tk.Label(self.upcoming_detail,text=breakdown,fg=MUTED,bg=PANEL,font=('Segoe UI',8),wraplength=900,justify='left').pack(anchor='w',padx=20,pady=(0,10))
        if not ok:
            tk.Label(self.upcoming_detail,text=f"LOCKED FOR YOUR PROFILE — requires {race['min_skill']}–{race['max_skill']} MMR and Racecraft {race['min_racecraft']}+.",fg=RED,bg=PANEL,font=('Segoe UI Black',9)).pack(anchor='w',padx=20,pady=(0,10))
        cols=('Rider','Bike','Size','Signed Up','Skill','Racecraft'); tree=ttk.Treeview(self.upcoming_detail,columns=cols,show='headings',height=8)
        for c in cols:tree.heading(c,text=c); tree.column(c,width=130 if c!='Rider' else 170,anchor='w')
        for x in self.conn.execute('''SELECT rd.*,rg.signed_up_at FROM registrations rg JOIN riders rd ON rd.id=rg.rider_id WHERE rg.race_id=? AND rg.payment_status='PAID' ORDER BY rg.signed_up_at''',(race['id'],)):
            tree.insert('', 'end',values=(f"#{x['number']} {x['username']}",x['bike_model'],x['bike_size'],datetime.fromisoformat(x['signed_up_at']).strftime('%m/%d %I:%M %p'),f"{x['skill_class']} {x['skill_rating']}",f"{x['racecraft_grade']} {x['racecraft_score']}"))
        tree.pack(fill='both',expand=True,padx=20,pady=(0,12))
        text='ENTER RACE WITH WALLET' if ok else 'RACE LOCKED'
        btn=tk.Button(self.upcoming_detail,text=text,command=lambda:self.signup_demo(race),state='normal' if ok else 'disabled',bg=ACCENT if ok else LINE,fg='white',relief='flat',font=('Segoe UI Black',11),pady=11,cursor='hand2'); btn.pack(fill='x',padx=20,pady=(0,20))

    def signup_demo(self,race):
        rider=self.rider(); existing=self.conn.execute('SELECT 1 FROM registrations WHERE race_id=? AND rider_id=?',(race['id'],rider['id'])).fetchone()
        if existing:messagebox.showinfo('Already Registered','You are already on the paid entry list for this race.'); return
        if not self.eligible(race,rider):messagebox.showerror('Race Locked','Your current skill/Racecraft rating does not qualify for this lobby.'); return
        dlg=tk.Toplevel(self); dlg.title('Enter Race'); dlg.geometry('570x530'); dlg.configure(bg=BG); dlg.transient(self); dlg.grab_set(); bal=wallet_balance(self.conn,rider['id'])
        tk.Label(dlg,text='ENTER RACE',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',padx=24,pady=(24,5)); tk.Label(dlg,text=race['name'],fg=ACCENT,bg=BG,font=('Segoe UI Semibold',12)).pack(anchor='w',padx=24)
        tk.Label(dlg,text=f"Wallet balance: ${bal:,.2f}\nEntry: ${race['entry_fee']:.2f}\nMain purse contribution: ${race['prize_contribution']:.2f}\nFastest-lap contribution: ${race['fast_lap_contribution']:.2f}\nRace operations/platform: ${race['platform_fee']:.2f}",fg=TEXT,bg=BG,font=('Segoe UI',11),justify='left').pack(anchor='w',padx=24,pady=18)
        if bal<race['entry_fee']:
            tk.Label(dlg,text=f"ADD ${race['entry_fee']-bal:.2f} OR MORE TO ENTER",fg=RED,bg=BG,font=('Segoe UI Black',10)).pack(anchor='w',padx=24,pady=(0,7))
            tk.Button(dlg,text='ADD FUNDS',command=lambda:[dlg.destroy(),self.add_funds_dialog()],bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',10),pady=9).pack(fill='x',padx=24,pady=(0,10))
        tk.Label(dlg,text='ALL SALES ARE FINAL — NO REFUNDS.\nThe main purse and fastest-lap bonus lock before racing begins. Applicable mandatory legal/payment-network rights still control where required.',fg=GOLD,bg=PANEL,justify='left',font=('Segoe UI Semibold',10),padx=14,pady=14,wraplength=490).pack(fill='x',padx=24)
        ack=tk.BooleanVar(False); tk.Checkbutton(dlg,text='I understand and accept the no-refund policy.',variable=ack,bg=BG,fg=TEXT,selectcolor=PANEL,activebackground=BG,activeforeground=TEXT,font=('Segoe UI',10)).pack(anchor='w',padx=24,pady=14)
        def confirm():
            if not ack.get():messagebox.showwarning('Required','Accept the no-refund policy before registration.'); return
            try:newbal=wallet_debit(self.conn,rider['id'],race['entry_fee'],kind='RACE_ENTRY',race_id=race['id'],note=f"Entry: {race['name']}")
            except ValueError as e:messagebox.showerror('Race Wallet',str(e)); return
            now=datetime.now().replace(microsecond=0).isoformat()
            self.conn.execute('INSERT INTO registrations(race_id,rider_id,signed_up_at,payment_status,amount_paid,no_refund_ack) VALUES(?,?,?,?,?,1)',(race['id'],rider['id'],now,'PAID',race['entry_fee']))
            self.conn.execute('INSERT INTO payment_transactions(rider_id,race_id,provider,provider_ref,amount,status,created_at) VALUES(?,?,?,?,?,?,?)',(rider['id'],race['id'],'RACE_WALLET',None,race['entry_fee'],'PAID',now)); self.conn.commit()
            dlg.destroy(); messagebox.showinfo('You’re In',f"You are officially registered.\nWallet remaining: ${newbal:,.2f}"); self.render_race(race)
        tk.Button(dlg,text=f"PAY ${race['entry_fee']:.2f} & ENTER",command=confirm,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',11),pady=10).pack(fill='x',padx=24)

    def add_funds_dialog(self):
        rider=self.rider(); dlg=tk.Toplevel(self); dlg.title('Race Wallet'); dlg.geometry('510x450'); dlg.configure(bg=BG); dlg.transient(self); dlg.grab_set(); current=wallet_balance(self.conn,rider['id'])
        tk.Label(dlg,text='RACE WALLET',fg=TEXT,bg=BG,font=('Segoe UI Black',20)).pack(anchor='w',padx=24,pady=(24,4)); tk.Label(dlg,text=f"Available  ${current:,.2f}",fg=GOLD,bg=BG,font=('Segoe UI Black',17)).pack(anchor='w',padx=24,pady=(0,14))
        tk.Label(dlg,text='Load money once, then use your balance for race entries. Enter any positive amount below.',fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=450,justify='left').pack(anchor='w',padx=24,pady=(0,10))
        amount=tk.StringVar(value='25.00'); quick=tk.Frame(dlg,bg=BG); quick.pack(fill='x',padx=20,pady=5)
        for v in (10,25,50,100,250):tk.Button(quick,text=f'${v}',command=lambda x=v:amount.set(f'{x:.2f}'),bg=PANEL2,fg=TEXT,relief='flat',font=('Segoe UI Semibold',9),padx=10,pady=8).pack(side='left',padx=3)
        tk.Label(dlg,text='CUSTOM AMOUNT',fg=MUTED,bg=BG,font=('Segoe UI Semibold',8)).pack(anchor='w',padx=24,pady=(12,3)); tk.Entry(dlg,textvariable=amount,bg=PANEL2,fg=TEXT,insertbackground=TEXT,relief='flat',font=('Segoe UI Black',18)).pack(fill='x',padx=24,ipady=8)
        tk.Label(dlg,text='DEMO MODE: production wallet funds must be held/managed through a payment provider approved for this competition model. Provider/compliance limits can override the app’s no-cap preference.',fg=MUTED,bg=BG,font=('Segoe UI',8),wraplength=450,justify='left').pack(anchor='w',padx=24,pady=12)
        def add():
            try:val=round(float(amount.get().replace('$','').replace(',','').strip()),2); assert val>0
            except Exception:messagebox.showerror('Race Wallet','Enter a valid positive amount.'); return
            newbal=wallet_credit(self.conn,rider['id'],val,kind='TOP_UP',provider='DEMO',note='Demo wallet top-up'); dlg.destroy(); messagebox.showinfo('Race Wallet',f"Funds added. New demo balance: ${newbal:,.2f}"); self.show('PROFILE')
        tk.Button(dlg,text='DEMO ADD FUNDS',command=add,bg=ACCENT,fg='white',relief='flat',font=('Segoe UI Black',11),pady=11).pack(fill='x',padx=24)

    # ---------- OTHER RIDER PAGES ----------
    def page_live(self):
        self.titlebar('LIVE','Watch race-day coverage with timing, AI commentary and championship context.')
        wrap=tk.Frame(self.content,bg=BG); wrap.pack(fill='both',expand=True,padx=28,pady=(0,24))
        vid=tk.Frame(wrap,bg='#050607',highlightbackground=LINE,highlightthickness=1); vid.pack(side='left',fill='both',expand=True)
        tk.Label(vid,text='LIVE',fg='white',bg=RED,font=('Segoe UI Black',10),padx=10,pady=5).place(x=16,y=16)
        tk.Label(vid,text='MX BIKES LIVE BROADCAST',fg='#38404a',bg='#050607',font=('Segoe UI Black',30)).place(relx=.5,rely=.43,anchor='center')
        tower=tk.Frame(vid,bg='#11161c'); tower.place(x=18,y=65,width=260,height=350); tk.Label(tower,text='PRO PREMIER • LAP 8/15',fg=GOLD,bg='#11161c',font=('Segoe UI Black',9)).pack(fill='x',padx=10,pady=10)
        for pos,name,gap in [(1,'#1 ProOne1','LEADER'),(2,'#7 ProSeven7','+1.842'),(3,'#311 Welchy','+4.327'),(4,'#27 Ripper27','+5.009')]:
            f=tk.Frame(tower,bg=PANEL2); f.pack(fill='x',padx=8,pady=3); tk.Label(f,text=str(pos),fg=ACCENT,bg=PANEL2,font=('Segoe UI Black',12),width=2).pack(side='left',padx=6,pady=7); tk.Label(f,text=name,fg=TEXT,bg=PANEL2,font=('Segoe UI Semibold',9)).pack(side='left'); tk.Label(f,text=gap,fg=MUTED,bg=PANEL2,font=('Segoe UI',8)).pack(side='right',padx=7)
        side=self.card(wrap); side.pack(side='left',fill='y',padx=(12,0)); side.configure(width=390); side.pack_propagate(False)
        tk.Label(side,text='AI ANNOUNCER',fg=ACCENT,bg=PANEL,font=('Segoe UI Black',12)).pack(anchor='w',padx=16,pady=(16,6))
        for q in ['“The 311 is closing — that gap is coming down quickly.”','“Fastest lap is worth cash tonight, so every clear lap matters.”','“The Pro Premier purse is the reward for climbing the license ladder.”']:
            tk.Label(side,text=q,fg=TEXT,bg=PANEL2,wraplength=340,justify='left',font=('Segoe UI',10),padx=12,pady=12).pack(fill='x',padx=14,pady=5)

    def page_my_races(self):
        self.titlebar('MY RACES','Your paid registrations and completed race history.')
        rider=self.rider(); cols=('Status','Race','Track','Date','Entry'); t=ttk.Treeview(self.content,columns=cols,show='headings')
        for c in cols:t.heading(c,text=c); t.column(c,width=190,anchor='w')
        for x in self.conn.execute('''SELECT rc.*,rg.amount_paid FROM registrations rg JOIN races rc ON rc.id=rg.race_id WHERE rg.rider_id=? ORDER BY rc.start_time''',(rider['id'],)):
            t.insert('', 'end',values=(x['status'],x['name'],x['track'],datetime.fromisoformat(x['start_time']).strftime('%b %d %I:%M %p'),f"${x['amount_paid']:.2f}"))
        t.pack(fill='both',expand=True,padx=28,pady=(0,24))

    def page_results(self):
        self.titlebar('RESULTS','Official finishing order, fastest-lap bonuses, payouts and rating movement.')
        races=list(self.conn.execute("SELECT * FROM races WHERE status='COMPLETE' ORDER BY start_time DESC")); top=tk.Frame(self.content,bg=BG); top.pack(fill='both',expand=True,padx=28)
        for race in races:
            c=self.card(top); c.pack(fill='x',pady=6); tk.Label(c,text=f"{race['name']}   •   {race['track']}   •   {datetime.fromisoformat(race['start_time']).strftime('%b %d, %Y')}",fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(anchor='w',padx=16,pady=(12,4))
            cols=('Pos','Rider','Bike','Best Lap','Finish Prize','Fast Lap','MMR'); t=ttk.Treeview(c,columns=cols,show='headings',height=4)
            for col in cols:t.heading(col,text=col); t.column(col,width=125,anchor='center')
            for x in self.conn.execute('''SELECT rs.*,rd.username,rd.number,rd.bike_model FROM results rs JOIN riders rd ON rd.id=rs.rider_id WHERE rs.race_id=? ORDER BY position''',(race['id'],)):
                t.insert('', 'end',values=(x['position'],f"#{x['number']} {x['username']}",x['bike_model'],x['best_lap'],f"${x['payout']:.0f}",f"${x['fast_lap_bonus']:.0f}" if x['fast_lap_bonus'] else '—',f"{x['skill_delta']:+d}"))
            t.pack(fill='x',padx=16,pady=(2,14))

    def page_championships(self):
        self.titlebar('SERIES','Outdoor MX and winter SX championships. Every track, round, fee and payout rule remains admin-editable.')
        nb=ttk.Notebook(self.content); nb.pack(fill='both',expand=True,padx=28,pady=(0,24))
        for discipline in ('MX','SX'):
            page=tk.Frame(nb,bg=BG); nb.add(page,text=f' {discipline} SERIES ')
            for c in self.conn.execute('''SELECT * FROM championships WHERE discipline=? ORDER BY CASE class_name WHEN '250 C' THEN 1 WHEN '450 C' THEN 2 WHEN '250 B' THEN 3 WHEN '450 B' THEN 4 WHEN '250 Pro' THEN 5 WHEN '450 Pro' THEN 6 ELSE 99 END, id''',(discipline,)):
                card=self.card(page); card.pack(fill='x',pady=6); top=tk.Frame(card,bg=PANEL); top.pack(fill='x',padx=16,pady=(12,4)); tk.Label(top,text=c['name'],fg=TEXT,bg=PANEL,font=('Segoe UI Black',13)).pack(side='left'); tk.Label(top,text=f"{c['rounds']} ROUNDS • ${c['per_round_fee']:.0f}/ROUND",fg=GOLD,bg=PANEL,font=('Segoe UI Black',10)).pack(side='right')
                tk.Label(card,text=f"{c['class_name']}  •  {c['bike_class']}cc  •  Skill requirement: {c['skill_class']}",fg=ACCENT,bg=PANEL,font=('Segoe UI Black',9)).pack(anchor='w',padx=16,pady=(0,5))
                rounds=list(self.conn.execute('SELECT * FROM championship_rounds WHERE championship_id=? ORDER BY round_no LIMIT 6',(c['id'],))); tk.Label(card,text='  •  '.join(f"R{rr['round_no']} {rr['track']}" for rr in rounds)+(' …' if c['rounds']>6 else ''),fg=MUTED,bg=PANEL,font=('Segoe UI',9),wraplength=1000,justify='left').pack(anchor='w',padx=16,pady=(0,12))

    def page_rankings(self):
        self.titlebar('RANKINGS','Skill controls speed class. Racecraft controls access to clean, higher-stakes competition.')
        cols=('Rank','Rider','Class','MMR','Racecraft','Starts','Wins','Podiums','Earnings'); tree=ttk.Treeview(self.content,columns=cols,show='headings')
        for c in cols:tree.heading(c,text=c); tree.column(c,width=120,anchor='center')
        for i,r in enumerate(self.conn.execute('SELECT * FROM riders ORDER BY skill_rating DESC'),1):tree.insert('', 'end',values=(i,f"#{r['number']} {r['username']}",r['skill_class'],r['skill_rating'],f"{r['racecraft_grade']} {r['racecraft_score']}",r['starts'],r['wins'],r['podiums'],f"${r['career_earnings']:,.0f}"))
        tree.pack(fill='both',expand=True,padx=28,pady=(0,24))

    # ---------- ADMIN ----------
    def page_admin(self):
        self.titlebar('ADMIN','Everything important stays configurable. The finance tab checks owner profitability before races are published.')
        nb=ttk.Notebook(self.content); nb.pack(fill='both',expand=True,padx=28,pady=(0,24)); tabs={}
        for n in ['Race Economy','Finance','Race Builder','Championships','Servers','Broadcast','Race Vault','Settings']:
            f=tk.Frame(nb,bg=BG); nb.add(f,text=f' {n} '); tabs[n]=f
        f=tabs['Race Economy']; tk.Label(f,text='DEFAULT LOBBY LADDER',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        data=[('Rookie','Low Entry','$5'),('Rookie','Open','$10'),('Amateur','Low Entry','$8'),('Amateur','Premier','$35'),('Expert','Low Entry','$12'),('Expert','Cash','$25–30'),('Expert','Premier','$50+'),('Pro','Low Entry','$20'),('Pro','Cash','$50+'),('Pro','Premier','$100+')]
        t=ttk.Treeview(f,columns=('Skill','Lobby','Entry'),show='headings',height=11)
        for c in ('Skill','Lobby','Entry'):t.heading(c,text=c); t.column(c,width=210,anchor='center')
        for x in data:t.insert('', 'end',values=x)
        t.pack(fill='x'); tk.Label(f,text='Lower-cost races reduce the barrier to entry. Pro still has the highest ceiling and biggest featured purses.',fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(anchor='w',pady=10)

        f=tabs['Finance']; tk.Label(f,text='OWNER PROFIT CHECK',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=(16,4))
        reserve=setting_float(self.conn,'processor_reserve_pct',.06); fixed=setting_float(self.conn,'race_fixed_ops_reserve',4); floor=setting_float(self.conn,'minimum_owner_profit',4)
        tk.Label(f,text=f"Conservative planning reserve: {reserve*100:.1f}% of entries + ${fixed:.2f} fixed race operations. Minimum projected owner profit: ${floor:.2f}.",fg=MUTED,bg=BG,font=('Segoe UI',9)).pack(anchor='w',pady=(0,10))
        cols=('Race','Entry','Min','Prizes @ Min','Platform @ Min','Reserve/Ops','Projected Owner Net','Status'); ft=ttk.Treeview(f,columns=cols,show='headings',height=13)
        widths={'Race':280,'Entry':80,'Min':60,'Prizes @ Min':120,'Platform @ Min':120,'Reserve/Ops':120,'Projected Owner Net':150,'Status':90}
        for c in cols:ft.heading(c,text=c); ft.column(c,width=widths[c],anchor='center' if c!='Race' else 'w')
        all_good=True
        for race in self.conn.execute("SELECT * FROM races WHERE status='REGISTRATION' ORDER BY skill_class,entry_fee"):
            fin=race_financials(self.conn,race['id'],race['min_riders']); good=fin['owner_projected_net']>=floor; all_good &= good
            ft.insert('', 'end',values=(race['name'],f"${race['entry_fee']:.2f}",race['min_riders'],f"${fin['total_prizes']:.2f}",f"${fin['platform_gross']:.2f}",f"${fin['processor_reserve']+fin['fixed_ops_reserve']:.2f}",f"${fin['owner_projected_net']:.2f}",'PROFITABLE' if good else 'FIX PRICE'))
        ft.pack(fill='both',expand=True)
        tk.Label(f,text='✓ ALL OPEN RACES CLEAR THE PROFIT FLOOR AT THEIR MINIMUM RIDER COUNT' if all_good else '⚠ One or more races fall below the configured profit floor.',fg=GREEN if all_good else RED,bg=BG,font=('Segoe UI Black',10)).pack(anchor='w',pady=10)
        tk.Label(f,text='Projected net is a planning estimate, not a guarantee. Actual processor, chargeback, hosting, tax and compliance costs can differ.',fg=MUTED,bg=BG,font=('Segoe UI',8)).pack(anchor='w')

        f=tabs['Race Builder']; tk.Label(f,text='RACE BUILDER',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        for x in ['Entry fee','Main purse contribution per rider','Fastest-lap contribution per rider','Platform/operations share','Minimum/maximum riders','Skill/MMR range','Racecraft minimum','Track and bike class','Practice / qualifying / moto format','Purse lock time','Broadcast enabled']:
            tk.Label(f,text='✓ '+x,fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w',pady=2)
        tk.Label(f,text='Publishing will eventually block any paid race whose minimum-rider projection falls below your configured owner-profit floor.',fg=GOLD,bg=BG,font=('Segoe UI Semibold',9),wraplength=950,justify='left').pack(anchor='w',pady=12)

        f=tabs['Championships']; tk.Label(f,text='SEASON CONTROL',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Default: MX May–September • SX November–March. Admin can change every date, track, round, fee, purse and points rule.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        f=tabs['Servers']; tk.Label(f,text='MX BIKES RACE AGENT',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Dedicated process control, whitelist enforcement, live timing, results import, replay vaulting and recovery remain the next server-integration milestone.',fg=MUTED,bg=BG,font=('Segoe UI',10),wraplength=900,justify='left').pack(anchor='w')
        f=tabs['Broadcast']; tk.Label(f,text='BROADCAST DIRECTOR',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Live spectator feed • timing tower • AI announcer • fastest-lap cash chase • championship context • sponsor slots.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        f=tabs['Race Vault']; tk.Label(f,text='OWNER-ONLY RACE VAULT',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16); tk.Label(f,text='Hidden from riders: official results, full replays, broadcasts, logs, payment audit records and steward evidence.',fg=TEXT,bg=BG,font=('Segoe UI',10)).pack(anchor='w')
        f=tabs['Settings']; tk.Label(f,text='PLATFORM DEFAULTS',fg=TEXT,bg=BG,font=('Segoe UI Black',16)).pack(anchor='w',pady=16)
        for x in self.conn.execute('SELECT * FROM admin_settings ORDER BY key'):tk.Label(f,text=f"{x['key']}:  {x['value']}",fg=TEXT,bg=BG,font=('Consolas',10)).pack(anchor='w',pady=2)

    def _silent_update_check(self):
        def worker():
            try:
                m=check_for_update()
                if m.get('available'):self.after(0,lambda:self.update_btn.configure(text=f"UPDATE TO {m['version']}"))
            except Exception:pass
        threading.Thread(target=worker,daemon=True).start()
    def do_update(self):
        self.update_btn.configure(state='disabled',text='CHECKING…')
        def worker():
            try:
                m=check_for_update()
                if not m.get('available'):
                    self.after(0,lambda:(self.update_btn.configure(state='normal',text='UPDATE'),messagebox.showinfo('MXB Race Control',f'You are on the latest version: v{VERSION}'))); return
                self.after(0,lambda:self.update_btn.configure(text=f"DOWNLOADING {m['version']}…")); z=download_update(m); self.after(0,lambda:self.update_btn.configure(text='RESTARTING…')); launch_update(z); self.after(500,self.destroy)
            except Exception as e:self.after(0,lambda:(self.update_btn.configure(state='normal',text='UPDATE'),messagebox.showerror('Update Failed',str(e))))
        threading.Thread(target=worker,daemon=True).start()

def main():RaceControlApp().mainloop()
