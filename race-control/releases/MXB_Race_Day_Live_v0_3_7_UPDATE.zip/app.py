from pathlib import Path
from src.app import main
from src.windows_integration import ensure_desktop_shortcut

if __name__ == '__main__':
    try:
        ensure_desktop_shortcut(Path(__file__).resolve().parent)
    except Exception:
        pass
    main()
