from __future__ import annotations

import base64
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
import urllib.request
import zipfile

from .config import VERSION

REPO = 'n286f7kh2k-debug/MXB-Bike-Builder'
BRANCH = 'main'
MANIFEST_PATH = 'race-control/latest.json'
MANIFEST_API = f'https://api.github.com/repos/{REPO}/contents/{MANIFEST_PATH}'
MANIFEST_RAW = f'https://raw.githubusercontent.com/{REPO}/{BRANCH}/{MANIFEST_PATH}'
USER_AGENT = f'MXB-Race-Day-Live-Updater/{VERSION}'


def _version_tuple(value):
    parts = []
    for piece in str(value or '').strip().lstrip('vV').split('.'):
        digits = ''.join(ch for ch in piece if ch.isdigit())
        parts.append(int(digits or 0))
    while len(parts) < 4:
        parts.append(0)
    return tuple(parts[:4])


def _request(url, timeout=20):
    sep = '&' if '?' in url else '?'
    busted = f'{url}{sep}_mxb={time.time_ns()}'
    req = urllib.request.Request(
        busted,
        headers={
            'User-Agent': USER_AGENT,
            'Accept': 'application/vnd.github+json, application/json;q=0.9, */*;q=0.1',
            'Cache-Control': 'no-cache, no-store, max-age=0',
            'Pragma': 'no-cache',
        },
    )
    return urllib.request.urlopen(req, timeout=timeout)


def _normalize_manifest(data):
    if not isinstance(data, dict):
        raise RuntimeError('Update feed returned an invalid manifest.')
    version = str(data.get('version') or '').strip().lstrip('vV')
    url = str(data.get('url') or '').strip()
    sha256 = str(data.get('sha256') or '').strip().lower()
    notes = str(data.get('notes') or '').strip()
    if not version or not url:
        raise RuntimeError('Update manifest is missing version or download URL.')
    if sha256 and (len(sha256) != 64 or any(c not in '0123456789abcdef' for c in sha256)):
        raise RuntimeError('Update manifest contains an invalid SHA-256 value.')
    return {'version': version, 'url': url, 'sha256': sha256, 'notes': notes}


def _manifest_from_github_api():
    with _request(f'{MANIFEST_API}?ref={BRANCH}', timeout=20) as r:
        payload = json.loads(r.read().decode('utf-8'))
    encoded = str(payload.get('content') or '').replace('\n', '')
    if not encoded:
        raise RuntimeError('GitHub update feed did not contain manifest data.')
    raw = base64.b64decode(encoded).decode('utf-8-sig')
    return _normalize_manifest(json.loads(raw))


def _manifest_from_raw():
    with _request(MANIFEST_RAW, timeout=20) as r:
        return _normalize_manifest(json.loads(r.read().decode('utf-8-sig')))


def _get_manifest():
    errors = []
    for loader in (_manifest_from_github_api, _manifest_from_raw):
        try:
            return loader()
        except Exception as exc:
            errors.append(str(exc))
    raise RuntimeError('Could not refresh the Race Day Live update feed. ' + ' | '.join(errors))


def check_for_update(current_version=None):
    current = str(current_version or VERSION).strip().lstrip('vV')
    manifest = _get_manifest()
    manifest['current_version'] = current
    manifest['available'] = _version_tuple(manifest['version']) > _version_tuple(current)
    return manifest


def download_update(manifest):
    manifest = _normalize_manifest(manifest)
    out = Path(tempfile.gettempdir()) / f"MXB_Race_Day_Live_v{manifest['version'].replace('.', '_')}_UPDATE.zip"
    tmp = out.with_suffix(out.suffix + '.part')
    tmp.unlink(missing_ok=True)
    h = hashlib.sha256()
    try:
        with _request(manifest['url'], timeout=60) as src, tmp.open('wb') as dst:
            while True:
                chunk = src.read(1024 * 1024)
                if not chunk:
                    break
                dst.write(chunk)
                h.update(chunk)
        digest = h.hexdigest()
        expected = manifest.get('sha256') or ''
        if expected and digest.lower() != expected.lower():
            raise RuntimeError(f'Update download failed SHA-256 verification. Expected {expected}, got {digest}.')
        if not zipfile.is_zipfile(tmp):
            raise RuntimeError('Downloaded update is not a valid ZIP package.')
        os.replace(tmp, out)
        return out
    except Exception:
        tmp.unlink(missing_ok=True)
        raise


def _install_root():
    return Path(__file__).resolve().parent.parent


def schedule_restart(update_zip, install_dir=None, wait_pid=None):
    update_zip = Path(update_zip).resolve()
    install_dir = Path(install_dir or _install_root()).resolve()
    wait_pid = int(wait_pid or os.getpid())
    if not update_zip.exists() or not zipfile.is_zipfile(update_zip):
        raise RuntimeError('Update package disappeared before install could start.')

    script = Path(tempfile.gettempdir()) / 'mxb_race_day_live_apply_update.py'
    code = '''import os, shutil, subprocess, sys, tempfile, time, zipfile\nfrom pathlib import Path\nzip_path=Path(sys.argv[1]).resolve()\ninstall=Path(sys.argv[2]).resolve()\npid=int(sys.argv[3])\nfor _ in range(240):\n    try:\n        os.kill(pid,0)\n        time.sleep(0.25)\n    except OSError:\n        break\nwork=Path(tempfile.mkdtemp(prefix="mxb_rdl_apply_"))\ntry:\n    with zipfile.ZipFile(zip_path) as z:z.extractall(work)\n    for src in sorted(work.rglob("*")):\n        rel=src.relative_to(work)\n        dst=install/rel\n        if src.is_dir():\n            dst.mkdir(parents=True,exist_ok=True)\n            continue\n        dst.parent.mkdir(parents=True,exist_ok=True)\n        tmp=dst.with_name(dst.name+".mxbnew")\n        try:\n            shutil.copy2(src,tmp)\n            os.replace(tmp,dst)\n        finally:\n            try:tmp.unlink(missing_ok=True)\n            except Exception:pass\n    vbs=install/"Start MXB Race Day Live.vbs"\n    if vbs.exists():\n        subprocess.Popen(["wscript.exe",str(vbs)],cwd=str(install),creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))\n    else:\n        app=install/"app.py"\n        py=Path(sys.executable)\n        pythonw=py.with_name("pythonw.exe")\n        subprocess.Popen([str(pythonw if pythonw.exists() else py),str(app)],cwd=str(install),creationflags=getattr(subprocess,"CREATE_NO_WINDOW",0))\nfinally:\n    shutil.rmtree(work,ignore_errors=True)\n    try:zip_path.unlink(missing_ok=True)\n    except Exception:pass\n'''
    script.write_text(code, encoding='utf-8')
    pythonw = Path(sys.executable).with_name('pythonw.exe')
    runner = str(pythonw if pythonw.exists() else Path(sys.executable))
    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0)
    subprocess.Popen(
        [runner, str(script), str(update_zip), str(install_dir), str(wait_pid)],
        cwd=str(install_dir),
        creationflags=flags,
        close_fds=True,
    )
    return script


def launch_update(update_zip):
    return schedule_restart(update_zip)
